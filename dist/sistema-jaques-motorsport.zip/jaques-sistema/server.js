/**
 * Jaques Motorsport — Sistema de Gestão Interno
 * Servidor HTTP + API REST em Node.js puro (sem dependências externas).
 *
 * Iniciar:  npm start   (ou: node server.js)
 * Acesso:   http://localhost:3000   —   login inicial: admin / admin123
 */
'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const os = require('os');

const db = require('./lib/db');
const domain = require('./lib/domain');
const ai = require('./lib/ai');
const xlsx = require('./lib/xlsx');
const sync = require('./lib/sync');
const contaazul = require('./lib/contaazul');
const casync = require('./lib/casync');
const { seedIfEmpty, hashPassword, checkPassword, isLegacyHash, MODULES,
  sincronizarAcessoCompleto } = require('./lib/seed');

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');

seedIfEmpty();
/* Funcionalidade nova entra sozinha em quem tem acesso completo. */
sincronizarAcessoCompleto(db);

/* ===================================================================== */
/* Utilitários HTTP                                                      */
/* ===================================================================== */

function send(res, status, data, headers) {
  const body = typeof data === 'string' ? data : JSON.stringify(data);
  res.writeHead(status, Object.assign({ 'Content-Type': 'application/json; charset=utf-8' }, headers));
  res.end(body);
}
/* Escapa texto para as poucas páginas HTML montadas aqui no servidor
   (o retorno da autorização da Conta Azul). */
function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

const ok = (res, data) => send(res, 200, data);
const bad = (res, msg) => send(res, 400, { error: msg });
const notFound = (res) => send(res, 404, { error: 'Não encontrado' });
const forbidden = (res, msg) => send(res, 403, { error: msg || 'Sem permissão para esta ação' });

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', c => { data += c; if (data.length > 15e6) req.destroy(); });
    req.on('end', () => {
      if (!data) return resolve({});
      try { resolve(JSON.parse(data)); } catch (e) { reject(new Error('JSON inválido')); }
    });
    req.on('error', reject);
  });
}

/* ===================================================================== */
/* Autenticação / permissões                                             */
/* ===================================================================== */

function authUser(req) {
  const h = req.headers['authorization'] || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : (req.headers['x-auth-token'] || '');
  if (!token) return null;
  const sess = db.all('sessions').find(s => s.token === token);
  if (!sess) return null;
  const user = db.get('users', sess.userId);
  if (!user || !user.active) return null;
  // Expiração deslizante: a sessão vale enquanto for usada (renova a cada acesso,
  // gravado no máximo 1x/hora para não inflar o arquivo de dados).
  const now = Date.now();
  if (!sess.lastUsed || now - new Date(sess.lastUsed).getTime() > 3600e3) {
    db.update('sessions', sess.id, { lastUsed: new Date(now).toISOString() });
  }
  return user;
}

function permissionsOf(user) {
  const role = db.get('roles', user.roleId);
  return role ? role.permissions : [];
}
/**
 * Uma lista de permissões significa "qualquer uma serve". É o que permite
 * estrear uma permissão nova sem tirar acesso de quem já trabalhava: a
 * Agenda financeira pede ['agenda', 'payables', 'receivables'], então quem
 * só tinha 'payables' continua entrando, e a Direção pode passar a conceder
 * 'agenda' sozinha para um perfil novo.
 */
function can(user, perm) {
  const perms = permissionsOf(user);
  if (perms.includes('admin')) return true;           // acesso completo
  return Array.isArray(perm) ? perm.some(p => perms.includes(p)) : perms.includes(perm);
}

/* As mensagens de confirmação são lidas por quem trabalha na oficina:
   valor e data vão no formato daqui, não no do banco de dados. */
const brl = (v) => 'R$ ' + (Number(v) || 0).toLocaleString('pt-BR',
  { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const dataBR = (d) => /^\d{4}-\d{2}-\d{2}$/.test(String(d || ''))
  ? String(d).slice(0, 10).split('-').reverse().join('/') : String(d || '');

function audit(user, action, entity, entityId, details) {
  db.insert('audit', {
    at: new Date().toISOString(),
    userId: user ? user.id : null,
    userName: user ? user.name : 'sistema',
    action, entity, entityId: entityId || null,
    details: details || ''
  });
  // Mantém o log dentro de um tamanho razoável.
  const a = db.all('audit');
  if (a.length > 20000) a.splice(0, a.length - 20000);
}

/**
 * Cópia de segurança do banco antes de qualquer ferramenta de correção.
 * Devolve o caminho do arquivo; estoura se não conseguir gravar — correção
 * nenhuma começa sem a cópia salva.
 */
function backupArquivo(prefixo) {
  db.persistNow();
  const dir = path.join(db.DATA_DIR, 'backups');
  fs.mkdirSync(dir, { recursive: true });
  const arq = path.join(dir, `${prefixo}-${new Date().toISOString().replace(/[:.]/g, '-')}.json`);
  fs.copyFileSync(db.DB_FILE, arq);
  return arq;
}

/** Remove campos financeiros sensíveis para usuários sem a permissão finance_sensitive. */
function sanitize(user, collection, record) {
  if (!record) return record;
  const sensivel = can(user, 'finance_sensitive');
  if (sensivel) return record;
  const financeiro = can(user, 'cashflow') || can(user, 'receivables') || can(user, 'payables');
  const r = Object.assign({}, record);

  // Custos, margens e salários: só para 'dados financeiros sensíveis'
  if (collection === 'products') { delete r.custoBase; }
  if (collection === 'sales') { delete r.custoBaseTotal; delete r.custosAdicionais; delete r.resultado; }
  if (collection === 'employees') { delete r.salario; delete r.beneficios; }
  if (collection === 'stockItems') { delete r.custoUnit; }

  // Nenhum acesso financeiro (ex.: Produção): também não vê preços, totais
  // nem condições de pagamento — só o conteúdo técnico/operacional.
  if (!financeiro) {
    const limpaItens = itens => (itens || []).map(i => {
      const x = Object.assign({}, i);
      delete x.valorUnit; delete x.total; delete x.preco;
      return x;
    });
    if (collection === 'sales' || collection === 'serviceOrders' || collection === 'quotes') {
      delete r.valorTotal; delete r.total; delete r.pagamento; delete r.custosAdicionais;
      if (r.itens) r.itens = limpaItens(r.itens);
    }
    if (collection === 'products') { delete r.preco; }
    if (collection === 'serviceCatalog') { delete r.preco; }
    if (collection === 'stockItems') { delete r.custoUnit; }
  }
  return r;
}

/* ===================================================================== */
/* Registro de coleções expostas via CRUD genérico                       */
/* ===================================================================== */
/* perm: permissão necessária. writeperm: se diferente da leitura.       */

const REST = {
  clients: { perm: 'clients', label: 'Cliente' },
  serviceCatalog: { perm: 'quotes', writePerm: 'admin', label: 'Serviço do catálogo' },
  products: { perm: 'sales', writePerm: ['products', 'finance_sensitive'], label: 'Produto' },
  stockItems: { perm: 'stock', label: 'Item de estoque' },
  stockMoves: { perm: ['stock_history', 'stock'], label: 'Movimentação de estoque',
                editPerm: 'stock_history_edit' },
  suppliers: { perm: 'suppliers', label: 'Fornecedor' },
  supplierExpenses: { perm: 'suppliers', label: 'Despesa de fornecedor' },
  recurring: { perm: 'payables', label: 'Conta recorrente' },
  tasks: { perm: 'tasks', label: 'Pendência' },
  employees: { perm: 'hr', label: 'Colaborador' },
  hrPayments: { perm: 'hr', label: 'Pagamento de RH' },
  assets: { perm: 'assets', label: 'Bem de cliente' },
  quotes: { perm: 'quotes', label: 'Orçamento' },
  headEntries: { perm: 'entries', label: 'Entrada de cabeçote' },
  serviceOrders: { perm: 'os', label: 'Ordem de serviço' },
  productionOrders: { perm: 'production', label: 'Ordem de produção' },
  sales: { perm: 'sales', label: 'Venda' },
  purchases: { perm: 'purchases', label: 'Compra' },
  freights: { perm: ['freights', 'payables'], label: 'Frete' },
  supplierInvoices: { perm: 'suppliers', label: 'Fatura de fornecedor' },
  payables: { perm: 'payables', label: 'Conta a pagar', editPerm: 'payables_edit' },
  receivables: { perm: 'receivables', label: 'Conta a receber' },
  cashflow: { perm: 'cashflow', label: 'Lançamento de caixa', editPerm: 'cashflow_edit' }
};

/* ===================================================================== */
/* Regras auxiliares                                                     */
/* ===================================================================== */

/* Situação de uma parcela a receber (boleto):
     aberto    — a vencer;
     vencida   — derivada na leitura, quando o vencimento já passou;
     parcial   — recebida em parte, continua sendo cobrança pelo SALDO;
     paga      — quitada;
     cancelada — fora da cobrança, mas preservada no histórico.
   "parcial" não vira "vencida": ela guarda o próprio estado e o atraso vai
   como marca (`atrasada`), para a tela conseguir mostrar as duas coisas. */

/** Quanto já entrou de uma parcela. A quitada vale pelo total. */
function recebidoDaParcela(r) {
  if (r.status === 'paga') return Math.round((Number(r.valor) || 0) * 100) / 100;
  return Math.round((Number(r.recebido) || 0) * 100) / 100;
}
/** Quanto ainda falta receber de uma parcela (0 se paga ou cancelada). */
function saldoDaParcela(r) {
  if (r.status === 'paga' || r.status === 'cancelada') return 0;
  return Math.round(((Number(r.valor) || 0) - (Number(r.recebido) || 0)) * 100) / 100;
}
/** Está em atraso? (vale para a que venceu e para a recebida em parte) */
function emAtraso(r) { return r.status === 'vencida' || (r.status === 'parcial' && r.atrasada); }
/** Continua sendo cobrança — conta no "a receber" pelo saldo. */
function aReceber(r) { return r.status === 'aberto' || r.status === 'vencida' || r.status === 'parcial'; }

/* ---------------------------------------------------------------------
   Forma de pagamento de um lançamento de caixa.

   NÃO é conta bancária. O dinheiro continua saindo e entrando da mesma
   conta da empresa — isto diz COMO o pagamento foi feito, para conferir a
   fatura do cartão, separar o que foi no dinheiro, etc.                  */
const FORMAS_PAGAMENTO = [
  ['pix', 'Pix'],
  ['dinheiro', 'Dinheiro'],
  ['cartao_credito', 'Cartão de crédito'],
  ['cartao_debito', 'Cartão de débito'],
  ['boleto', 'Boleto'],
  ['transferencia', 'Transferência'],
  ['cheque', 'Cheque'],
  ['outro', 'Outra']
];
const FORMAS_VALIDAS = FORMAS_PAGAMENTO.map(f => f[0]);

/* Os módulos antigos gravavam a forma com outros nomes ('cartao', 'link',
   'ted'). Traduzir na leitura evita ter que reescrever o histórico. */
const FORMA_LEGADO = {
  cartao: 'cartao_credito', credito: 'cartao_credito', 'cartao de credito': 'cartao_credito',
  debito: 'cartao_debito', 'cartao de debito': 'cartao_debito',
  link: 'cartao_credito', ted: 'transferencia', doc: 'transferencia',
  transferencia_bancaria: 'transferencia', especie: 'dinheiro'
};

function normalizaForma(v) {
  if (!v) return '';
  const chave = String(v).normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .toLowerCase().trim().replace(/[\s-]+/g, '_');
  if (FORMAS_VALIDAS.includes(chave)) return chave;
  return FORMA_LEGADO[chave] || FORMA_LEGADO[chave.replace(/_/g, ' ')] || '';
}

/** Preenche a forma de pagamento na leitura, sem reescrever o histórico.
    Lançamentos antigos da planilha marcavam o cartão na conta. */
function comFormaPagamento(list) {
  return list.map(c => {
    if (c.formaPagamento) return c;
    const daConta = normalizaForma(c.conta);
    return daConta ? Object.assign({}, c, { formaPagamento: daConta }) : c;
  });
}

/** Marca como vencidas as parcelas/contas em aberto com vencimento passado (derivado na leitura). */
function withOverdue(list) {
  const t = domain.today();
  return list.map(r => {
    const venceu = !!(r.vencimento && r.vencimento < t);
    if (r.status === 'aberto' && venceu) return Object.assign({}, r, { status: 'vencida' });
    if (r.status === 'parcial') return Object.assign({}, r, { atrasada: venceu });
    return r;
  });
}

/* ---- código interno do cliente (CLI-000001) ----------------------------
   Identificador do próprio sistema: nasce no cadastro, nunca muda e nunca se
   repete. O nome pode ser corrigido, e dois clientes podem ter nomes iguais —
   o código é o que os separa em vendas, serviços, orçamentos e financeiro.
   Não é o CPF/CNPJ: o cadastro pode existir sem documento, e o documento
   pertence ao cliente, não à numeração da empresa. */

const CODIGO_CLIENTE_RE = /^CLI-(\d+)$/;

function formatCodigoCliente(seq) { return 'CLI-' + String(seq).padStart(6, '0'); }

/** Próximo código livre. Nunca reaproveita um código já usado por outro cadastro. */
function proximoCodigoCliente() {
  const usados = new Set(db.all('clients').map(c => c.codigo).filter(Boolean));
  let codigo;
  do { codigo = formatCodigoCliente(db.nextNumber('cliente', 1)); } while (usados.has(codigo));
  return codigo;
}

/**
 * Cadastros anteriores a esta versão — ou vindos de um backup — recebem o
 * código que falta, na ordem em que foram criados. A sequência é adiantada
 * para depois do maior código existente, para que a numeração nunca volte
 * atrás depois de uma restauração.
 */
function garantirCodigosDeCliente() {
  const clients = db.all('clients');
  let maior = 0;
  for (const c of clients) {
    const m = CODIGO_CLIENTE_RE.exec(String(c.codigo || ''));
    if (m) maior = Math.max(maior, Number(m[1]));
  }
  const seq = db.load()._seq;
  if ((seq['num:cliente'] || 0) < maior) seq['num:cliente'] = maior;

  const semCodigo = clients.filter(c => !c.codigo).sort((a, b) => a.id - b.id);
  for (const c of semCodigo) db.update('clients', c.id, { codigo: proximoCodigoCliente() });
  if (semCodigo.length || maior) db.save();
  return semCodigo.length;
}

/**
 * Sugere um responsável: primeiro usuário ativo cujo perfil tem a permissão
 * pedida (preferindo perfis específicos — Financeiro, Produção — antes do
 * Administrador, que fica como último recurso).
 */
function suggestAssignee(perm) {
  const roles = db.all('roles');
  const users = db.all('users').filter(u => u.active);
  const roleOf = u => roles.find(r => r.id === u.roleId);
  const specific = users.find(u => {
    const r = roleOf(u);
    return r && r.permissions.includes(perm) && !r.permissions.includes('admin');
  });
  if (specific) return specific.id;
  const admin = users.find(u => {
    const r = roleOf(u);
    return r && r.permissions.includes('admin');
  });
  return admin ? admin.id : null;
}

/**
 * Avisos das contas recorrentes (COPEL, Sanepar, consórcio…):
 * a pendência nasce alguns dias ANTES do vencimento (padrão 4, configurável
 * por conta), já com dono sugerido (perfil financeiro) e link do site.
 * A baixa é automática quando o boleto do mês é cadastrado em Contas a pagar.
 */
function ensureRecurringTasks() {
  const hoje = domain.today();
  const nextM = new Date(hoje + 'T12:00:00');
  nextM.setMonth(nextM.getMonth() + 1);
  const meses = [hoje.slice(0, 7), nextM.toISOString().slice(0, 7)];
  for (const rec of db.all('recurring').filter(r => r.ativo)) {
    const aviso = Number(rec.diasAviso) || 4;
    for (const month of meses) {
      const due = `${month}-${String(rec.diaVencimento || 10).padStart(2, '0')}`;
      if (domain.addDays(due, -aviso) > hoje) continue;   // ainda é cedo para avisar
      if (due < domain.addDays(hoje, -45)) continue;      // vencimento antigo demais
      if (db.all('tasks').some(t => t.recurringId === rec.id && t.refMonth === month)) continue;
      db.insert('tasks', {
        titulo: `Pagar/emitir boleto — ${rec.nome} (vence dia ${rec.diaVencimento || 10})`,
        descricao: rec.instrucao || '',
        prioridade: 'urgente',
        assigneeId: suggestAssignee('payables'),
        status: 'aberta',
        recurringId: rec.id,
        refMonth: month,
        due,
        link: rec.link || '',
        origem: 'conta recorrente'
      });
    }
  }
}

/** Cadastrou o boleto do mês em Contas a pagar → a pendência se conclui sozinha. */
function completeRecurringTask(recurringId, vencimento) {
  if (!recurringId) return;
  const month = String(vencimento || '').slice(0, 7);
  for (const t of db.all('tasks').filter(t =>
    t.recurringId === Number(recurringId) && t.status === 'aberta' && (!month || t.refMonth <= month))) {
    db.update('tasks', t.id, { status: 'concluida', concluidaEm: domain.today(), origem: 'conta recorrente · baixa automática' });
  }
}

/* ===================================================================== */
/* Vínculos de um cadastro                                               */
/* ===================================================================== */

/**
 * Onde cada cadastro é referenciado. É esta tabela que permite responder
 * "dá para apagar?" sem sair caçando à mão em cada tela — e que garante
 * que apagar um cliente duplicado nunca leve junto a venda dele.
 * [coleção, campo, rótulo humano]
 */
const VINCULOS = {
  clients: [
    ['sales', 'clienteId', 'venda(s)'], ['quotes', 'clienteId', 'orçamento(s)'],
    ['serviceOrders', 'clienteId', 'ordem(ns) de serviço'], ['headEntries', 'clienteId', 'entrada(s) de cabeçote'],
    ['assets', 'clienteId', 'bem(ns) guardado(s)'], ['receivables', 'clienteId', 'conta(s) a receber'],
    ['freights', 'clienteId', 'frete(s)'], ['supplierExpenses', 'clienteId', 'gasto(s) de fornecedor'],
    ['clientCredits', 'clienteId', 'crédito(s)']
  ],
  suppliers: [
    ['purchases', 'fornecedorId', 'compra(s)'], ['payables', 'fornecedorId', 'conta(s) a pagar'],
    ['supplierExpenses', 'fornecedorId', 'gasto(s) do mês'], ['supplierInvoices', 'fornecedorId', 'fatura(s) mensal(is)']
  ],
  products: [
    ['sales', 'itens.productId', 'venda(s)'], ['productionOrders', 'productId', 'ordem(ns) de produção'],
    ['models3d', 'produtoId', 'modelo(s) 3D']
  ],
  stockItems: [
    ['stockMoves', 'itemId', 'movimentação(ões) de estoque'], ['sales', 'itens.stockItemId', 'venda(s)']
  ],
  employees: [['hrPayments', 'employeeId', 'lançamento(s) de RH']],
  serviceCatalog: [['quotes', 'itens.catalogId', 'orçamento(s)'], ['serviceOrders', 'itens.catalogId', 'ordem(ns) de serviço']],
  headEntries: [['quotes', 'entryId', 'orçamento(s)'], ['serviceOrders', 'entryId', 'ordem(ns) de serviço'], ['assets', 'entryId', 'bem(ns)']],
  assets: [['headEntries', 'assetId', 'entrada(s)']]
};

/** Cadastros que aceitam ser inativados em vez de apagados. */
const INATIVAVEIS = { clients: 'ativo', suppliers: 'ativo', products: 'ativo', employees: 'ativo', serviceCatalog: 'ativo', stockItems: 'ativo' };

/** Conta as referências a um registro. Devolve [{colecao, rotulo, qtd}]. */
function vinculosDe(colecao, id) {
  const regras = VINCULOS[colecao] || [];
  const alvo = Number(id);
  const out = [];
  for (const [col, campo, rotulo] of regras) {
    let qtd;
    if (campo.includes('.')) {
      const [lista, chave] = campo.split('.');
      qtd = db.all(col).filter(r => (r[lista] || []).some(i => Number(i[chave]) === alvo)).length;
    } else {
      qtd = db.all(col).filter(r => Number(r[campo]) === alvo).length;
    }
    if (qtd) out.push({ colecao: col, rotulo, qtd });
  }
  return out;
}

/** Movimenta estoque com registro da movimentação. */
function moveStock(itemId, tipo, qtd, refType, refId, obs, user, extra) {
  const item = db.get('stockItems', itemId);
  if (!item) return null;
  const delta = tipo === 'entrada' ? qtd : -qtd;
  item.qtd = (item.qtd || 0) + delta;
  db.update('stockItems', item.id, { qtd: item.qtd });
  /* `extra` guarda a procedência da movimentação (compra, fornecedor, NF,
     custo unitário e total). É o que faz o histórico do estoque responder
     "de onde veio esta peça" sem ninguém redigitar nada. */
  db.insert('stockMoves', Object.assign({
    itemId, itemNome: item.nome, tipo, qtd, data: domain.today(), refType, refId, obs: obs || ''
  }, extra || {}));
  if (user) audit(user, 'estoque', 'stockItems', itemId, `${tipo} de ${qtd} × ${item.nome}`);
  return item;
}

/* =====================================================================
   PRODUTOS, CONFIGURAÇÕES E COMPOSIÇÃO TÉCNICA

   O que antes estava escrito no código — quais comandos cada Stage aceita,
   que tucho usa, que peças entram na montagem — passa a morar no cadastro
   do produto. Produtos e custos administra isso; venda, orçamento,
   produção, estoque e custo leem a MESMA composição.
   ===================================================================== */

/* Papéis de seed: como encontrar, UMA vez, o item de estoque de cada peça
   da sugestão inicial. Depois da migração cada linha já aponta para o item. */
const PAPEL_BUSCA = {
  casco: (cfg) => it => it.categoria === (cfg.tipo === 'crossflow' ? 'casco_crossflow' : 'casco_unilateral'),
  valvula_adm: () => it => it.categoria === 'valvula' && /admiss/i.test(it.nome || ''),
  valvula_esc: () => it => it.categoria === 'valvula' && /escape/i.test(it.nome || ''),
  mola: () => it => it.categoria === 'mola',
  prato: () => it => it.categoria === 'prato',
  trava: () => it => it.categoria === 'trava'
};

/** Item de estoque do comando escolhido (ex.: "Comando 290x300"). */
function itemDoComando(comando) {
  const alvo = String(comando || '').trim().toLowerCase();
  if (!alvo) return null;
  return db.all('stockItems').find(it =>
    it.categoria === 'comando' && String(it.nome || '').toLowerCase().includes(alvo)) || null;
}

/** Item de estoque do tucho escolhido (35 ou 37 mm). */
function itemDoTucho(tucho) {
  const cat = String(tucho) === '37' ? 'tucho37' : 'tucho35';
  return db.all('stockItems').find(it => it.categoria === cat) || null;
}

/**
 * Composição do produto já RESOLVIDA para uma configuração concreta:
 * o comando e o tucho viram o item de estoque que será realmente baixado.
 * Devolve uma linha por peça, com quantidade, custo e se está vinculada.
 */
function composicaoResolvida(prod, cfg) {
  cfg = cfg || {};
  const linhas = Array.isArray(prod && prod.composicao) ? prod.composicao : [];
  const tipo = cfg.tipo || (prod && prod.tipo) || '';
  return linhas.map((l, idx) => {
    const qtd = Math.max(0, Number(l.qtd) || 0);
    let item = null, motivo = '';
    if (l.papel === 'comando') {
      item = itemDoComando(cfg.comando);
      if (!item) motivo = cfg.comando
        ? `Não existe item de estoque para o comando ${cfg.comando}`
        : 'Comando não informado';
    } else if (l.papel === 'tucho') {
      item = itemDoTucho(cfg.tucho);
      if (!item) motivo = `Não existe item de estoque para o tucho ${cfg.tucho || '—'} mm`;
    } else {
      item = l.stockItemId ? db.get('stockItems', l.stockItemId) : null;
      if (!item) motivo = 'Linha da composição sem item de estoque vinculado';
    }
    const custoUnit = item ? (Number(item.custoUnit) || 0) : 0;
    return {
      idx, papel: l.papel || 'fixo', obs: l.obs || '', qtd,
      stockItemId: item ? item.id : null,
      nome: item ? item.nome : (l.papel === 'comando' ? `Comando ${cfg.comando || '—'}`
        : l.papel === 'tucho' ? `Tucho ${cfg.tucho || '—'} mm` : (l.nomeLivre || 'Peça não vinculada')),
      categoria: item ? item.categoria : '',
      emEstoque: item ? (Number(item.qtd) || 0) : null,
      custoUnit, custoTotal: Math.round(custoUnit * qtd * 100) / 100,
      vinculado: !!item, motivo, tipo
    };
  });
}

/** Custo da composição somado, com a lista por peça. */
function custoDaComposicao(prod, cfg) {
  const linhas = composicaoResolvida(prod, cfg);
  const total = linhas.reduce((s, l) => s + l.custoTotal, 0);
  return {
    linhas, total: Math.round(total * 100) / 100,
    semCusto: linhas.filter(l => l.vinculado && !l.custoUnit).length,
    semVinculo: linhas.filter(l => !l.vinculado).length
  };
}

/** Configuração de um produto no formato que as telas consomem. */
function produtoComConfig(prod) {
  if (!prod) return prod;
  const { comandos, tuchos } = domain.opcoesDoProduto(prod);
  return Object.assign({}, prod, {
    comandos, tuchos,
    rotuloStage: prod.rotuloStage || domain.rotuloStage(prod.stage, prod.variante)
  });
}

/* ------------------------------------------------------------------
   MIGRAÇÃO (uma vez, na primeira subida desta versão)

   - cada configuração passa a guardar os seus comandos e tuchos;
   - entra o comando 280x280 no Stage 1 das duas linhas;
   - Stage 3 passa a ser a configuração de tucho 35 mm e nasce o
     Stage 3 Plus, de 37 mm, com os mesmos comandos;
   - cada configuração ganha uma composição sugerida, marcada como NÃO
     CONFERIDA até a oficina revisar.
   Nada é apagado e nenhum pedido antigo é tocado: venda, orçamento e
   ordem de produção guardam a própria configuração desde que nasceram.
   ------------------------------------------------------------------ */
function garantirItemDeEstoque(nome, categoria) {
  const achado = db.all('stockItems').find(it =>
    String(it.nome || '').trim().toLowerCase() === String(nome).trim().toLowerCase());
  if (achado) return achado;
  return db.insert('stockItems', { nome, categoria, qtd: 0, custoUnit: 0, minimo: 0, ativo: true });
}

function composicaoSugerida(tipo) {
  return domain.COMPOSICAO_SUGERIDA.map(linha => {
    if (linha.papel === 'comando' || linha.papel === 'tucho') {
      return { papel: linha.papel, stockItemId: null, qtd: linha.qtd, obs: linha.obs };
    }
    const busca = PAPEL_BUSCA[linha.papel];
    const item = busca ? db.all('stockItems').find(busca({ tipo })) : null;
    return { papel: 'fixo', stockItemId: item ? item.id : null, qtd: linha.qtd, obs: linha.obs };
  });
}

function migrarProdutos() {
  const feitos = { configurados: 0, comandoNovo: 0, criados: 0, composicoes: 0 };
  const todos = db.all('products');
  if (!todos.length) return feitos;

  // O comando novo precisa existir no estoque para poder ser baixado.
  garantirItemDeEstoque(`Comando ${domain.COMANDO_NOVO_STAGE1}`, 'comando');

  for (const p of todos) {
    const mudanca = {};
    const stage = Number(p.stage);

    if (!Array.isArray(p.comandos) || !p.comandos.length) {
      mudanca.comandos = (domain.STAGE_COMANDOS[stage] || []).slice();
      feitos.configurados++;
    }
    const comandos = mudanca.comandos || p.comandos;
    if (stage === 1 && !comandos.includes(domain.COMANDO_NOVO_STAGE1)) {
      mudanca.comandos = comandos.concat([domain.COMANDO_NOVO_STAGE1]);
      feitos.comandoNovo++;
    }
    if (!Array.isArray(p.tuchos) || !p.tuchos.length) {
      /* Stage 3 passa a ser o de 35 mm; o de 37 vira Stage 3 Plus, criado
         logo abaixo. Stage 1 e 2 seguem com 35 mm. */
      mudanca.tuchos = ['35'];
    }
    if (p.variante === undefined) mudanca.variante = '';
    if (!p.rotuloStage) mudanca.rotuloStage = domain.rotuloStage(stage, p.variante || '');
    if (p.ativo === undefined) mudanca.ativo = true;
    if (!Array.isArray(p.composicao) || !p.composicao.length) {
      mudanca.composicao = composicaoSugerida(p.tipo);
      mudanca.composicaoConfirmada = false;
      feitos.composicoes++;
    }
    if (p.custoBaseAuto === undefined) mudanca.custoBaseAuto = false;
    if (Object.keys(mudanca).length) db.update('products', p.id, mudanca);
  }

  // Stage 3 Plus (tucho 37 mm) — uma configuração por linha.
  for (const tipo of ['unilateral', 'crossflow']) {
    const jaTem = db.all('products').some(p => p.tipo === tipo && Number(p.stage) === 3 && p.variante === 'plus');
    if (jaTem) continue;
    const base = db.all('products').find(p => p.tipo === tipo && Number(p.stage) === 3 && !p.variante);
    if (!base) continue;
    db.insert('products', {
      nome: domain.nomeProduto(tipo, 3, 'plus'),
      tipo, stage: 3, variante: 'plus', rotuloStage: domain.rotuloStage(3, 'plus'),
      comandos: (base.comandos || []).slice(),
      tuchos: ['37'],
      preco: base.preco || 0,
      custoBase: base.custoBase || 0,
      custoBaseAuto: !!base.custoBaseAuto,
      composicao: composicaoSugerida(tipo),
      composicaoConfirmada: false,
      composicaoObs: 'Mesma configuração do Stage 3, com tucho de 37 mm (alojamento aberto).',
      ativo: true
    });
    feitos.criados++;
  }
  if (feitos.criados || feitos.comandoNovo || feitos.configurados || feitos.composicoes) db.persistNow();
  return feitos;
}

/* ---------------------------------------------------------------------
   COMPRA → ESTOQUE PRÓPRIO.

   Cada item da compra pode apontar para um produto do estoque
   (`stockItemId`). Os que apontam entram no estoque sozinhos; os que não
   apontam — serviço de terceiro, manutenção, material consumido na hora —
   não geram nada.

   A função trabalha por DIFERENÇA, comparando o que a compra pede com o
   que ela já movimentou. Isso dá três garantias de uma vez:
     - chamar duas vezes não cria entrada dupla (nada a fazer na segunda);
     - mudar a quantidade de 8 para 10 movimenta só as 2 que faltam;
     - tirar o item da compra devolve a quantidade, sem apagar histórico.  */
function sincronizarEstoqueDaCompra(compra, user) {
  const movs = db.all('stockMoves').filter(m =>
    m.refType === 'purchases' && m.refId === compra.id && !m.estornada);
  const jaMovimentado = {};
  for (const m of movs) {
    const d = m.tipo === 'entrada' ? (Number(m.qtd) || 0) : -(Number(m.qtd) || 0);
    jaMovimentado[m.itemId] = (jaMovimentado[m.itemId] || 0) + d;
  }

  const alvo = {}, custo = {};
  for (const it of compra.itens || []) {
    const id = Number(it.stockItemId) || 0;
    if (!id) continue;
    const q = Number(it.qtd) || 0;
    if (q <= 0) continue;
    alvo[id] = (alvo[id] || 0) + q;
    custo[id] = Number(it.valorUnit) || custo[id] || 0;
  }

  const ids = [...new Set([...Object.keys(alvo), ...Object.keys(jaMovimentado)].map(Number))];
  const efeitos = [];
  for (const id of ids) {
    const diferenca = Math.round(((alvo[id] || 0) - (jaMovimentado[id] || 0)) * 1000) / 1000;
    if (!diferenca) continue;
    const item = db.get('stockItems', id);
    if (!item) continue;
    const unit = custo[id] || 0;
    moveStock(id, diferenca > 0 ? 'entrada' : 'saida', Math.abs(diferenca),
      'purchases', compra.id,
      (diferenca > 0 ? 'Entrada por compra' : 'Ajuste de compra') +
        (compra.fornecedorNome ? ' — ' + compra.fornecedorNome : '') +
        (compra.documentoNumero ? ' — NF ' + compra.documentoNumero : ''),
      user,
      {
        compraId: compra.id, fornecedorId: compra.fornecedorId || null,
        fornecedorNome: compra.fornecedorNome || '',
        documento: compra.documentoNumero || '', documentoTipo: compra.documentoTipo || '',
        data: compra.data || domain.today(),
        custoUnit: unit, custoTotal: Math.round(unit * Math.abs(diferenca) * 100) / 100
      });
    efeitos.push(`${item.nome}: ${diferenca > 0 ? '+' : ''}${diferenca}`);
  }
  return efeitos;
}

/* ===================================================================== */
/* Parser simplificado de NF-e (XML) para leitura automática de compras   */
/* ===================================================================== */

function tag(xml, name) {
  const m = xml.match(new RegExp(`<${name}[^>]*>([\\s\\S]*?)</${name}>`));
  return m ? m[1].trim() : '';
}
function parseNfeXml(xml) {
  try {
    const emit = tag(xml, 'emit');
    const ide = tag(xml, 'ide');
    const out = {
      fornecedorNome: tag(emit, 'xNome'),
      fornecedorCnpj: tag(emit, 'CNPJ'),
      numeroNF: tag(ide, 'nNF'),
      data: (tag(ide, 'dhEmi') || tag(ide, 'dEmi')).slice(0, 10),
      valorTotal: parseFloat(tag(tag(xml, 'ICMSTot'), 'vNF')) || 0,
      itens: [], parcelas: []
    };
    const dets = xml.match(/<det[^>]*>[\s\S]*?<\/det>/g) || [];
    for (const det of dets) {
      out.itens.push({
        descricao: tag(det, 'xProd'),
        qtd: parseFloat(tag(det, 'qCom')) || 1,
        valorUnit: parseFloat(tag(det, 'vUnCom')) || 0,
        total: parseFloat(tag(det, 'vProd')) || 0
      });
    }
    const dups = xml.match(/<dup>[\s\S]*?<\/dup>/g) || [];
    for (const dup of dups) {
      out.parcelas.push({ vencimento: tag(dup, 'dVenc'), valor: parseFloat(tag(dup, 'vDup')) || 0 });
    }
    return out;
  } catch (e) { return null; }
}

/* ===================================================================== */
/* Dashboard                                                             */
/* ===================================================================== */

/** Acesso ao bloco financeiro (faturamento, contas, caixa): perfis com
    financeiro ou dados sensíveis. Produção fica só com o operacional —
    os valores nem são calculados nem enviados. */
function canFinanceiro(user) {
  return can(user, 'cashflow') || can(user, 'finance_sensitive');
}

function dashboard(user) {
  const t = domain.today();
  const month = t.slice(0, 7);
  const inMonth = d => d && String(d).slice(0, 7) === month;

  const sales = db.all('sales').filter(s => s.status !== 'cancelado');
  const os = db.all('serviceOrders');
  const salesMonth = sales.filter(s => inMonth(s.dataPedido));
  const osMonth = os.filter(o => inMonth(o.dataFinalizacao) && !osCancelada(o));

  /* Bloco operacional — o que todo perfil com dashboard enxerga */
  const base = {
    mes: month,
    vendasMes: { qtd: salesMonth.length },
    servicosMes: { qtd: osMonth.length },
    orcamentosAguardando: db.all('quotes').filter(q => q.status === 'aberto').length,
    servicosAndamento: os.filter(o => ['em_analise', 'em_andamento', 'aguardando_peca'].includes(o.status)).length,
    cabecotesAguardandoProducao: db.all('productionOrders').filter(p => p.status === 'nao_produzido').length,
    pedidosAguardandoEnvio: sales.filter(s => ['pronto'].includes(s.status)).length,
    pedidosNaoEntregues: sales.filter(s => !['entregue', 'cancelado'].includes(s.status)).length,
    bensDeClientes: db.all('assets').filter(a => a.status === 'na_empresa').length,
    minhasPendencias: db.all('tasks').filter(tk => tk.status === 'aberta' && (!tk.assigneeId || tk.assigneeId === user.id))
      .sort((a, b) => (a.due || '9999') < (b.due || '9999') ? -1 : 1).slice(0, 20)
  };

  /* Bloco financeiro — calculado apenas para quem pode ver */
  if (canFinanceiro(user)) {
    const receiv = withOverdue(db.all('receivables'));
    const pay = withOverdue(db.all('payables'));
    const flows = db.all('cashflow');
    const faturamentoVendas = salesMonth.reduce((s, v) => s + (v.valorTotal || 0), 0);
    const faturamentoServicos = osMonth.reduce((s, o) => s + (o.valorTotal || 0), 0);
    const fat = faturamentoVendas + faturamentoServicos;
    base.faturamentoMes = fat;
    base.vendasMes.valor = faturamentoVendas;
    base.servicosMes.valor = faturamentoServicos;
    // Parcela recebida em parte entra pelo que ainda falta, nunca pelo total.
    base.contasReceber = receiv.filter(r => aReceber(r) && !emAtraso(r)).reduce((s, r) => s + saldoDaParcela(r), 0);
    base.contasPagar = pay.filter(p => p.status === 'aberto').reduce((s, p) => s + p.valor, 0);
    base.vencidosReceber = receiv.filter(emAtraso).reduce((s, r) => s + saldoDaParcela(r), 0);
    base.vencidosPagar = pay.filter(p => p.status === 'vencida').reduce((s, p) => s + p.valor, 0);
    base.saldoCaixa = flows.reduce((s, f) => s + (f.tipo === 'entrada' ? f.valor : -f.valor), 0);

    if (can(user, 'finance_sensitive')) {
      const custoVendas = salesMonth.reduce((s, v) => s + (domain.saleResult(v).custoReal || 0), 0);
      const lucroEstimado = salesMonth.reduce((s, v) => s + domain.saleResult(v).resultado, 0);
      base.lucroEstimadoMes = lucroEstimado;
      base.margemMes = fat > 0 ? (lucroEstimado / fat) * 100 : 0;
      base.custoVendasMes = custoVendas;
    }
  }
  return base;
}

/* ===================================================================== */
/* Rotas especiais (fluxos de negócio)                                   */
/* ===================================================================== */

const routes = [];
function route(method, pattern, perm, handler) {
  routes.push({ method, regex: new RegExp('^' + pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), perm, handler });
}

/* ---- sessão ---- */
/* Quem está do outro lado da conexão.
   Na nuvem o sistema fica atrás do servidor da hospedagem, e aí toda
   requisição chega com o mesmo endereço — sem isto, o bloqueio por tentativas
   trancaria todo mundo junto. O cabeçalho X-Forwarded-For traz o endereço real,
   mas só é levado em conta quando JAQUES_TRUST_PROXY=1: fora da nuvem qualquer
   um poderia forjá-lo e escapar do bloqueio. */
function clientIp(req) {
  if (process.env.JAQUES_TRUST_PROXY === '1') {
    const xff = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (xff) return xff;
  }
  return req.socket.remoteAddress || '?';
}

/* Proteção contra força bruta: máx. 10 senhas erradas por IP a cada 15 minutos. */
const loginFailures = new Map();
function bruteForceBlocked(ip) {
  const rec = loginFailures.get(ip);
  if (!rec) return false;
  if (Date.now() - rec.first > 15 * 60 * 1000) { loginFailures.delete(ip); return false; }
  return rec.count >= 10;
}
function noteLoginFailure(ip) {
  const rec = loginFailures.get(ip);
  if (rec && Date.now() - rec.first <= 15 * 60 * 1000) rec.count++;
  else loginFailures.set(ip, { count: 1, first: Date.now() });
}

route('POST', '/api/login', null, async (req, res) => {
  const ip = clientIp(req);
  if (bruteForceBlocked(ip)) {
    return send(res, 429, { error: 'Muitas tentativas de login. Aguarde 15 minutos e tente novamente.' });
  }
  const { username, password } = await readBody(req);
  const user = db.all('users').find(u => u.username === String(username || '').toLowerCase().trim());
  if (!user || !checkPassword(password, user.password)) {
    noteLoginFailure(ip);
    return send(res, 401, { error: 'Usuário ou senha inválidos' });
  }
  loginFailures.delete(ip);
  if (!user.active) return send(res, 401, { error: 'Usuário inativo' });
  // Senha certa e cadastro ainda no formato antigo: converte agora, em silêncio.
  if (isLegacyHash(user.password)) db.update('users', user.id, { password: hashPassword(password) });
  // Expira sessões sem uso há mais de 30 dias (quem usa o sistema permanece conectado).
  const cutoff = Date.now() - 30 * 24 * 3600 * 1000;
  for (const s of db.all('sessions').filter(s => new Date(s.lastUsed || s.createdAt).getTime() < cutoff)) {
    db.remove('sessions', s.id);
  }
  const token = crypto.randomBytes(24).toString('hex');
  db.insert('sessions', { token, userId: user.id });
  audit(user, 'login', 'users', user.id, 'Login no sistema');
  ensureRecurringTasks();
  ok(res, {
    token,
    user: { id: user.id, name: user.name, cargo: user.cargo, username: user.username, mustChangePassword: !!user.mustChangePassword },
    permissions: permissionsOf(user)
  });
});

route('POST', '/api/logout', null, async (req, res, user) => {
  const h = req.headers['authorization'] || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : '';
  const s = db.all('sessions').find(x => x.token === token);
  if (s) db.remove('sessions', s.id);
  ok(res, { ok: true });
});

route('GET', '/api/me', 'dashboard', async (req, res, user) => {
  ok(res, { user: { id: user.id, name: user.name, cargo: user.cargo, username: user.username }, permissions: permissionsOf(user) });
});

route('POST', '/api/me/password', 'dashboard', async (req, res, user) => {
  const { atual, nova } = await readBody(req);
  if (!checkPassword(atual, user.password)) return bad(res, 'Senha atual incorreta');
  if (!nova || nova.length < 6) return bad(res, 'A nova senha deve ter ao menos 6 caracteres');
  db.update('users', user.id, { password: hashPassword(nova), mustChangePassword: false });
  audit(user, 'senha', 'users', user.id, 'Alterou a própria senha');
  ok(res, { ok: true });
});

/* ---- metadados p/ frontend ---- */
route('GET', '/api/meta', 'dashboard', async (req, res, user) => {
  ok(res, {
    modules: MODULES,
    stageComandos: domain.STAGE_COMANDOS,
    /* Configuração viva dos cabeçotes: comandos e tuchos saem do cadastro
       do produto, não de uma tabela no código. */
    produtosConfig: db.all('products').map(p => {
      const o = domain.opcoesDoProduto(p);
      return { id: p.id, nome: p.nome, tipo: p.tipo, stage: p.stage, variante: p.variante || '',
        rotuloStage: p.rotuloStage || domain.rotuloStage(p.stage, p.variante),
        comandos: o.comandos, tuchos: o.tuchos, ativo: p.ativo !== false };
    }),
    comandosCadastrados: [...new Set(db.all('products')
      .flatMap(p => domain.opcoesDoProduto(p).comandos))].sort(),
    dreMap: domain.DRE_MAP,
    settings: { quoteValidityDays: db.settings.quoteValidityDays, companyName: db.settings.companyName,
      empresa: db.settings.empresa || {} },
    users: db.all('users').map(u => ({ id: u.id, name: u.name, cargo: u.cargo, active: u.active })),
    roles: db.all('roles').map(r => ({ id: r.id, name: r.name }))
  });
});

route('GET', '/api/meta/tuchos', 'sales', async (req, res, user, params, query) => {
  const prod = query.productId ? db.get('products', query.productId) : null;
  if (prod) return ok(res, { options: domain.opcoesDoProduto(prod).tuchos });
  ok(res, { options: domain.tuchoOptions(query.stage, query.comando) });
});

route('GET', '/api/dashboard', 'dashboard', async (req, res, user) => {
  ensureRecurringTasks();
  ok(res, dashboard(user));
});

/* ---- administração ---- */
route('GET', '/api/users', 'admin', async (req, res) => {
  ok(res, db.all('users').map(u => ({ id: u.id, username: u.username, name: u.name, cargo: u.cargo, roleId: u.roleId, active: u.active })));
});
route('POST', '/api/users', 'admin', async (req, res, user) => {
  const b = await readBody(req);
  if (!b.username || !b.password || !b.name) return bad(res, 'username, password e name são obrigatórios');
  if (db.all('users').some(u => u.username === b.username.toLowerCase())) return bad(res, 'Usuário já existe');
  const rec = db.insert('users', {
    username: b.username.toLowerCase().trim(), password: hashPassword(b.password),
    name: b.name, cargo: b.cargo || '', roleId: Number(b.roleId) || 3, active: b.active !== false, mustChangePassword: true
  });
  audit(user, 'criou', 'users', rec.id, `Usuário ${rec.username}`);
  ok(res, { id: rec.id });
});
route('PUT', '/api/users/:id', 'admin', async (req, res, user, params) => {
  const b = await readBody(req);
  if (Number(params.id) === user.id && b.active === false) {
    return bad(res, 'Você não pode desativar o seu próprio usuário');
  }
  const patch = {};
  for (const k of ['name', 'cargo', 'roleId', 'active']) if (b[k] !== undefined) patch[k] = k === 'roleId' ? Number(b[k]) : b[k];
  if (b.password) { patch.password = hashPassword(b.password); patch.mustChangePassword = true; }
  const rec = db.update('users', params.id, patch);
  if (!rec) return notFound(res);
  audit(user, 'alterou', 'users', rec.id, `Usuário ${rec.username}: ${Object.keys(patch).join(', ')}`);
  ok(res, { ok: true });
});

route('GET', '/api/roles', 'admin', async (req, res) => ok(res, db.all('roles')));
route('POST', '/api/roles', 'admin', async (req, res, user) => {
  const b = await readBody(req);
  const rec = db.insert('roles', { name: b.name || 'Novo perfil', permissions: b.permissions || [] });
  audit(user, 'criou', 'roles', rec.id, rec.name);
  ok(res, rec);
});
route('PUT', '/api/roles/:id', 'admin', async (req, res, user, params) => {
  const b = await readBody(req);
  // O perfil administrador (id 1) nunca pode perder a permissão 'admin' —
  // evita que o sistema fique sem nenhum acesso administrativo.
  if (Number(params.id) === 1 && Array.isArray(b.permissions) && !b.permissions.includes('admin')) {
    return bad(res, 'O perfil Administrador não pode perder a permissão de administração');
  }
  const rec = db.update('roles', params.id, { name: b.name, permissions: b.permissions });
  if (!rec) return notFound(res);
  audit(user, 'alterou', 'roles', rec.id, `Permissões do perfil ${rec.name}`);
  ok(res, rec);
});

route('GET', '/api/audit', 'admin', async (req, res, user, params, query) => {
  let list = db.all('audit').slice().reverse();
  if (query.entity) list = list.filter(a => a.entity === query.entity && String(a.entityId) === String(query.entityId || a.entityId));
  ok(res, list.slice(0, Number(query.limit) || 300));
});

/* Segredos nunca saem do servidor: o GET devolve só máscara.
   Vale para a chave do assistente e para as credenciais da Conta Azul —
   o bloco inteiro sai daqui, e a tela usa /api/contaazul/status. */
function settingsForClient() {
  const s = Object.assign({}, db.settings);
  s.aiKeyMasked = s.aiApiKey ? '••••' + String(s.aiApiKey).slice(-4) : '';
  delete s.aiApiKey;
  delete s.contaazul;
  return s;
}

route('GET', '/api/settings', 'admin', async (req, res) => ok(res, settingsForClient()));
route('PUT', '/api/settings', 'admin', async (req, res, user) => {
  const b = await readBody(req);
  const s = db.settings;
  if (b.quoteValidityDays !== undefined) s.quoteValidityDays = Number(b.quoteValidityDays) || 30;
  if (b.companyName) s.companyName = b.companyName;
  // Dados da empresa (remetente das etiquetas de envio) — cadastrados uma vez
  if (b.empresa && typeof b.empresa === 'object') {
    const e = s.empresa || (s.empresa = {});
    for (const k of ['razaoSocial', 'endereco', 'numero', 'bairro', 'cidade', 'estado', 'complemento', 'telefone']) {
      if (b.empresa[k] !== undefined) e[k] = String(b.empresa[k] || '').slice(0, 120);
    }
    // documentos guardados só com números
    if (b.empresa.cnpj !== undefined) e.cnpj = String(b.empresa.cnpj || '').replace(/\D/g, '').slice(0, 14);
    if (b.empresa.cep !== undefined) e.cep = String(b.empresa.cep || '').replace(/\D/g, '').slice(0, 8);
  }
  if (b.aiProvider !== undefined) s.aiProvider = b.aiProvider === 'claude' ? 'claude' : 'gemini';
  if (b.aiModel !== undefined) s.aiModel = String(b.aiModel || '').trim();
  if (b.aiApiKey === null) s.aiApiKey = '';                       // remoção explícita
  else if (typeof b.aiApiKey === 'string' && b.aiApiKey.trim()) s.aiApiKey = b.aiApiKey.trim();
  let backupAgora = false;
  if (b.backupDir !== undefined) {
    const dir = String(b.backupDir || '').trim();
    if (!dir) { s.backupDir = ''; s.lastCloudBackup = null; }
    else {
      // Valida na hora: cria a pasta (se preciso) e testa a escrita.
      try {
        fs.mkdirSync(dir, { recursive: true });
        const probe = path.join(dir, '.teste-de-escrita-jaques.tmp');
        fs.writeFileSync(probe, 'ok');
        fs.unlinkSync(probe);
      } catch (e) {
        return bad(res, `Não consegui gravar nessa pasta (${e.message}). Confira o caminho — ex.: G:\\Meu Drive\\Backup Jaques Motorsport`);
      }
      backupAgora = dir !== s.backupDir;
      s.backupDir = dir;
    }
  }
  db.save();
  audit(user, 'alterou', 'settings', 1, 'Configurações do sistema');
  if (backupAgora) cloudBackup(true); // primeiro backup imediato — o arquivo já aparece no Drive
  ok(res, settingsForClient());
});

/* ---- backup na nuvem ---- */
route('GET', '/api/backup/status', 'admin', async (req, res) => {
  const localDir = path.join(db.DATA_DIR, 'backups');
  let locais = [];
  try { locais = fs.readdirSync(localDir).filter(f => /^db-\d{4}-\d{2}-\d{2}\.json$/.test(f)).sort(); } catch (e) {}
  ok(res, {
    local: { arquivos: locais.length, ultimo: locais[locais.length - 1] || null },
    cloud: { dir: db.settings.backupDir || '', last: db.settings.lastCloudBackup || null },
    sugestoes: cloudCandidates().map(c => path.join(c, 'Backup Jaques Motorsport'))
  });
});

/* ---- importação da planilha de gastos (Excel semanal) ---- */
/* Layout esperado (o da planilha GASTOS OFICINA): uma aba por semana;
   à esquerda A=data B=descrição C=valor D=nota E=cartão (gastos);
   à direita G=data H=item I=valor J=descrição (entradas).            */

const CAT_SAIDA_REGRAS = [
  [/SALARIO|SAL[AÁ]RIO|ADIANTAMENTO|FGTS|F[EÉ]RIAS|13/, 'salarios'],
  [/IRRF|SIMPLES|IMPOSTO|DARF|\bDAS\b|TRIBUT|INSS/, 'impostos'],
  [/COPEL|ENERGIA/, 'energia'],
  [/SANEPAR|[AÁ]GUA/, 'agua'],
  [/VIVO|CLARO|\bTIM\b|CELULAR|TELEFONE/, 'telefone'],
  [/INTERNET/, 'internet'],
  [/ALUGUEL/, 'aluguel'],
  [/FRETE|RODONAVES|EXPRESSO|CORREIO|TRANSPORTADORA/, 'custo_direto'],
  [/USINAGEM|\bSOLDA\b|RETIFICA|TERCEIR/, 'terceirizacao'],
  [/FERRAMENTA|\bCNC\b|MANUTEN/, 'manutencao'],
  [/MERCADO|LIMPEZA|ESCRITORIO|ESCRIT[OÓ]RIO|PAPELARIA|VIAGEM|GASOLINA|COMBUSTIVEL|COMBUST[IÍ]VEL|MULTA|ANIVERSARIO|HONORARIO|HONOR[AÁ]RIO|CONTAB/, 'despesa_operacional'],
  [/\bJAU\b|RETIFOZ|RETFOZ|FERRAGENS|MANGOPAR|\bOCTA\b|SEDE|VALVULA|V[AÁ]LVULA|GUIA|JUNTA|TUCHO|COMANDO|MOLA|CASCO|PIST[AÃ]O|ANEL|RETENTOR|VEDADOR/, 'componentes']
];
function categoriaSaida(txt) {
  const t = String(txt).toUpperCase();
  for (const [re, cat] of CAT_SAIDA_REGRAS) if (re.test(t)) return cat;
  return 'materiais';
}
function categoriaEntrada(txt) {
  return /VENDA|PEDIDO/i.test(String(txt)) ? 'venda_cabecote' : 'servico';
}

function parseGastosXlsx(buf) {
  const wb = xlsx.parse(buf);
  if (!wb.sheets.length) throw new Error('não encontrei abas na planilha');
  const rows = [], avisos = [];
  const dateOk = v => {
    const d = xlsx.asDate(v);
    return d && d >= '2020-01-01' && d <= '2035-12-31' ? d : null;
  };
  for (const sh of wb.sheets) {
    for (let r = 1; r < sh.rows.length; r++) {
      const row = sh.rows[r] || {};
      // gastos (bloco da esquerda)
      const dA = dateOk(row[0]);
      const desc = typeof row[1] === 'string' ? row[1].trim() : '';
      if (dA && desc) {
        if (typeof row[2] === 'number' && row[2] > 0) {
          rows.push({
            tipo: 'saida', data: dA, origem: desc, valor: Math.round(row[2] * 100) / 100,
            nota: row[3] === true, cartao: row[4] === true, aba: sh.name, categoria: categoriaSaida(desc)
          });
        } else {
          avisos.push(`Aba ${sh.name}: “${desc.slice(0, 40)}” sem valor numérico — ignorada`);
        }
      }
      // entradas (bloco da direita) — exige item preenchido (filtra totais soltos)
      const dG = dateOk(row[6]);
      const item = typeof row[7] === 'string' ? row[7].trim() : '';
      if (dG && item && typeof row[8] === 'number' && row[8] > 0) {
        const extra = typeof row[9] === 'string' && row[9].trim() ? ' — ' + row[9].trim() : '';
        rows.push({
          tipo: 'entrada', data: dG, origem: item + extra, valor: Math.round(row[8] * 100) / 100,
          aba: sh.name, categoria: categoriaEntrada(item)
        });
      }
    }
  }
  // Chave estável por linha: reimportar o mesmo arquivo não duplica nada.
  const seen = {};
  for (const x of rows) {
    const base = `xls|${x.tipo}|${x.data}|${x.valor.toFixed(2)}|${x.origem.toUpperCase().replace(/\s+/g, ' ').slice(0, 120)}`;
    seen[base] = (seen[base] || 0) + 1;
    x.importKey = seen[base] === 1 ? base : `${base}#${seen[base]}`;
  }
  return { rows, avisos };
}

route('POST', '/api/cashflow/import-xlsx', 'cashflow', async (req, res, user) => {
  // Recebe o .xlsx e devolve a análise (nada é gravado nesta etapa).
  const chunks = [];
  let size = 0, aborted = false;
  req.on('data', c => {
    size += c.length;
    if (size > 40 * 1024 * 1024) {
      aborted = true;
      send(res, 413, { error: 'Planilha grande demais (limite: 40 MB)' });
      res.on('finish', () => req.destroy());
      return;
    }
    if (!aborted) chunks.push(c);
  });
  req.on('end', () => {
    if (aborted) return;
    try {
      const { rows, avisos } = parseGastosXlsx(Buffer.concat(chunks));
      const existentes = new Set(db.all('cashflow').map(f => f.importKey).filter(Boolean));
      for (const x of rows) x.jaExiste = existentes.has(x.importKey);
      const soma = list => Math.round(list.reduce((s, x) => s + x.valor, 0) * 100) / 100;
      const saidas = rows.filter(x => x.tipo === 'saida');
      const entradas = rows.filter(x => x.tipo === 'entrada');
      ok(res, {
        rows, avisos,
        resumo: {
          saidas: saidas.length, entradas: entradas.length,
          totalSaidas: soma(saidas), totalEntradas: soma(entradas),
          novos: rows.filter(x => !x.jaExiste).length,
          repetidos: rows.filter(x => x.jaExiste).length,
          novosSaidas: soma(saidas.filter(x => !x.jaExiste)),
          novosEntradas: soma(entradas.filter(x => !x.jaExiste))
        }
      });
    } catch (e) {
      bad(res, 'Não consegui ler a planilha: ' + e.message);
    }
  });
  req.on('error', () => {});
});

route('POST', '/api/cashflow/import-confirm', 'cashflow', async (req, res, user) => {
  const b = await readBody(req);
  const rows = Array.isArray(b.rows) ? b.rows : [];
  const existentes = new Set(db.all('cashflow').map(f => f.importKey).filter(Boolean));
  let inseridos = 0, pulados = 0;
  for (const x of rows) {
    if (!x || (x.tipo !== 'entrada' && x.tipo !== 'saida')) continue;
    const valor = Number(x.valor);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(x.data || '')) || !(valor > 0)) continue;
    const key = String(x.importKey || '').slice(0, 200);
    if (key && existentes.has(key)) { pulados++; continue; }
    db.insert('cashflow', {
      tipo: x.tipo, valor: Math.round(valor * 100) / 100, data: x.data,
      conta: 'principal',
      formaPagamento: x.cartao ? 'cartao_credito' : '',
      categoria: String(x.categoria || (x.tipo === 'saida' ? 'materiais' : 'servico')).slice(0, 40),
      origem: String(x.origem || 'Importado').slice(0, 160),
      documento: x.nota ? 'com NF' : '',
      refType: 'importPlanilha', refId: null,
      descricao: `Importado da planilha${x.aba ? ' (aba ' + String(x.aba).slice(0, 30) + ')' : ''}`,
      importKey: key || null
    });
    if (key) existentes.add(key);
    inseridos++;
  }
  audit(user, 'importou', 'cashflow', null, `Planilha de gastos: ${inseridos} lançamento(s) novos, ${pulados} já existiam`);
  ok(res, { inseridos, pulados });
});

/* ---- modelos 3D (escaneamentos / CAD exportado como malha) ---- */
const MODELS_DIR = path.join(db.DATA_DIR, 'models');
const MODEL_EXTS = ['stl', 'obj', 'ply'];

route('POST', '/api/models3d/upload', 'products', async (req, res, user, params, query) => {
  const nome = String(query.nome || 'modelo').slice(0, 140);
  const ext = (nome.split('.').pop() || '').toLowerCase();
  if (!MODEL_EXTS.includes(ext)) {
    return bad(res, 'Formato não suportado. Exporte do CAD como STL, OBJ ou PLY (no SolidWorks: Salvar como → STL).');
  }
  const MAX = 200 * 1024 * 1024;
  const MSG_GRANDE = 'Arquivo grande demais (limite: 200 MB). Exporte de novo com resolução Média/Medium — fica leve e a diferença visual é imperceptível.';
  // O navegador informa o tamanho antes de enviar: recusa na hora, com mensagem clara.
  const declared = Number(req.headers['content-length'] || 0);
  if (declared > MAX) return send(res, 413, { error: MSG_GRANDE });
  fs.mkdirSync(MODELS_DIR, { recursive: true });
  const fname = Date.now() + '-' + crypto.randomBytes(4).toString('hex') + '.' + ext;
  const fpath = path.join(MODELS_DIR, fname);
  let size = 0, aborted = false;
  const ws = fs.createWriteStream(fpath);
  req.on('data', chunk => {
    if (aborted) return;
    size += chunk.length;
    if (size > MAX) {
      aborted = true;
      ws.destroy();
      fs.unlink(fpath, () => {});
      send(res, 413, { error: MSG_GRANDE });
      res.on('finish', () => req.destroy()); // deixa a resposta chegar antes de derrubar
      return;
    }
    ws.write(chunk);
  });
  req.on('end', () => {
    if (aborted) return;
    ws.end(() => {
      const rec = db.insert('models3d', {
        nome, arquivo: fname, ext, size,
        produtoId: query.produtoId ? Number(query.produtoId) : null,
        criadoEm: new Date().toISOString()
      });
      audit(user, 'criou', 'models3d', rec.id, `Modelo 3D ${nome} (${(size / 1048576).toFixed(1)} MB)`);
      ok(res, rec);
    });
  });
  req.on('error', () => { aborted = true; ws.destroy(); fs.unlink(fpath, () => {}); });
});

route('GET', '/api/models3d', 'dashboard', async (req, res) => ok(res, db.all('models3d')));

route('PUT', '/api/models3d/:id', 'products', async (req, res, user, params) => {
  const b = await readBody(req);
  const patch = {};
  if (b.nome) patch.nome = String(b.nome).slice(0, 140);
  if (b.produtoId !== undefined) patch.produtoId = b.produtoId ? Number(b.produtoId) : null;
  const rec = db.update('models3d', params.id, patch);
  if (!rec) return notFound(res);
  audit(user, 'alterou', 'models3d', rec.id, rec.nome);
  ok(res, rec);
});

route('DELETE', '/api/models3d/:id', 'products', async (req, res, user, params) => {
  const m = db.get('models3d', params.id);
  if (!m) return notFound(res);
  fs.unlink(path.join(MODELS_DIR, m.arquivo), () => {});
  db.remove('models3d', m.id);
  audit(user, 'excluiu', 'models3d', m.id, m.nome);
  ok(res, { ok: true });
});

route('GET', '/api/models3d/:id/file', 'dashboard', async (req, res, user, params) => {
  const m = db.get('models3d', params.id);
  if (!m) return notFound(res);
  const fpath = path.join(MODELS_DIR, m.arquivo);
  if (!fs.existsSync(fpath)) return notFound(res);
  res.writeHead(200, {
    'Content-Type': 'application/octet-stream',
    'Content-Length': fs.statSync(fpath).size,
    'Cache-Control': 'no-cache'
  });
  fs.createReadStream(fpath).pipe(res);
});

/* ---- acesso pelo celular: endereços do computador na rede local ---- */
route('GET', '/api/network', 'admin', async (req, res) => {
  const ips = [];
  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const ni of nets[name] || []) {
      if (ni.family === 'IPv4' && !ni.internal && !ni.address.startsWith('169.254.')) ips.push(ni.address);
    }
  }
  // redes domésticas primeiro (192.168.x.x é o caso comum de Wi-Fi)
  ips.sort((a, b) => (b.startsWith('192.168.') ? 1 : 0) - (a.startsWith('192.168.') ? 1 : 0));
  ok(res, { port: PORT, ips });
});

route('POST', '/api/backup/now', 'admin', async (req, res, user) => {
  ensureDailyBackup();
  const r = cloudBackup(true);
  audit(user, 'backup', 'settings', 1, r.ok ? `Backup manual → ${r.file}` : `Backup manual falhou: ${r.error || 'nuvem não configurada'}`);
  ok(res, r);
});

/* Baixa o banco inteiro como um arquivo só.
   É o backup que dá para guardar fora do sistema — e é assim que os dados
   saem de um computador para entrar em outro (ou na nuvem). */
route('GET', '/api/backup/download', 'admin', async (req, res, user) => {
  db.persistNow();
  const conteudo = fs.readFileSync(db.DB_FILE);
  const nome = `jaques-backup-${new Date().toISOString().slice(0, 10)}.json`;
  audit(user, 'backup', 'settings', 1, 'Backup baixado');
  res.writeHead(200, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Disposition': `attachment; filename="${nome}"`,
    'Content-Length': conteudo.length
  });
  res.end(conteudo);
});

/* Restaura um backup por cima do banco atual.
   Antes de trocar qualquer coisa, o banco de agora é guardado em
   data/backups — se o arquivo enviado estiver errado, nada se perde. */
route('POST', '/api/backup/restore', 'admin', async (req, res, user) => {
  const corpo = await readBody(req);
  const novo = corpo && corpo.banco;
  if (!novo || typeof novo !== 'object' || Array.isArray(novo)) {
    return bad(res, 'Arquivo inválido: não parece um backup do sistema.');
  }
  if (!Array.isArray(novo.users) || !novo.users.length) {
    return bad(res, 'Arquivo inválido: nenhum usuário dentro dele. Um backup sem usuários deixaria o sistema sem ninguém para entrar.');
  }
  const faltando = ['clients', 'settings'].filter(c => !Array.isArray(novo[c]));
  if (faltando.length) return bad(res, `Arquivo inválido: faltam as tabelas ${faltando.join(', ')}.`);

  const backupDir = path.join(db.DATA_DIR, 'backups');
  fs.mkdirSync(backupDir, { recursive: true });
  const salvaguarda = path.join(backupDir, `antes-da-restauracao-${Date.now()}.json`);
  db.persistNow();
  if (fs.existsSync(db.DB_FILE)) fs.copyFileSync(db.DB_FILE, salvaguarda);

  for (const c of db.COLLECTIONS) if (!Array.isArray(novo[c])) novo[c] = [];
  if (!novo._seq) novo._seq = {};
  const tmp = db.DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(novo, null, 1));
  fs.renameSync(tmp, db.DB_FILE);
  db.reload();
  garantirCodigosDeCliente(); // backup de uma versão sem código não fica sem ele

  console.log('Banco restaurado. Cópia do anterior:', salvaguarda);
  audit(user, 'restore', 'settings', 1,
    `Backup restaurado por ${user.name} — cópia do anterior em ${path.basename(salvaguarda)}`);
  ok(res, {
    ok: true,
    salvaguarda: path.basename(salvaguarda),
    usuarios: novo.users.length,
    clientes: novo.clients.length
  });
});

/* ================= Conta Azul — conexão oficial (OAuth 2.0) =================
   O Client Secret e os tokens nunca saem do servidor. O navegador só recebe
   o estado da conexão e o endereço para onde deve mandar o usuário. */

route('GET', '/api/contaazul/status', 'admin', async (req, res) => {
  ok(res, contaazul.status());
});

route('PUT', '/api/contaazul/config', 'admin', async (req, res, user) => {
  const b = await readBody(req);
  const c = contaazul.config();
  // Antes de sobrescrever a credencial, guarda a anterior. Se um
  // preenchimento automático do navegador (ou um engano) passar por cima,
  // o valor antigo continua recuperável em data/db.json → contaazul.anteriores.
  for (const k of ['clientId', 'clientSecret']) {
    const novo = typeof b[k] === 'string' ? b[k].trim() : '';
    if (novo && c[k] && novo !== c[k]) {
      (c.anteriores = c.anteriores || {})[k] = { valor: c[k], em: new Date().toISOString() };
    }
  }
  if (typeof b.clientId === 'string' && b.clientId.trim()) c.clientId = b.clientId.trim();
  if (typeof b.clientSecret === 'string' && b.clientSecret.trim()) c.clientSecret = b.clientSecret.trim();
  if (typeof b.redirectUri === 'string' && b.redirectUri.trim()) c.redirectUri = b.redirectUri.trim();
  // Campos avançados: em branco volta ao padrão.
  for (const k of ['autorizarUrl', 'tokenUrl', 'apiBase', 'escopo']) {
    if (typeof b[k] === 'string') c[k] = b[k].trim();
  }
  db.save();
  audit(user, 'update', 'settings', 1, 'Credenciais da Conta Azul atualizadas');
  ok(res, contaazul.status());
});

/* Devolve o endereço da tela de autorização da Conta Azul. Quem abre é o
   navegador do usuário — o servidor nunca vê a senha da Conta Azul. */
route('POST', '/api/contaazul/connect', 'admin', async (req, res) => {
  if (!contaazul.configurado()) {
    return bad(res, 'Preencha antes o Client ID, o Client Secret e o endereço de retorno.');
  }
  ok(res, { url: contaazul.urlAutorizacao() });
});

/* Para onde a Conta Azul devolve o usuário depois de autorizar.
   Quem chega aqui é o navegador, vindo de fora e sem token do sistema — por
   isso a rota é aberta, e quem faz o papel de credencial é o "state", que só
   este servidor gerou e que vale uma vez só. */
async function contaazulRetorno(req, res, query) {
  const pagina = (titulo, corpo, cor) => send(res, 200, `<!DOCTYPE html><html lang="pt-BR"><head>
    <meta charset="utf-8"><title>Conta Azul — ${titulo}</title>
    <style>body{font:15px/1.5 system-ui,sans-serif;background:#0b0b0c;color:#ededea;
      display:grid;place-items:center;height:100vh;margin:0;text-align:center}
      .cx{max-width:460px;padding:32px;border:1px solid #26262b;border-radius:16px;background:#121214}
      h1{font-size:19px;margin:0 0 10px;color:${cor}} p{color:#9a9aa1;margin:0 0 16px}
      a{color:#e43146}</style></head><body><div class="cx">
    <h1>${titulo}</h1>${corpo}
    <p><a href="/#/admin">Voltar ao sistema</a></p></div></body></html>`,
    { 'Content-Type': 'text/html; charset=utf-8' });

  if (query.error) {
    return pagina('Autorização não concluída',
      `<p>A Conta Azul respondeu: <b>${esc(query.error_description || query.error)}</b></p>`, '#e43146');
  }
  if (!contaazul.consumirState(query.state)) {
    return pagina('Retorno não reconhecido',
      '<p>Este retorno não corresponde a nenhum pedido de conexão feito aqui, ou demorou mais de 10 minutos. Comece de novo pelo botão <b>Conectar</b>.</p>', '#e43146');
  }
  if (!query.code) {
    return pagina('Retorno incompleto', '<p>A Conta Azul não enviou o código de autorização.</p>', '#e43146');
  }
  try {
    await contaazul.trocarCodigo(query.code);
    try {
      const eu = await contaazul.quemSou();
      const c = contaazul.config();
      c.conta = { nome: eu.name || eu['cognito:username'] || '', email: eu.email || '' };
      db.save();
    } catch (e) { /* conectou; só não deu para descobrir o nome da conta */ }
    audit({ id: 0, name: 'sistema' }, 'update', 'settings', 1, 'Conta Azul conectada');
    return pagina('Conta Azul conectada',
      '<p>Pode fechar esta aba e voltar ao sistema.</p>', '#3fb950');
  } catch (e) {
    const c = contaazul.config();
    c.ultimoErro = e.message;
    db.save();
    return pagina('Não consegui concluir', `<p>${esc(e.message)}</p>`, '#e43146');
  }
}
route('GET', '/api/contaazul/callback', null, async (req, res, user, params, query) =>
  contaazulRetorno(req, res, query));

/* Conclui a autorização a partir do código colado à mão.
   É o caminho para quando o app está cadastrado para voltar no site da
   Conta Azul em vez de aqui: o usuário copia o endereço da barra do
   navegador, que traz "?code=…", e cola. */
route('POST', '/api/contaazul/codigo', 'admin', async (req, res, user) => {
  const b = await readBody(req);
  const code = contaazul.codigoDe(b.texto);
  if (!code) {
    return bad(res, 'Não achei o código nesse texto. Cole o endereço inteiro da barra do navegador, aquele que tem "code=".');
  }
  try {
    await contaazul.trocarCodigo(code);
    try {
      const eu = await contaazul.quemSou();
      const c = contaazul.config();
      c.conta = { nome: eu.name || eu['cognito:username'] || '', email: eu.email || '' };
      db.save();
    } catch (e) { /* conectou; só não deu para descobrir o nome da conta */ }
    audit(user, 'update', 'settings', 1, 'Conta Azul conectada (código colado)');
    ok(res, { ok: true, status: contaazul.status() });
  } catch (e) {
    /* De propósito não grava o erro: gravar mexe nos dados, a tela se
       redesenha sozinha e o painel com o campo do código some — e o código
       vale só 3 minutos. O erro volta na resposta, que é o que importa. */
    ok(res, { ok: false, error: e.message });
  }
});

/* Conecta com um refresh token colado à mão — o exemplo de cURL do portal
   traz um pronto para o app de desenvolvimento. É a conexão definitiva sem
   a corrida dos 3 minutos: valida na hora, renovando de verdade. */
route('POST', '/api/contaazul/refresh-manual', 'admin', async (req, res, user) => {
  const b = await readBody(req);
  const token = String(b.token || '').trim();
  if (token.length < 20) return bad(res, 'Cole o refresh_token completo, como está no exemplo de cURL do portal.');
  contaazul.refreshManual(token);
  try {
    await contaazul.renovar();               // prova real: gera o primeiro access token
    try {
      const eu = await contaazul.quemSou();
      const c = contaazul.config();
      c.conta = { nome: eu.name || eu['cognito:username'] || '', email: eu.email || '' };
      db.save();
    } catch (e) { /* conectou; só não deu para descobrir o nome da conta */ }
    audit(user, 'update', 'settings', 1, 'Conta Azul conectada (refresh token do portal)');
    ok(res, { ok: true, status: contaazul.status() });
  } catch (e) {
    ok(res, { ok: false, error: e.message });
  }
});

/* O portal da Conta Azul mostra o token do app de desenvolvimento uma única
   vez. Guardar aqui permite explorar a API da conta de teste enquanto a
   autorização completa não está concluída. */
route('POST', '/api/contaazul/token-manual', 'admin', async (req, res, user) => {
  const b = await readBody(req);
  const token = String(b.token || '').trim();
  if (token.length < 20) return bad(res, 'Cole o access_token completo, do jeito que o portal mostrou.');
  contaazul.tokenManual(token, b.minutos);
  audit(user, 'update', 'settings', 1, 'Conta Azul — token de teste guardado');
  ok(res, contaazul.status());
});

route('POST', '/api/contaazul/test', 'admin', async (req, res) => {
  try {
    // A prova real da conexão é obter um token válido (renova se preciso).
    await contaazul.tokenValido();
    const c = contaazul.config();
    try {
      const eu = await contaazul.quemSou();
      c.conta = { nome: eu.name || eu['cognito:username'] || '', email: eu.email || '' };
    } catch (e) { /* identificação é cortesia; a conexão está de pé */ }
    c.ultimoErro = '';
    db.save();
    ok(res, { ok: true, conta: c.conta || null });
  } catch (e) {
    ok(res, { ok: false, error: e.message });
  }
});

route('POST', '/api/contaazul/disconnect', 'admin', async (req, res, user) => {
  contaazul.desconectar();
  audit(user, 'update', 'settings', 1, 'Conta Azul desconectada');
  ok(res, contaazul.status());
});

/* Ferramenta de leitura, para conferirmos junto o formato real de cada
   recurso antes de escrever a sincronização. Só GET e só administrador:
   não altera nada na Conta Azul. */
route('POST', '/api/contaazul/explorar', 'admin', async (req, res, user) => {
  const b = await readBody(req);
  const caminho = String(b.caminho || '').trim();
  if (!caminho.startsWith('/')) return bad(res, 'Informe o caminho do recurso, começando com "/".');
  try {
    const r = await contaazul.chamar(caminho, { method: 'GET' });
    audit(user, 'view', 'settings', 1, `Conta Azul — leitura de ${caminho}`);
    ok(res, { status: r.status, corpo: r.json !== null ? r.json : String(r.text || '').slice(0, 4000) });
  } catch (e) {
    ok(res, { status: 0, erro: e.message });
  }
});

/* ---- sincronização real: Clientes → Pessoas ---- */

/* Sonda o formato + mostra o que iria. Nada é enviado. */
route('POST', '/api/contaazul/sync/clientes/ensaio', 'admin', async (req, res, user) => {
  const ensaio = casync.ensaioClientes({ amostra: 5 });
  let sonda = null;
  try { sonda = await casync.sondarPessoas(); }
  catch (e) { sonda = { status: 0, corpo: e.message }; }
  audit(user, 'view', 'settings', 1, 'Conta Azul — ensaio de envio de clientes');
  ok(res, Object.assign({ sonda }, ensaio));
});

/* Envia de verdade. { limite: 1 } é o teste com um cliente só. */
route('POST', '/api/contaazul/sync/clientes/enviar', 'admin', async (req, res, user) => {
  const b = await readBody(req);
  const r = await casync.enviarClientes({ ids: b.ids, limite: b.limite });
  audit(user, 'update', 'settings', 1,
    `Conta Azul — envio de clientes: ${r.enviados} ok, ${r.falhas} falha(s)`);
  ok(res, r);
});

/* ---- integrações externas (preparação p/ Conta Azul) ----
   Só leitura do estado de sincronização; nenhuma chamada externa ainda. */
/* O plano de sincronização: o que iria, para onde, e o que já foi.
   É calculado só com dados locais — não toca na Conta Azul. */
/* Consulta de vínculos antes de excluir — a tela usa isto para avisar
   exatamente o que está preso ao cadastro. */
route('GET', '/api/vinculos/:colecao/:id', 'dashboard', async (req, res, user, params) => {
  const col = params.colecao;
  if (!REST[col]) return notFound(res);
  if (!can(user, REST[col].perm)) return forbidden(res);
  const rec = db.get(col, params.id);
  if (!rec) return notFound(res);
  const vinc = vinculosDe(col, params.id);
  ok(res, {
    vinculos: vinc,
    total: vinc.reduce((s, v) => s + v.qtd, 0),
    podeInativar: !!INATIVAVEIS[col],
    campoAtivo: INATIVAVEIS[col] || null,
    ativo: INATIVAVEIS[col] ? rec[INATIVAVEIS[col]] !== false : null
  });
});

route('GET', '/api/sync/plano', 'admin', async (req, res) => {
  ok(res, {
    sistema: 'contaazul',
    conectado: contaazul.conectado(),
    sentidos: sync.SENTIDOS,
    tipos: sync.plano('contaazul')
  });
});

route('PUT', '/api/sync/config', 'admin', async (req, res, user) => {
  const b = await readBody(req);
  try {
    sync.definirSentido(String(b.entidade || ''), String(b.sentido || ''));
  } catch (e) { return bad(res, e.message); }
  audit(user, 'update', 'settings', 1, `Sincronização: ${b.entidade} → ${b.sentido}`);
  ok(res, { sistema: 'contaazul', conectado: contaazul.conectado(), sentidos: sync.SENTIDOS, tipos: sync.plano('contaazul') });
});

/* ---- etiquetas de envio: registro de emissão (vínculo com pedido/OS) ---- */
route('POST', '/api/labels', 'dashboard', async (req, res, user) => {
  const b = await readBody(req);
  const origem = b.origem === 'serviceOrders' ? 'serviceOrders' : 'sales';
  const refId = Number(b.refId) || null;
  const rec = db.insert('labels', {
    origem, refId, ref: String(b.ref || '').slice(0, 60),
    clienteId: b.clienteId ? Number(b.clienteId) : null,
    emitidaEm: new Date().toISOString(), emitidaPor: user.name
  });
  // marca no próprio pedido/OS e deixa rastro na linha do tempo
  const doc = refId ? db.get(origem, refId) : null;
  if (doc) db.update(origem, refId, { etiquetaEmitidaEm: rec.emitidaEm });
  audit(user, 'etiqueta', origem, refId, `Etiqueta de envio gerada — ${rec.ref}`);
  ok(res, rec);
});

route('GET', '/api/labels', 'dashboard', async (req, res) => ok(res, db.all('labels').slice(-100)));

/* ---- sinal de alteração: as telas abertas se atualizam sozinhas ----
   /api/events mantém uma conexão aberta e avisa NA HORA que alguém
   alterou algo. /api/rev fica como reserva, caso a conexão caia. */
route('GET', '/api/rev', 'dashboard', async (req, res) => ok(res, { rev: db.rev() }));

const liveClients = new Set();
route('GET', '/api/events', 'dashboard', async (req, res) => {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'X-Accel-Buffering': 'no'
  });
  res.write('retry: 5000\n\n');
  res.write(`data: {"rev":${db.rev()}}\n\n`);
  const cli = { res };
  liveClients.add(cli);
  req.on('close', () => liveClients.delete(cli));
  req.on('error', () => liveClients.delete(cli));
});

/* Vigia o contador de alterações e avisa todas as telas conectadas. */
let lastBroadcast = db.rev();
let keepAliveTick = 0;
setInterval(() => {
  if (!liveClients.size) { lastBroadcast = db.rev(); return; }
  const r = db.rev();
  const mudou = r !== lastBroadcast;
  if (mudou) lastBroadcast = r;
  keepAliveTick++;
  const msg = mudou ? `data: {"rev":${r}}\n\n` : (keepAliveTick % 25 === 0 ? ': ping\n\n' : null);
  if (!msg) return;
  for (const cli of [...liveClients]) {
    try { cli.res.write(msg); } catch (e) { liveClients.delete(cli); }
  }
}, 700);

/* ---- pendências: individuais por padrão ---- */
/* Cada um recebe as SUAS pendências, as sem dono (pode assumir) e as que
   ele mesmo delegou a outros. Só quem tem 'admin' enxerga o quadro da
   equipe inteira. */
route('GET', '/api/tasks', 'tasks', async (req, res, user) => {
  let list = db.all('tasks');
  if (!can(user, 'admin')) {
    list = list.filter(t => !t.assigneeId || t.assigneeId === user.id || t.criadoPorId === user.id);
  }
  ok(res, list);
});

route('POST', '/api/tasks', 'tasks', async (req, res, user) => {
  const b = await readBody(req);
  if (!b.titulo || !String(b.titulo).trim()) return bad(res, 'Dê um título à pendência');
  const rec = db.insert('tasks', {
    titulo: String(b.titulo).slice(0, 200),
    descricao: String(b.descricao || '').slice(0, 600),
    prioridade: ['urgente', 'semana', 'normal', 'aguardando'].includes(b.prioridade) ? b.prioridade : 'normal',
    assigneeId: b.assigneeId ? Number(b.assigneeId) : null,
    due: b.due || '',
    link: String(b.link || '').slice(0, 300),
    origem: String(b.origem || 'manual').slice(0, 60),
    status: 'aberta',
    criadoPorId: user.id,
    criadoPorNome: user.name
  });
  const paraQuem = rec.assigneeId ? (db.get('users', rec.assigneeId) || {}).name : null;
  audit(user, 'criou', 'tasks', rec.id, rec.titulo + (paraQuem ? ` → atribuída a ${paraQuem}` : ''));
  ok(res, rec);
});

/* ---- assistente de IA ---- */

/**
 * Monta um retrato compacto dos dados para a IA responder perguntas.
 * Cada bloco só entra se o usuário tiver permissão no módulo — o mesmo
 * controle das telas vale para o assistente (Produção não vê financeiro).
 */
function assistantContext(user) {
  const t = domain.today();
  const month = t.slice(0, 7);
  const money = v => Math.round((v || 0) * 100) / 100;
  const fin = can(user, 'finance_sensitive');
  const ctx = {
    hoje: t,
    empresa: db.settings.companyName,
    usuario: { nome: user.name, cargo: user.cargo || '' }
  };

  const d = dashboard(user);
  ctx.resumoDoMes = {
    mes: d.mes, faturamento: money(d.faturamentoMes),
    vendas: d.vendasMes, servicos: d.servicosMes,
    orcamentosAguardando: d.orcamentosAguardando,
    servicosEmAndamento: d.servicosAndamento,
    cabecotesAguardandoProducao: d.cabecotesAguardandoProducao,
    pedidosNaoEntregues: d.pedidosNaoEntregues,
    bensDeClientesNaEmpresa: d.bensDeClientes
  };
  if (fin) {
    ctx.resumoDoMes.lucroEstimado = money(d.lucroEstimadoMes);
    ctx.resumoDoMes.margemPct = money(d.margemMes);
  }

  if (can(user, 'tasks')) {
    ctx.pendenciasAbertas = db.all('tasks').filter(x => x.status === 'aberta')
      .sort((a, b) => ((a.due || '9999') < (b.due || '9999') ? -1 : 1)).slice(0, 25)
      .map(x => ({ titulo: x.titulo, prioridade: x.prioridade, prazo: x.due || '', responsavel: x.assigneeId ? ((db.get('users', x.assigneeId) || {}).name || '') : 'todos' }));
  }

  if (can(user, 'clients')) {
    const clients = db.all('clients');
    ctx.clientes = {
      total: clients.length,
      lista: clients.slice(0, 150).map(c => ({ nome: c.nome, cidade: c.cidade || '', estado: c.estado || '', telefone: c.telefone || '' }))
    };
  }

  if (can(user, 'quotes')) {
    ctx.orcamentosAbertos = db.all('quotes').filter(q => q.status === 'aberto').slice(-20)
      .map(q => ({ numero: q.numero, cliente: (db.get('clients', q.clienteId) || {}).nome || '', modelo: q.modelo || '', valor: money(q.total), data: q.dataOrcamento }));
  }

  if (can(user, 'sales')) {
    ctx.vendasRecentes = db.all('sales').filter(s => s.status !== 'cancelado').slice(-15)
      .map(s => ({ numero: s.numero, cliente: (db.get('clients', s.clienteId) || {}).nome || '', valor: money(s.valorTotal), status: s.status, data: s.dataPedido,
        itens: (s.itens || []).map(i => `${i.produto || ''} ${i.stage || ''}`.trim()).join(' + ') }));
  }

  if (can(user, 'os')) {
    ctx.ordensDeServicoAtivas = db.all('serviceOrders')
      .filter(o => ['em_analise', 'em_andamento', 'aguardando_peca', 'aguardando_pagamento'].includes(o.status)).slice(-20)
      .map(o => ({ numero: o.numero, cliente: (db.get('clients', o.clienteId) || {}).nome || '', modelo: o.modelo || '', status: o.status, valor: money(o.valorTotal) }));
  }

  if (can(user, 'production')) {
    ctx.producaoPendente = db.all('productionOrders').filter(p => p.status !== 'pronto').slice(-20)
      .map(p => ({ pedido: p.pedidoNumero, cliente: p.clienteNome, produto: `${p.tipo || ''} ${p.stage || ''}`.trim(), comando: p.comando, tucho: p.tucho, status: p.status, previsao: p.previsaoEntrega || '' }));
  }

  if (can(user, 'stock')) {
    const items = db.all('stockItems');
    ctx.estoque = items.slice(0, 80).map(i => ({ item: i.nome, qtd: i.qtd || 0, minimo: i.minimo || 0, abaixoDoMinimo: (i.qtd || 0) < (i.minimo || 0) }));
  }

  if (can(user, 'payables')) {
    const pays = withOverdue(db.all('payables')).filter(p => p.status === 'aberto' || p.status === 'vencida')
      .sort((a, b) => (a.vencimento < b.vencimento ? -1 : 1));
    ctx.contasAPagar = {
      totalEmAberto: money(pays.reduce((s, p) => s + p.valor, 0)),
      vencidas: money(pays.filter(p => p.status === 'vencida').reduce((s, p) => s + p.valor, 0)),
      proximas: pays.slice(0, 20).map(p => ({ descricao: p.descricao, valor: money(p.valor), vencimento: p.vencimento, pagarNoDia: p.dataProgramada || '', status: p.status }))
    };
  }

  if (can(user, 'receivables')) {
    const recs = withOverdue(db.all('receivables')).filter(aReceber)
      .sort((a, b) => (a.vencimento < b.vencimento ? -1 : 1));
    ctx.contasAReceber = {
      totalEmAberto: money(recs.reduce((s, r) => s + saldoDaParcela(r), 0)),
      vencidas: money(recs.filter(emAtraso).reduce((s, r) => s + saldoDaParcela(r), 0)),
      proximas: recs.slice(0, 20).map(r => ({ descricao: r.descricao, cliente: (db.get('clients', r.clienteId) || {}).nome || '', valor: money(saldoDaParcela(r)), vencimento: r.vencimento, status: r.status }))
    };
  }

  if (can(user, 'cashflow')) {
    const flows = db.all('cashflow');
    ctx.caixa = {
      saldoAtual: money(flows.reduce((s, f) => s + (f.tipo === 'entrada' ? f.valor : -f.valor), 0)),
      ultimosLancamentos: flows.slice(-12).map(f => ({ data: f.data, tipo: f.tipo, valor: money(f.valor), categoria: f.categoria, origem: f.origem }))
    };
  }

  if (can(user, 'projection')) {
    const proj = domain.projection(t);
    ctx.projecao = proj.janelas.map(j => ({ dias: j.dias, aReceber: money(j.aReceber), aPagar: money(j.aPagar), saldoProjetado: money(j.saldoProjetado) }));
  }

  if (can(user, 'suppliers')) {
    const exps = db.all('supplierExpenses').filter(e => String(e.data || '').slice(0, 7) === month);
    ctx.fornecedoresGastoNoMes = db.all('suppliers').map(f => ({
      fornecedor: f.nome,
      gastoNoMes: money(exps.filter(e => e.fornecedorId === f.id).reduce((s, e) => s + (e.valor || 0), 0))
    })).filter(x => x.gastoNoMes > 0);
  }

  if (can(user, 'hr')) {
    ctx.equipe = db.all('employees').filter(e => e.ativo !== false)
      .map(e => fin ? { nome: e.nome, cargo: e.cargo || '', salario: money(e.salario) } : { nome: e.nome, cargo: e.cargo || '' });
  }

  if (fin && can(user, 'dre')) {
    const r = domain.dre(month);
    ctx.dreDoMes = {
      receitaCaixa: money(r.receita.total), custos: money(r.custos.total), lucroBruto: money(r.lucroBruto),
      despesasOperacionais: money(r.despesasOperacionais.total), despesasFinanceiras: money(r.despesasFinanceiras.total),
      lucroLiquido: money(r.lucroLiquido), margemLiquidaPct: money(r.margemLiquida),
      receitaCompetencia: money(r.receitaCompetencia.total)
    };
  }

  return ctx;
}

function assistantSystemPrompt(user) {
  const fin = can(user, 'finance_sensitive');
  const dias = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];
  const hoje = domain.today();
  const diaSemana = dias[domain.parseDay(hoje).getDay()];
  return `Você é o assistente interno do sistema de gestão da ${db.settings.companyName} — empresa de cabeçotes de alta performance (venda de cabeçotes prontos Unilateral/Crossflow Stage 1 a 3, serviços de preparação e retrabalho de cabeçotes de clientes).
Hoje é ${diaSemana}, ${hoje.split('-').reverse().join('/')}.
Quem pergunta: ${user.name}${user.cargo ? ' (' + user.cargo + ')' : ''}.

REGRAS:
- Responda SEMPRE em português do Brasil, direto e claro, como um colega de trabalho prestativo.
- Use SOMENTE os dados do JSON abaixo. NUNCA invente números, clientes, datas ou valores.
- Dinheiro no formato R$ 1.234,56 e datas no formato dd/mm/aaaa.
- Para listas, use marcadores; para comparações com vários números, use tabela markdown simples.
- Se os dados fornecidos não respondem à pergunta, diga isso e indique em qual tela do sistema a pessoa encontra (ex.: "veja em Financeiro → Contas a pagar").
- Perguntas sobre como usar o sistema: explique com base nos módulos listados.
- Nos pagamentos programados, a empresa paga às sextas-feiras: a data de pagamento é a sexta anterior ao vencimento.${fin ? '' : `
- O perfil deste usuário NÃO tem acesso a custos, margens, salários e resultados. Se perguntarem sobre isso, explique educadamente que o perfil de acesso não permite ver dados financeiros sensíveis.`}

MÓDULOS DO SISTEMA: Dashboard, Análises (gráficos), Minhas pendências, Clientes, Orçamentos, Vendas/Pedidos, Entrada de cabeçotes, Bens de clientes, Ordens de serviço, Produção, Estoque próprio, Produtos e custos, Compras (com leitura de NF-e), Fornecedores (fechamento mensal), Contas a pagar (agenda de sextas-feiras), Contas a receber (boletos parcelados), Fluxo de caixa, Projeção, DRE, RH, Relatórios (impressão), Administração.

DADOS ATUAIS DO SISTEMA (JSON):
${JSON.stringify(assistantContext(user))}`;
}

route('GET', '/api/assistant/status', 'dashboard', async (req, res, user) => {
  ok(res, {
    configured: !!db.settings.aiApiKey,
    provider: db.settings.aiProvider || 'gemini',
    canConfigure: can(user, 'admin')
  });
});

route('POST', '/api/assistant', 'dashboard', async (req, res, user) => {
  const b = await readBody(req);
  const question = String(b.question || '').trim().slice(0, 2000);
  if (!question) return bad(res, 'Escreva uma pergunta');
  if (!db.settings.aiApiKey) {
    return bad(res, 'O assistente ainda não foi configurado. Peça a um administrador para cadastrar a chave da API em Administração → Configurações.');
  }
  // Histórico curto para dar continuidade à conversa sem estourar o contexto.
  const history = (Array.isArray(b.history) ? b.history : []).slice(-8)
    .filter(m => m && typeof m.text === 'string' && m.text.trim())
    .map(m => ({ role: m.role === 'assistant' ? 'assistant' : 'user', text: String(m.text).slice(0, 4000) }));
  const messages = history.concat([{ role: 'user', text: question }]);
  try {
    const r = await ai.ask(
      { provider: db.settings.aiProvider || 'gemini', key: db.settings.aiApiKey, model: db.settings.aiModel },
      assistantSystemPrompt(user), messages
    );
    audit(user, 'assistente', 'assistant', null, question.slice(0, 140));
    ok(res, { answer: r.text, model: r.model });
  } catch (e) {
    send(res, 502, { error: e.message });
  }
});

/* Testa a chave (a informada no corpo ou a já salva) sem precisar salvar antes. */
route('POST', '/api/assistant/test', 'admin', async (req, res, user) => {
  const b = await readBody(req);
  const cfg = {
    provider: (b.provider || db.settings.aiProvider) === 'claude' ? 'claude' : 'gemini',
    key: (typeof b.key === 'string' && b.key.trim()) ? b.key.trim() : db.settings.aiApiKey,
    model: b.model !== undefined ? b.model : db.settings.aiModel
  };
  if (!cfg.key) return bad(res, 'Informe a chave da API (ou salve uma antes de testar)');
  try {
    const r = await ai.ask(cfg, 'Você é um assistente de teste. Responda em português, em uma única frase curta.',
      [{ role: 'user', text: 'Conexão de teste do sistema Jaques Motorsport. Confirme que você está funcionando.' }]);
    ok(res, { ok: true, provider: cfg.provider, model: r.model, answer: r.text.slice(0, 200) });
  } catch (e) {
    send(res, 502, { error: e.message });
  }
});

/* ---- clientes: perfil consolidado ---- */
route('GET', '/api/clients/:id/profile', 'clients', async (req, res, user, params) => {
  const c = db.get('clients', params.id);
  if (!c) return notFound(res);
  const id = c.id;
  const compras = db.all('sales').filter(s => s.clienteId === id).map(s => sanitize(user, 'sales', s));
  const entradas = db.all('headEntries').filter(e => e.clienteId === id);
  const oss = db.all('serviceOrders').filter(o => o.clienteId === id);
  const orcamentos = db.all('quotes').filter(q => q.clienteId === id);
  const receb = withOverdue(db.all('receivables').filter(r => r.clienteId === id));
  const totalComprado = compras.reduce((s, v) => s + (v.valorTotal || 0), 0)
    + oss.filter(o => !osCancelada(o)).reduce((s, o) => s + (o.valorTotal || 0), 0);
  const totalPago = receb.reduce((s, r) => s + recebidoDaParcela(r), 0);
  const emAberto = receb.filter(r => aReceber(r) && !emAtraso(r)).reduce((s, r) => s + saldoDaParcela(r), 0);
  const vencido = receb.filter(emAtraso).reduce((s, r) => s + saldoDaParcela(r), 0);
  const hist = db.all('audit').filter(a => a.action === 'timeline' && a.clientId === id).sort((a, b) => a.at < b.at ? 1 : -1);
  /* Crédito fica fora de "em aberto": ali é o que o cliente deve à empresa,
     e o crédito corre no sentido contrário. Vai como número próprio. */
  const creditoDisponivel = saldoDeCreditos(id);
  ok(res, {
    cliente: c, compras, entradas, ordens: oss, orcamentos, recebiveis: receb,
    financeiro: { totalComprado, totalPago, emAberto, vencido, creditoDisponivel },
    historico: hist
  });
});

/* ---- entrada de cabeçotes ---- */
route('POST', '/api/entries', 'entries', async (req, res, user) => {
  const b = await readBody(req);
  const cliente = db.get('clients', b.clienteId);
  if (!cliente) return bad(res, 'Cliente é obrigatório (cadastre o cliente antes)');
  const numero = db.nextNumber('cabecote', 1001);
  const entry = db.insert('headEntries', {
    codigo: '#' + numero,
    clienteId: cliente.id,
    dataChegada: b.dataChegada || domain.today(),
    cidade: b.cidade || cliente.cidade || '',
    estado: b.estado || cliente.estado || '',
    peca: b.peca || 'Cabeçote',
    modelo: b.modelo || '',
    defeito: b.defeito || '',
    observacoes: b.observacoes || '',
    docFiscal: b.docFiscal || { tipo: 'sem_documento', numero: '' },
    entradaDireta: !!b.entradaDireta, // exceção: entrou sem orçamento
    status: 'recebido' // recebido → em_analise → aguardando_orcamento → orcado → aprovado → ...
  });
  // Todo cabeçote de cliente entra automaticamente como BEM DE TERCEIRO — nunca no estoque próprio.
  const asset = db.insert('assets', {
    clienteId: cliente.id,
    identificacao: `${entry.codigo} — ${entry.peca} ${entry.modelo}`.trim(),
    dataEntrada: entry.dataChegada,
    motivo: b.entradaDireta ? 'Serviço (entrada direta — exceção)' : 'Serviço/retrabalho',
    entryId: entry.id, osId: null,
    status: 'na_empresa',
    docFiscal: entry.docFiscal,
    semDocumentoFiscal: !entry.docFiscal || entry.docFiscal.tipo === 'sem_documento'
  });
  db.update('headEntries', entry.id, { assetId: asset.id });
  audit(user, 'criou', 'headEntries', entry.id, `Entrada ${entry.codigo} (${cliente.nome})`);
  const tl = db.insert('audit', {
    at: new Date().toISOString(), userId: user.id, userName: user.name,
    action: 'timeline', entity: 'headEntries', entityId: entry.id, clientId: cliente.id,
    details: `Cabeçote ${entry.codigo} recebido${asset.semDocumentoFiscal ? ' (sem documento fiscal de remessa)' : ''}`
  });
  ok(res, entry);
});

route('POST', '/api/entries/:id/status', 'entries', async (req, res, user, params) => {
  const b = await readBody(req);
  const rec = db.update('headEntries', params.id, { status: b.status });
  if (!rec) return notFound(res);
  audit(user, 'status', 'headEntries', rec.id, `Entrada ${rec.codigo} → ${b.status}`);
  ok(res, rec);
});

/* ---- devolução de bem de terceiro ---- */
route('POST', '/api/assets/:id/return', 'assets', async (req, res, user, params) => {
  const b = await readBody(req);
  const rec = db.get('assets', params.id);
  if (!rec) return notFound(res);
  db.update('assets', rec.id, { status: 'devolvido', dataSaida: b.dataSaida || domain.today(), nfRetorno: b.nfRetorno || '' });
  audit(user, 'devolução', 'assets', rec.id, `Bem devolvido ao cliente (${rec.identificacao})`);
  db.insert('audit', {
    at: new Date().toISOString(), userId: user.id, userName: user.name,
    action: 'timeline', entity: 'assets', entityId: rec.id, clientId: rec.clienteId,
    details: `Bem devolvido: ${rec.identificacao}${b.nfRetorno ? ' — NF retorno ' + b.nfRetorno : ''}`
  });
  ok(res, { ok: true });
});

/* ---- orçamentos ---- */
function computeQuoteTotals(itens, custosAdicionais) {
  let total = 0;
  const items = (itens || []).map(i => {
    const t = (Number(i.qtd) || 0) * (Number(i.valorUnit) || 0);
    total += t;
    return { serviceId: i.serviceId || null, nome: i.nome, qtd: Number(i.qtd) || 0, valorUnit: Number(i.valorUnit) || 0, total: t };
  });
  const extras = Number(custosAdicionais) || 0;
  return { items, total: total + extras, extras };
}

route('POST', '/api/quotes', 'quotes', async (req, res, user) => {
  const b = await readBody(req);
  const cliente = db.get('clients', b.clienteId);
  if (!cliente) return bad(res, 'Cliente é obrigatório');
  const entry = b.entryId ? db.get('headEntries', b.entryId) : null;
  const { items, total, extras } = computeQuoteTotals(b.itens, b.custosAdicionais);
  const numero = db.nextNumber('orcamento', 1);
  const rec = db.insert('quotes', {
    numero,
    clienteId: cliente.id, cpfCnpj: cliente.cpfCnpj || '',
    entryId: entry ? entry.id : null,
    dataChegada: entry ? entry.dataChegada : (b.dataChegada || ''),
    dataOrcamento: b.dataOrcamento || domain.today(),
    validadeDias: Number(b.validadeDias) || db.settings.quoteValidityDays,
    previsaoEntrega: b.previsaoEntrega || '',
    modelo: b.modelo || (entry ? entry.modelo : ''),
    problema: b.problema || (entry ? entry.defeito : ''),
    descricaoServico: b.descricaoServico || '',
    itens: items, custosAdicionais: extras,
    observacoes: b.observacoes || '',
    total, status: 'aberto'
  });
  if (entry) db.update('headEntries', entry.id, { status: 'orcado', quoteId: rec.id });
  audit(user, 'criou', 'quotes', rec.id, `Orçamento nº ${numero} — ${cliente.nome} — R$ ${total.toFixed(2)}`);
  db.insert('audit', {
    at: new Date().toISOString(), userId: user.id, userName: user.name, action: 'timeline',
    entity: 'quotes', entityId: rec.id, clientId: cliente.id,
    details: `Orçamento nº ${numero} criado (R$ ${total.toFixed(2)})`
  });
  ok(res, rec);
});

route('PUT', '/api/quotes/:id', 'quotes', async (req, res, user, params) => {
  const b = await readBody(req);
  const q = db.get('quotes', params.id);
  if (!q) return notFound(res);
  if (q.status !== 'aberto') return bad(res, 'Só é possível editar orçamentos em aberto');
  const { items, total, extras } = computeQuoteTotals(b.itens || q.itens, b.custosAdicionais !== undefined ? b.custosAdicionais : q.custosAdicionais);
  const rec = db.update('quotes', q.id, {
    validadeDias: b.validadeDias !== undefined ? Number(b.validadeDias) : q.validadeDias,
    previsaoEntrega: b.previsaoEntrega !== undefined ? b.previsaoEntrega : q.previsaoEntrega,
    modelo: b.modelo !== undefined ? b.modelo : q.modelo,
    problema: b.problema !== undefined ? b.problema : q.problema,
    descricaoServico: b.descricaoServico !== undefined ? b.descricaoServico : q.descricaoServico,
    observacoes: b.observacoes !== undefined ? b.observacoes : q.observacoes,
    itens: items, custosAdicionais: extras, total
  });
  audit(user, 'alterou', 'quotes', rec.id, `Orçamento nº ${rec.numero}`);
  ok(res, rec);
});

/** Aprovação do orçamento → gera OS aproveitando todos os dados, sem recadastro. */
/* Replica um orçamento como modelo: novo registro independente, com os
   serviços, itens, valores e observações do original — e número novo, data
   de hoje, status aberto, sem aprovação nem vínculo com a entrada original.
   O orçamento de origem não é tocado. */
route('POST', '/api/quotes/:id/replicate', 'quotes', async (req, res, user, params) => {
  const b = await readBody(req);
  const origem = db.get('quotes', params.id);
  if (!origem) return notFound(res);
  const cliente = db.get('clients', b.clienteId || origem.clienteId);
  if (!cliente) return bad(res, 'Escolha o cliente do novo orçamento.');
  const numero = db.nextNumber('orcamento', 1);
  const rec = db.insert('quotes', {
    numero,
    clienteId: cliente.id, cpfCnpj: cliente.cpfCnpj || '',
    entryId: null,                              // a entrada de cabeçote era do original
    dataChegada: '',
    dataOrcamento: domain.today(),
    validadeDias: origem.validadeDias || db.settings.quoteValidityDays,
    previsaoEntrega: '',
    modelo: origem.modelo || '',
    problema: origem.problema || '',
    descricaoServico: origem.descricaoServico || '',
    itens: JSON.parse(JSON.stringify(origem.itens || [])),
    custosAdicionais: origem.custosAdicionais || 0,
    observacoes: origem.observacoes || '',
    total: origem.total,
    status: 'aberto',
    replicadoDe: origem.numero
  });
  audit(user, 'criou', 'quotes', rec.id,
    `Orçamento nº ${numero} replicado do nº ${origem.numero} — ${cliente.nome} — R$ ${Number(origem.total || 0).toFixed(2)}`);
  ok(res, rec);
});

route('POST', '/api/quotes/:id/approve', 'quotes', async (req, res, user, params) => {
  const q = db.get('quotes', params.id);
  if (!q) return notFound(res);
  if (q.status !== 'aberto') return bad(res, 'Orçamento não está em aberto');
  const b = await readBody(req);
  const numero = db.nextNumber('os', 1);
  const entry = q.entryId ? db.get('headEntries', q.entryId) : null;
  const os = db.insert('serviceOrders', {
    numero,
    quoteId: q.id, entryId: q.entryId, clienteId: q.clienteId,
    identificacao: entry ? entry.codigo : '',
    modelo: q.modelo, problema: q.problema, descricaoServico: q.descricaoServico,
    itens: q.itens, custosAdicionais: q.custosAdicionais,
    observacoes: q.observacoes,
    valorTotal: q.total,
    status: 'em_analise',
    previsaoEntrega: b.previsaoEntrega || q.previsaoEntrega || '',
    responsavelId: b.responsavelId || suggestAssignee('production'),
    dataFinalizacao: null,
    pagamentoStatus: 'pendente',
    nfRetorno: '', envioStatus: 'na_empresa',
    historico: [{ at: new Date().toISOString(), por: user.name, evento: 'OS criada a partir do orçamento nº ' + q.numero }]
  });
  db.update('quotes', q.id, { status: 'aprovado', osId: os.id, dataAprovacao: domain.today() });
  if (entry) db.update('headEntries', entry.id, { status: 'aprovado', osId: os.id });
  if (entry && entry.assetId) db.update('assets', entry.assetId, { osId: os.id });

  /* O trabalho aparece na Produção e o valor em Contas a receber sem
     ninguém redigitar nada: aprovar o orçamento fecha o ciclo inteiro. */
  const op = gerarProducaoDaOS(os, user);
  const fin = gerarFinanceiroDaOS(os, user, {
    forma: b.forma, condicao: b.parcelado ? 'parcelado' : 'a_vista',
    parcelas: b.parcelas, intervaloDias: b.intervaloDias,
    primeiroVencimento: b.primeiroVencimento,
    vencimento: b.vencimento, dataBase: b.dataBase || domain.today()
  });
  // Entrada paga na aprovação (ex.: metade agora, metade na entrega).
  if (Number(b.entrada) > 0) {
    const atual = db.get('serviceOrders', os.id);
    receberDaOS(atual, user, { valor: Number(b.entrada), forma: b.formaEntrada || b.forma || 'pix' });
  }

  audit(user, 'aprovou', 'quotes', q.id, `Orçamento nº ${q.numero} aprovado → OS nº ${numero}`);
  db.insert('audit', {
    at: new Date().toISOString(), userId: user.id, userName: user.name, action: 'timeline',
    entity: 'serviceOrders', entityId: os.id, clientId: q.clienteId,
    details: `Orçamento nº ${q.numero} aprovado — OS nº ${numero} aberta` +
      (op ? ` · ordem de produção #${op.id}` : '') +
      (fin.criadas ? ` · ${fin.criadas} conta(s) a receber` : '')
  });
  ok(res, db.get('serviceOrders', os.id));
});

route('POST', '/api/quotes/:id/reject', 'quotes', async (req, res, user, params) => {
  const b = await readBody(req);
  const q = db.get('quotes', params.id);
  if (!q) return notFound(res);
  const status = b.status === 'cancelado' ? 'cancelado' : 'recusado';
  /* Orçamento aprovado já virou OS: recusá-lo aqui deixaria uma OS e uma
     produção ativas penduradas num orçamento morto. */
  if (q.osId) {
    const os = db.get('serviceOrders', q.osId);
    if (os && !osCancelada(os)) {
      return bad(res, `Este orçamento já foi aprovado e gerou a OS nº ${os.numero}. ` +
        'Cancele a OS — ela cancela junto a produção e as parcelas em aberto.');
    }
  }
  db.update('quotes', q.id, { status });
  /* O cabeçote continua na empresa: a entrada volta a esperar orçamento,
     em vez de ficar "orçado" apontando para um orçamento recusado. */
  if (q.entryId) {
    const entry = db.get('headEntries', q.entryId);
    if (entry && entry.quoteId === q.id && !['entregue', 'aprovado'].includes(entry.status)) {
      db.update('headEntries', entry.id, { status: 'aguardando_orcamento', quoteId: null });
      audit(user, 'sincronizou', 'headEntries', entry.id,
        `Entrada ${entry.codigo} liberada para novo orçamento porque o orçamento nº ${q.numero} foi ${status}`);
    }
  }
  audit(user, status === 'cancelado' ? 'cancelou' : 'recusou', 'quotes', q.id, `Orçamento nº ${q.numero}`);
  db.insert('audit', {
    at: new Date().toISOString(), userId: user.id, userName: user.name, action: 'timeline',
    entity: 'quotes', entityId: q.id, clientId: q.clienteId, details: `Orçamento nº ${q.numero} ${status}`
  });
  ok(res, { ok: true });
});

/* ---- ordens de serviço ---- */
/* Uma OS cancelada sempre gravou 'cancelada', mas metade do sistema
   comparava com 'cancelado' — e assim OS canceladas continuavam somando
   faturamento no painel, na DRE, no analytics e na ficha do cliente.
   'cancelada' é a forma oficial; a outra continua sendo aceita na leitura
   para os registros que já existem. */
const OS_STATUS = ['em_analise', 'em_andamento', 'aguardando_peca', 'finalizado', 'aguardando_pagamento', 'cancelada'];
function osCancelada(os) { return !!os && (os.status === 'cancelada' || os.status === 'cancelado'); }
/* Situação do envio do cabeçote do cliente, na ordem em que acontece. */
const OS_ENVIO = ['na_empresa', 'pronto', 'enviado', 'entregue'];

/* ---- custos do serviço (OS) ----
   custoBase: estimativa por linha (mão de obra, materiais, componentes,
   terceirização, outros). custoReal: o que foi efetivamente gasto.
   O resultado usa o real quando existe; senão, a estimativa. */
const TIPOS_CUSTO_OS = ['mao_obra', 'materiais', 'componentes', 'terceirizacao', 'outros'];

function somaCustos(lista) {
  return (lista || []).reduce((s, c) => s + (Number(c.valor) || 0), 0);
}

/** Resultado do serviço: valor − custo (real se houver, senão estimado). */
function resultadoOS(os) {
  const bruto = Number(os.valorTotal) || 0;
  const estimado = somaCustos(os.custoBase);
  const real = somaCustos(os.custoReal);
  const usado = (os.custoReal || []).length ? real : estimado;
  const resultado = bruto - usado;
  return {
    bruto, custoEstimado: estimado, custoReal: real,
    usouReal: (os.custoReal || []).length > 0, custoUsado: usado,
    resultado, margem: bruto > 0 ? (resultado / bruto) * 100 : 0,
    desvio: (os.custoReal || []).length ? real - estimado : 0
  };
}

route('GET', '/api/os/:id/custos', 'finance_sensitive', async (req, res, user, params) => {
  const os = db.get('serviceOrders', params.id);
  if (!os) return notFound(res);
  ok(res, {
    tipos: TIPOS_CUSTO_OS,
    custoBase: os.custoBase || [], custoReal: os.custoReal || [],
    resultado: resultadoOS(os)
  });
});

route('PUT', '/api/os/:id/custos', 'finance_sensitive', async (req, res, user, params) => {
  const b = await readBody(req);
  const os = db.get('serviceOrders', params.id);
  if (!os) return notFound(res);
  const limpa = lista => (Array.isArray(lista) ? lista : [])
    .filter(c => c && (c.descricao || c.valor))
    .map(c => ({
      tipo: TIPOS_CUSTO_OS.includes(c.tipo) ? c.tipo : 'outros',
      descricao: String(c.descricao || '').slice(0, 160),
      valor: Number(c.valor) || 0
    }));
  const patch = {};
  if (b.custoBase !== undefined) patch.custoBase = limpa(b.custoBase);
  if (b.custoReal !== undefined) patch.custoReal = limpa(b.custoReal);
  const rec = db.update('serviceOrders', os.id, patch);
  audit(user, 'alterou', 'serviceOrders', os.id,
    `Custos da OS nº ${os.numero} — estimado R$ ${somaCustos(rec.custoBase).toFixed(2)}, real R$ ${somaCustos(rec.custoReal).toFixed(2)}`);
  ok(res, { custoBase: rec.custoBase || [], custoReal: rec.custoReal || [], resultado: resultadoOS(rec) });
});

/* ---- editar / duplicar / cancelar OS ---- */
route('PUT', '/api/os/:id', 'os', async (req, res, user, params) => {
  const antes = db.get('serviceOrders', params.id);
  if (!antes) return notFound(res);
  const b = await readBody(req);

  const temFinanceiro = db.all('receivables').some(r => r.refType === 'serviceOrders' && r.refId === antes.id && r.status === 'paga')
    || db.all('cashflow').some(c => c.refType === 'serviceOrders' && c.refId === antes.id);
  const mudaValor = b.valorTotal !== undefined && Number(b.valorTotal) !== antes.valorTotal;
  if (mudaValor && temFinanceiro) {
    return bad(res, 'Esta OS já tem pagamento registrado. Estorne o recebimento antes de mudar o valor — assim o caixa não fica diferente da OS.');
  }

  const patch = {};
  for (const k of ['modelo', 'problema', 'descricaoServico', 'observacoes', 'previsaoEntrega', 'identificacao', 'nfRetorno']) {
    if (b[k] !== undefined) patch[k] = b[k];
  }
  if (b.clienteId !== undefined) {
    const c = db.get('clients', b.clienteId);
    if (!c) return bad(res, 'Cliente inválido');
    patch.clienteId = c.id;
  }
  if (b.responsavelId !== undefined) patch.responsavelId = b.responsavelId || null;
  if (b.itens !== undefined) {
    const { items, total, extras } = computeQuoteTotals(b.itens, b.custosAdicionais);
    patch.itens = items; patch.custosAdicionais = extras; patch.valorTotal = total;
    if (temFinanceiro && total !== antes.valorTotal) {
      return bad(res, 'Esta OS já tem pagamento registrado. Estorne o recebimento antes de mudar os serviços.');
    }
  } else if (b.valorTotal !== undefined) {
    patch.valorTotal = Number(b.valorTotal) || 0;
  }

  const NOMES = { clienteId: 'Cliente', modelo: 'Modelo', valorTotal: 'Valor', previsaoEntrega: 'Previsão',
                  descricaoServico: 'Descrição', problema: 'Problema', observacoes: 'Observações' };
  const mudou = Object.keys(patch)
    .filter(k => NOMES[k] && JSON.stringify(antes[k] ?? '') !== JSON.stringify(patch[k] ?? ''))
    .map(k => `${NOMES[k]}: ${antes[k] ?? '—'} → ${patch[k] === '' ? '—' : patch[k]}`);
  if (patch.itens) mudou.push(`Serviços: ${(antes.itens || []).length} → ${patch.itens.length}`);

  const hist = (antes.historico || []).concat([{
    at: new Date().toISOString(), por: user.name,
    evento: 'OS editada' + (mudou.length ? ' — ' + mudou.join('; ') : '')
  }]);
  patch.historico = hist;
  // db.update altera o próprio registro, então o valor antigo é guardado antes.
  const valorAntigo = Number(antes.valorTotal || 0);
  const os = db.update('serviceOrders', antes.id, patch);
  // A ordem de produção acompanha a OS sem perder o que a equipe já marcou.
  gerarProducaoDaOS(os, user);
  // Mudou o valor: o plano de cobrança em aberto é refeito na mesma hora.
  if (valorAntigo !== Number(os.valorTotal || 0)) {
    gerarFinanceiroDaOS(os, user, {
      forma: (os.pagamento || {}).forma,
      condicao: (os.pagamento || {}).condicao,
      parcelas: (os.pagamento || {}).parcelas,
      intervaloDias: (os.pagamento || {}).intervaloDias,
      primeiroVencimento: primeiroVencimentoVigente(os)
    });
  }
  audit(user, 'alterou', 'serviceOrders', os.id, `OS nº ${os.numero} editada${mudou.length ? ' — ' + mudou.join('; ') : ''}`);
  ok(res, db.get('serviceOrders', os.id));
});

route('POST', '/api/os/:id/duplicate', 'os', async (req, res, user, params) => {
  const origem = db.get('serviceOrders', params.id);
  if (!origem) return notFound(res);
  const b = await readBody(req);
  const cliente = db.get('clients', b.clienteId || origem.clienteId);
  if (!cliente) return bad(res, 'Cliente inválido');
  const numero = db.nextNumber('os', 1);
  const os = db.insert('serviceOrders', {
    numero,
    quoteId: null, entryId: null, clienteId: cliente.id,
    identificacao: '',
    modelo: origem.modelo, problema: origem.problema, descricaoServico: origem.descricaoServico,
    itens: JSON.parse(JSON.stringify(origem.itens || [])),
    custosAdicionais: origem.custosAdicionais || 0,
    custoBase: JSON.parse(JSON.stringify(origem.custoBase || [])),  // a estimativa serve de modelo
    custoReal: [],                                                  // o real é sempre desta OS
    observacoes: origem.observacoes || '',
    valorTotal: origem.valorTotal,
    status: 'em_analise',
    previsaoEntrega: '', responsavelId: suggestAssignee('production'),
    dataFinalizacao: null, pagamentoStatus: 'pendente',
    nfRetorno: '', envioStatus: 'na_empresa',
    duplicadaDe: origem.numero,
    historico: [{ at: new Date().toISOString(), por: user.name, evento: `OS criada como cópia da nº ${origem.numero}` }]
  });
  gerarProducaoDaOS(os, user);
  audit(user, 'criou', 'serviceOrders', os.id, `OS nº ${numero} duplicada da nº ${origem.numero} — ${cliente.nome}`);
  ok(res, os);
});

route('DELETE', '/api/os/:id', 'os', async (req, res, user, params) => {
  const os = db.get('serviceOrders', params.id);
  if (!os) return notFound(res);
  const recs = db.all('receivables').filter(r => r.refType === 'serviceOrders' && r.refId === os.id);
  const pagas = recs.filter(r => r.status === 'paga');
  const caixa = db.all('cashflow').filter(c => c.refType === 'serviceOrders' && c.refId === os.id);
  if (pagas.length || caixa.length) {
    return bad(res, `Esta OS já tem ${pagas.length + caixa.length} movimentação(ões) financeira(s) registrada(s). Em vez de excluir, use Cancelar — o histórico e o financeiro ficam preservados.`);
  }
  for (const r of recs) db.remove('receivables', r.id);
  for (const p of db.all('productionOrders').filter(p => p.osId === os.id)) db.remove('productionOrders', p.id);
  if (os.quoteId) db.update('quotes', os.quoteId, { osId: null });
  if (os.entryId) db.update('headEntries', os.entryId, { osId: null, status: 'orcado' });
  db.remove('serviceOrders', os.id);
  audit(user, 'excluiu', 'serviceOrders', os.id, `OS nº ${os.numero} excluída — ${recs.length} recebível(is) em aberto removido(s)`);
  ok(res, { ok: true });
});

route('POST', '/api/os/:id/cancel', 'os', async (req, res, user, params) => {
  const b = await readBody(req);
  const os = db.get('serviceOrders', params.id);
  if (!os) return notFound(res);
  if (os.status === 'cancelada') return bad(res, 'Esta OS já está cancelada.');
  // Recebíveis em aberto são cancelados; os recebidos ficam (o dinheiro entrou).
  const recs = db.all('receivables').filter(r => r.refType === 'serviceOrders' && r.refId === os.id && r.status !== 'paga');
  for (const r of recs) db.update('receivables', r.id, { status: 'cancelada' });
  const hist = (os.historico || []).concat([{
    at: new Date().toISOString(), por: user.name,
    evento: `OS cancelada${b.motivo ? ' — ' + b.motivo : ''}${recs.length ? ` (${recs.length} parcela(s) em aberto cancelada(s))` : ''}`
  }]);
  db.update('serviceOrders', os.id, { status: 'cancelada', historico: hist });
  /* Cancelada, a OS deixa de ser trabalho a fazer: a entrada de cabeçote
     volta a ser um cabeçote parado na empresa, esperando decisão. */
  if (os.entryId) {
    const entry = db.get('headEntries', os.entryId);
    if (entry && entry.status !== 'entregue') {
      db.update('headEntries', entry.id, { status: 'aguardando_orcamento', osId: null });
      audit(user, 'sincronizou', 'headEntries', entry.id,
        `Entrada ${entry.codigo} devolvida para "aguardando orçamento" porque a OS nº ${os.numero} foi cancelada`);
    }
  }
  for (const p of db.all('productionOrders').filter(p => p.osId === os.id && p.status !== 'cancelado')) {
    db.update('productionOrders', p.id, { status: 'cancelado', osStatus: 'cancelada' });
  }
  audit(user, 'cancelou', 'serviceOrders', os.id, `OS nº ${os.numero} cancelada${b.motivo ? ' — ' + b.motivo : ''}`);
  ok(res, db.get('serviceOrders', os.id));
});

route('POST', '/api/os/:id/status', 'os', async (req, res, user, params) => {
  const b = await readBody(req);
  const os = db.get('serviceOrders', params.id);
  if (!os) return notFound(res);
  // 'cancelado' virava um status órfão que nenhum relatório reconhecia.
  const novo = b.status === 'cancelado' ? 'cancelada' : b.status;
  if (!OS_STATUS.includes(novo)) return bad(res, 'Status inválido: ' + b.status);
  if (novo === 'cancelada') {
    return bad(res, 'Para cancelar a OS use o botão Cancelar — ele cancela junto as parcelas em aberto e a produção.');
  }
  /* Reabrir uma OS cancelada por aqui deixaria a produção cancelada e as
     parcelas canceladas para trás. O caminho é duplicar. */
  if (osCancelada(os)) {
    return bad(res, `A OS nº ${os.numero} está cancelada. Para refazer o trabalho, use Duplicar — assim o cancelamento continua registrado.`);
  }
  const patch = { status: novo };
  if (novo === 'finalizado') patch.dataFinalizacao = b.data || domain.today();
  if (b.responsavelId !== undefined) patch.responsavelId = b.responsavelId;
  os.historico = os.historico || [];
  os.historico.push({ at: new Date().toISOString(), por: user.name, evento: 'Status → ' + novo });
  db.update('serviceOrders', os.id, patch);
  for (const p of db.all('productionOrders').filter(p => p.osId === os.id && p.status !== 'cancelado')) {
    db.update('productionOrders', p.id, { osStatus: novo });
  }
  /* Finalizar a OS é dizer que o trabalho acabou. A Produção mostra o mesmo
     trabalho: ela conclui junto, sem ninguém remarcar o checklist. */
  if (novo === 'finalizado') {
    const r = concluirProducaoDe(p => p.osId === os.id, user, `a OS nº ${os.numero} foi finalizada`);
    if (r.ordens) {
      historicoOS(db.get('serviceOrders', os.id),
        `${r.ordens} ordem(ns) de produção concluída(s) automaticamente junto com a OS`, user);
    }
  }
  audit(user, 'status', 'serviceOrders', os.id, `OS nº ${os.numero} → ${novo}`);
  db.insert('audit', {
    at: new Date().toISOString(), userId: user.id, userName: user.name, action: 'timeline',
    entity: 'serviceOrders', entityId: os.id, clientId: os.clienteId, details: `OS nº ${os.numero}: status ${b.status}`
  });
  ok(res, db.get('serviceOrders', os.id));
});

route('POST', '/api/os/:id/envio', 'os', async (req, res, user, params) => {
  const b = await readBody(req);
  const os = db.get('serviceOrders', params.id);
  if (!os) return notFound(res);
  if (!OS_ENVIO.includes(b.envioStatus)) return bad(res, 'Situação de envio inválida: ' + b.envioStatus);
  db.update('serviceOrders', os.id, { envioStatus: b.envioStatus, nfRetorno: b.nfRetorno !== undefined ? b.nfRetorno : os.nfRetorno });
  os.historico = os.historico || [];
  os.historico.push({ at: new Date().toISOString(), por: user.name, evento: 'Envio/entrega → ' + b.envioStatus });
  db.save();

  /* "Pronto para envio" (ou já despachado) quer dizer que a bancada
     terminou: a Produção reconhece a conclusão sem ninguém remarcar o
     checklist, e a OS fica finalizada se ainda não estava. */
  if (['pronto', 'enviado', 'entregue'].includes(b.envioStatus)) {
    const rotulo = { pronto: 'ficou pronta para envio', enviado: 'foi enviada', entregue: 'foi entregue' }[b.envioStatus];
    const r = concluirProducaoDe(p => p.osId === os.id, user, `a OS nº ${os.numero} ${rotulo}`);
    const atual = db.get('serviceOrders', os.id);
    if (!osCancelada(atual) && !['finalizado', 'aguardando_pagamento'].includes(atual.status)) {
      db.update('serviceOrders', os.id, { status: 'finalizado', dataFinalizacao: atual.dataFinalizacao || domain.today() });
      for (const p of db.all('productionOrders').filter(p => p.osId === os.id && p.status !== 'cancelado')) {
        db.update('productionOrders', p.id, { osStatus: 'finalizado' });
      }
      historicoOS(db.get('serviceOrders', os.id),
        `OS finalizada automaticamente porque o serviço ${rotulo}`, user);
      audit(user, 'sincronizou', 'serviceOrders', os.id,
        `OS nº ${os.numero} → Finalizado automaticamente porque ${rotulo}`);
    }
    if (r.ordens) {
      historicoOS(db.get('serviceOrders', os.id),
        `${r.ordens} ordem(ns) de produção concluída(s) automaticamente porque a OS ${rotulo}`, user);
    }
  }
  /* Despachado o cabeçote, o bem de terceiro e a entrada acompanham: o
     mesmo fato não precisa ser baixado em três telas. */
  sincronizarEntregaDaOS(db.get('serviceOrders', os.id), user);

  audit(user, 'envio', 'serviceOrders', os.id, `OS nº ${os.numero} → ${b.envioStatus}`);
  ok(res, db.get('serviceOrders', os.id));
});

/* ---- financeiro do serviço ----
   O valor da OS vira conta a receber sozinho, do mesmo jeito que a venda de
   cabeçote. Uma única função monta o plano, e ela é usada tanto na aprovação
   do orçamento quanto quando alguém troca a forma de pagamento depois. */

/** Quanto já entrou nesta OS (recebimentos parciais registrados). */
function recebidoDaOS(os) {
  return Math.round((os.recebimentos || []).reduce((s, r) => s + (Number(r.valor) || 0), 0) * 100) / 100;
}

/** Resumo financeiro da OS: total, recebido, saldo. */
function resumoFinanceiroOS(os) {
  const total = Number(os.valorTotal) || 0;
  const recebido = recebidoDaOS(os);
  /* Parcelas baixadas em Contas a receber contam aqui. Ficam de fora as
     baixas automáticas (auto) e a conta de "saldo", que é só o espelho do
     que já está em `recebimentos` — somar as duas contaria o mesmo dinheiro
     duas vezes. */
  const pagas = db.all('receivables')
    .filter(r => r.refType === 'serviceOrders' && r.refId === os.id &&
                 (r.status === 'paga' || r.status === 'parcial') && !r.auto && r.origem !== 'saldo')
    .reduce((s, r) => s + recebidoDaParcela(r), 0);
  const quitado = Math.round((recebido + pagas) * 100) / 100;
  return { total, recebido: quitado, saldo: Math.round((total - quitado) * 100) / 100 };
}

/**
 * (Re)monta as contas a receber de uma OS. Só mexe no que está em aberto e
 * foi gerado pelo sistema — parcela já recebida nunca é tocada.
 * opcoes: { forma, condicao: 'a_vista'|'parcelado', parcelas, intervaloDias,
 *           primeiroVencimento, vencimento, dataBase, entrada }
 * Com `primeiroVencimento`, a 1ª parcela cai no dia informado e as demais
 * andam de `intervaloDias` a partir dele.
 */
/* Ao refazer sozinho o plano de cobrança (mudou o valor da OS, migração),
   vale a data de 1º vencimento que a OS já tinha — desde que ainda esteja
   à frente. Data velha geraria parcelas já nascendo vencidas. */
function primeiroVencimentoVigente(os) {
  const d = (os.pagamento || {}).primeiroVencimento || '';
  return d && d >= domain.today() ? d : '';
}

function gerarFinanceiroDaOS(os, user, opcoes = {}) {
  const cliente = db.get('clients', os.clienteId);
  const total = Number(os.valorTotal) || 0;
  if (total <= 0) return { criadas: 0, motivo: 'OS sem valor' };

  // Fora o que já foi recebido: o plano cobre apenas o que falta.
  const jaRecebido = resumoFinanceiroOS(os).recebido;
  const aCobrar = Math.round((total - jaRecebido) * 100) / 100;

  // Limpa só as parcelas em aberto criadas automaticamente para esta OS.
  for (const r of db.all('receivables').filter(r =>
    r.refType === 'serviceOrders' && r.refId === os.id &&
    r.status !== 'paga' && r.status !== 'parcial' && r.status !== 'cancelada')) {
    db.remove('receivables', r.id);
  }
  if (aCobrar <= 0.005) {
    db.update('serviceOrders', os.id, { pagamentoStatus: 'pago' });
    return { criadas: 0, motivo: 'já quitada' };
  }

  const forma = opcoes.forma || (os.pagamento && os.pagamento.forma) || 'boleto';
  const base = opcoes.dataBase || domain.today();
  const parcelas = Math.max(1, Number(opcoes.parcelas) || 1);
  const parcelado = opcoes.condicao === 'parcelado' && parcelas > 1;

  let criadas = 0;
  if (parcelado) {
    const parcels = domain.generateInstallments(base, aCobrar, parcelas,
      opcoes.intervaloDias, opcoes.primeiroVencimento);
    for (const p of parcels) {
      db.insert('receivables', {
        clienteId: os.clienteId, origem: 'servico', refType: 'serviceOrders', refId: os.id,
        descricao: `OS nº ${os.numero} — ${os.modelo || 'serviço'} — parcela ${p.parcela}/${p.parcelas}`,
        forma, valor: p.valor, vencimento: p.vencimento,
        status: 'aberto', parcela: p.parcela, parcelas: p.parcelas
      });
      criadas++;
    }
  } else {
    db.insert('receivables', {
      clienteId: os.clienteId, origem: 'servico', refType: 'serviceOrders', refId: os.id,
      descricao: `OS nº ${os.numero} — ${os.modelo || 'serviço'}`,
      forma, valor: aCobrar,
      vencimento: opcoes.vencimento || os.previsaoEntrega || domain.addDays(base, 30),
      status: 'aberto', parcela: 1, parcelas: 1
    });
    criadas = 1;
  }
  db.update('serviceOrders', os.id, {
    pagamentoStatus: jaRecebido > 0 ? 'parcial' : (parcelado ? 'parcelado' : 'pendente'),
    pagamento: Object.assign({}, os.pagamento, {
      forma, condicao: parcelado ? 'parcelado' : 'a_vista',
      parcelas: parcelado ? parcelas : 1, intervaloDias: opcoes.intervaloDias || 30,
      primeiroVencimento: parcelado ? (opcoes.primeiroVencimento || '') : '', valor: total
    })
  });
  return { criadas, aCobrar };
}

/**
 * Registro do pagamento de uma OS: define a forma e refaz o plano de parcelas.
 * À vista com dinheiro em caixa entra direto; boleto/parcelado vira conta a receber.
 */
route('POST', '/api/os/:id/payment', 'receivables', async (req, res, user, params) => {
  const b = await readBody(req);
  const os = db.get('serviceOrders', params.id);
  if (!os) return notFound(res);
  const cliente = db.get('clients', os.clienteId);
  const valor = Number(b.valor) || os.valorTotal || 0;

  /* "Já recebido à vista": isto É um recebimento, pedido de propósito por
     quem marcou a caixinha. Então entra pelo mesmo caminho de qualquer
     recebimento — fica registrado em os.recebimentos e gera UMA entrada no
     caixa. Antes criava também um recebível "pago" espelho que o resumo da
     OS não contava: a OS continuava mostrando o valor cheio em aberto e
     dava para receber de novo, dobrando o dinheiro no caixa. */
  if (b.aVistaAgora) {
    const data = b.data || domain.today();
    const jaRecebido = resumoFinanceiroOS(os).recebido;
    const aReceber = Math.round((valor - jaRecebido) * 100) / 100;
    if (aReceber <= 0.005) {
      return bad(res, `Esta OS já tem ${brl(jaRecebido)} recebidos — não há o que receber à vista.`);
    }
    for (const r of db.all('receivables').filter(r =>
      r.refType === 'serviceOrders' && r.refId === os.id &&
      r.status !== 'paga' && r.status !== 'parcial' && r.status !== 'cancelada')) {
      db.remove('receivables', r.id);
    }
    db.update('serviceOrders', os.id, {
      pagamento: { forma: b.forma || 'pix', condicao: 'a_vista', parcelas: 1, valor, data }
    });
    const out = receberDaOS(db.get('serviceOrders', os.id), user,
      { valor: aReceber, data, forma: b.forma || 'pix', conta: b.conta, documento: b.documento,
        obs: 'Recebido à vista no registro da forma de pagamento' });
    if (out.erro) return bad(res, out.erro);
  } else {
    gerarFinanceiroDaOS(os, user, {
      forma: b.forma, condicao: b.parcelado ? 'parcelado' : 'a_vista',
      parcelas: b.parcelas, intervaloDias: b.intervaloDias,
      primeiroVencimento: b.primeiroVencimento,
      vencimento: b.vencimento, dataBase: b.dataVenda || domain.today()
    });
  }
  audit(user, 'pagamento', 'serviceOrders', os.id, `OS nº ${os.numero} — R$ ${valor.toFixed(2)} (${b.parcelado ? b.parcelas + 'x' : 'à vista'})`);
  db.insert('audit', {
    at: new Date().toISOString(), userId: user.id, userName: user.name, action: 'timeline',
    entity: 'serviceOrders', entityId: os.id, clientId: os.clienteId,
    details: `Pagamento registrado na OS nº ${os.numero}: R$ ${valor.toFixed(2)}`
  });
  ok(res, db.get('serviceOrders', os.id));
});

/* Recebimento parcial do serviço — mesma lógica da venda de cabeçote:
   entrada de R$ 1.500 num serviço de R$ 3.000 deixa R$ 1.500 em aberto,
   e só isso. Nunca as duas coisas ao mesmo tempo. */
function receberDaOS(os, user, b) {
  const cliente = db.get('clients', os.clienteId);
  const valor = Number(b.valor) || 0;
  if (valor <= 0) return { erro: 'Informe o valor recebido.' };
  const resumo = resumoFinanceiroOS(os);
  if (valor > resumo.saldo + 0.005) {
    return { erro: `O saldo em aberto é R$ ${resumo.saldo.toFixed(2)} — não dá para receber R$ ${valor.toFixed(2)}.` };
  }
  const data = b.data || domain.today();
  const rec = { valor, data, forma: b.forma || 'pix', obs: b.obs || '' };
  const lista = (os.recebimentos || []).concat([rec]);
  db.update('serviceOrders', os.id, { recebimentos: lista });
  db.insert('cashflow', {
    tipo: 'entrada', valor, data, conta: b.conta || 'principal',
    formaPagamento: normalizaForma(rec.forma) || 'outro',
    categoria: 'servico', origem: `OS nº ${os.numero}${cliente ? ' — ' + cliente.nome : ''} — recebimento`,
    documento: b.documento || '', refType: 'serviceOrders', refId: os.id,
    descricao: `Recebimento de serviço (${rec.forma})`
  });

  // A cobrança cheia dá lugar ao saldo: o mesmo dinheiro não pode aparecer duas vezes.
  for (const r of db.all('receivables').filter(r =>
    r.refType === 'serviceOrders' && r.refId === os.id && r.origem !== 'saldo' &&
    r.status !== 'paga' && r.status !== 'parcial' && r.status !== 'cancelada')) {
    db.remove('receivables', r.id);
  }
  const atualizada = db.get('serviceOrders', os.id);
  const saldo = resumoFinanceiroOS(atualizada).saldo;
  const saldoAberto = db.all('receivables').find(r =>
    r.refType === 'serviceOrders' && r.refId === os.id && r.origem === 'saldo');
  if (saldo > 0.005) {
    const dados = {
      clienteId: os.clienteId, origem: 'saldo', refType: 'serviceOrders', refId: os.id,
      descricao: `OS nº ${os.numero} — saldo em aberto`,
      forma: b.forma || 'pix', valor: saldo,
      vencimento: b.vencimentoSaldo || os.previsaoEntrega || domain.addDays(data, 30),
      status: 'aberto', parcela: 1, parcelas: 1
    };
    if (saldoAberto) {
      db.update('receivables', saldoAberto.id, {
        valor: saldo, vencimento: saldoAberto.vencimento || dados.vencimento,
        status: 'aberto', dataRecebimento: null, recebido: 0
      });
    } else db.insert('receivables', dados);
    db.update('serviceOrders', os.id, { pagamentoStatus: 'parcial' });
  } else {
    /* Quitada, a linha de saldo SAI de Contas a receber em vez de ficar lá
       marcada como "paga" com o valor antigo — era isso que fazia o painel
       do título somar o mesmo dinheiro de novo e mostrar saldo negativo.
       O recebimento continua registrado na OS e no Fluxo de caixa. */
    if (saldoAberto) db.remove('receivables', saldoAberto.id);
    db.update('serviceOrders', os.id, { pagamentoStatus: 'pago' });
  }

  audit(user, 'recebeu', 'serviceOrders', os.id,
    `OS nº ${os.numero} — recebido R$ ${valor.toFixed(2)} (${rec.forma}); saldo R$ ${saldo.toFixed(2)}`);
  db.insert('audit', {
    at: new Date().toISOString(), userId: user.id, userName: user.name, action: 'timeline',
    entity: 'serviceOrders', entityId: os.id, clientId: os.clienteId,
    details: `Recebimento de R$ ${valor.toFixed(2)} na OS nº ${os.numero} — saldo R$ ${saldo.toFixed(2)}`
  });
  return { recebido: recebidoDaOS(db.get('serviceOrders', os.id)), saldo };
}

route('POST', '/api/os/:id/receive', 'receivables', async (req, res, user, params) => {
  const b = await readBody(req);
  const os = db.get('serviceOrders', params.id);
  if (!os) return notFound(res);
  const out = receberDaOS(os, user, b);
  if (out.erro) return bad(res, out.erro);
  ok(res, out);
});

/** Desfaz um recebimento parcial do serviço (estorna o caixa e devolve o saldo). */
route('POST', '/api/os/:id/unreceive', 'receivables', async (req, res, user, params) => {
  const b = await readBody(req);
  const os = db.get('serviceOrders', params.id);
  if (!os) return notFound(res);
  const idx = Number(b.index);
  const lista = (os.recebimentos || []).slice();
  if (!(idx >= 0 && idx < lista.length)) return bad(res, 'Recebimento não encontrado.');
  const [removido] = lista.splice(idx, 1);
  db.update('serviceOrders', os.id, { recebimentos: lista });

  const caixa = db.all('cashflow').find(c =>
    c.refType === 'serviceOrders' && c.refId === os.id && c.tipo === 'entrada' &&
    Math.abs((Number(c.valor) || 0) - removido.valor) < 0.005 && c.data === removido.data);
  if (caixa) db.remove('cashflow', caixa.id);

  const atualizada = db.get('serviceOrders', os.id);
  const saldo = resumoFinanceiroOS(atualizada).saldo;
  const saldoAberto = db.all('receivables').find(r =>
    r.refType === 'serviceOrders' && r.refId === os.id && r.origem === 'saldo');
  if (saldo > 0.005) {
    if (saldoAberto) db.update('receivables', saldoAberto.id, { valor: saldo, status: 'aberto', dataRecebimento: null });
    else gerarFinanceiroDaOS(atualizada, user, { forma: (os.pagamento || {}).forma });
    db.update('serviceOrders', os.id, { pagamentoStatus: lista.length ? 'parcial' : 'pendente' });
  }
  audit(user, 'estornou', 'serviceOrders', os.id,
    `OS nº ${os.numero} — recebimento de R$ ${removido.valor.toFixed(2)} desfeito; saldo R$ ${saldo.toFixed(2)}`);
  ok(res, { recebido: recebidoDaOS(db.get('serviceOrders', os.id)), saldo });
});

/** Resumo financeiro do serviço para a tela da OS. */
route('GET', '/api/os/:id/financeiro', 'receivables', async (req, res, user, params) => {
  const os = db.get('serviceOrders', params.id);
  if (!os) return notFound(res);
  const parcelas = withOverdue(db.all('receivables')
    .filter(r => r.refType === 'serviceOrders' && r.refId === os.id))
    .sort((a, b) => String(a.vencimento || '').localeCompare(String(b.vencimento || '')));
  ok(res, Object.assign(resumoFinanceiroOS(os), {
    pagamento: os.pagamento || {}, pagamentoStatus: os.pagamentoStatus,
    recebimentos: os.recebimentos || [], parcelas
  }));
});

/* ---- vendas ----
   Uma venda tem itens de dois tipos:
     kind 'cabecote' — produto fabricado; consome componentes na PRODUÇÃO
                       (quando a ordem fica "pronto"), não na venda;
     kind 'peca'     — item do estoque próprio revendido; baixa na hora.
   A distinção importa para o estoque não ser baixado duas vezes. */

/** Monta e valida os itens da venda. Devolve { itens, valorTotal, custoBaseTotal } ou { erro }. */
function montarItensVenda(lista) {
  let valorTotal = 0, custoBaseTotal = 0;
  const itens = [];
  for (const i of lista) {
    const qtd = Math.max(1, Number(i.qtd) || 1);
    if (i.kind === 'peca') {
      const it = db.get('stockItems', i.stockItemId);
      if (!it) return { erro: 'Peça do estoque inválida' };
      const unit = Number(i.valorUnit) || 0;
      const tot = qtd * unit;
      valorTotal += tot;
      custoBaseTotal += qtd * (Number(it.custoUnit) || 0);
      itens.push({ kind: 'peca', stockItemId: it.id, produto: it.nome, qtd, valorUnit: unit, total: tot });
      continue;
    }
    const prod = db.get('products', i.productId);
    if (!prod) return { erro: 'Produto inválido' };
    const v = domain.validarProduto(prod, i.comando, i.tucho);
    if (!v.ok) return { erro: v.error };
    const unit = Number(i.valorUnit) || prod.preco || 0;
    const tot = qtd * unit;
    valorTotal += tot;
    custoBaseTotal += qtd * (prod.custoBase || 0);
    itens.push({ kind: 'cabecote', productId: prod.id, produto: prod.nome, tipo: prod.tipo, stage: prod.stage,
                 variante: prod.variante || '', rotuloStage: prod.rotuloStage || domain.rotuloStage(prod.stage, prod.variante),
                 comando: i.comando, tucho: String(i.tucho), qtd, valorUnit: unit, total: tot });
  }
  return { itens, valorTotal, custoBaseTotal };
}

/** Baixa (ou devolve) o estoque das peças de uma venda, uma única vez. */
function estoquePecasDaVenda(sale, user, { devolver } = {}) {
  const jaBaixado = !!sale.estoquePecasBaixado;
  if (devolver ? !jaBaixado : jaBaixado) return;
  for (const it of (sale.itens || []).filter(x => x.kind === 'peca')) {
    moveStock(it.stockItemId, devolver ? 'entrada' : 'saida', it.qtd, 'sales', sale.id,
      `${devolver ? 'Estorno da venda' : 'Venda'} nº ${sale.numero}`, user);
  }
  db.update('sales', sale.id, { estoquePecasBaixado: !devolver });
}

/** Desfaz tudo que uma venda gerou: produção não iniciada, recebíveis em
    aberto, caixa e estoque de peças. Devolve o que não pôde ser desfeito. */
function reverterVenda(sale, user) {
  const travas = [];

  // Produção: só remove o que ainda não consumiu componentes.
  const pos = db.all('productionOrders').filter(p => p.saleId === sale.id);
  for (const po of pos) {
    if (po.estoqueBaixado) travas.push(`ordem de produção #${po.id} já consumiu componentes do estoque`);
    else db.remove('productionOrders', po.id);
  }

  // Recebíveis: em aberto são removidos; recebidos viram trava.
  const recs = db.all('receivables').filter(r => r.refType === 'sales' && r.refId === sale.id);
  for (const r of recs) {
    if (r.status === 'paga' && !r.auto) travas.push(`parcela "${r.descricao}" já foi recebida`);
    else db.remove('receivables', r.id);
  }

  // Recebimentos avulsos lançados na venda.
  if ((sale.recebimentos || []).length) travas.push(`${sale.recebimentos.length} recebimento(s) já registrado(s)`);

  if (travas.length) return travas;

  // Sem travas: limpa caixa e devolve as peças ao estoque.
  for (const c of db.all('cashflow').filter(c => c.refType === 'sales' && c.refId === sale.id)) {
    db.remove('cashflow', c.id);
  }
  estoquePecasDaVenda(sale, user, { devolver: true });
  return null;
}

/**
 * Quando a ordem fica pronta, os componentes saem do estoque próprio — uma
 * única vez, venha o "pronto" do checklist ou de onde for. Serviço não baixa
 * nada: quem entra é o cabeçote do cliente.
 */
function concluirSePronto(po, user) {
  const atual = baixarComponentesSePronto(po, user);
  /* O trabalho é um só: quando a ordem anda, quem mostra o mesmo trabalho
     em outra aba anda junto. */
  sincronizarOSComProducao(atual, user);
  sincronizarVendaComProducao(atual, user);
  return andamentoDaOrdem(db.get('productionOrders', atual.id)) || atual;
}

/**
 * Componentes que ESTA ordem deve consumir, pela composição cadastrada do
 * produto e pela configuração vendida (comando e tucho do pedido).
 * Ordem já baixada responde pelo que foi realmente consumido, para o
 * histórico não mudar quando a composição do produto mudar depois.
 */
function componentesDaOrdem(po) {
  if (!po) return [];
  if (Array.isArray(po.consumo) && po.consumo.length) {
    return po.consumo.map((c, idx) => {
      const item = c.stockItemId ? db.get('stockItems', c.stockItemId) : null;
      return Object.assign({ idx, vinculado: !!c.stockItemId, motivo: c.motivo || '', historico: true },
        c, { emEstoque: item ? (Number(item.qtd) || 0) : null });
    });
  }
  const prod = po.productId ? db.get('products', po.productId) : null;
  if (!prod) return [];
  const unidades = Math.max(1, Number(po.qtd) || 1);
  return composicaoResolvida(prod, { tipo: po.tipo, comando: po.comando, tucho: po.tucho })
    .map(l => Object.assign({}, l, { qtd: Math.round(l.qtd * unidades * 1000) / 1000 }));
}

function baixarComponentesSePronto(po, user) {
  const atual = andamentoDaOrdem(po);
  if (atual.status !== 'pronto' || atual.estoqueBaixado || atual.origem === 'servico') return atual;
  /* A baixa segue a COMPOSIÇÃO do produto — peça por peça, na quantidade
     cadastrada. O que a ordem consumiu fica gravado nela: mudar a
     composição depois não reescreve o que já saiu do estoque. */
  const linhas = componentesDaOrdem(atual);
  const consumo = [];
  for (const l of linhas) {
    if (!l.vinculado || !l.qtd) {
      consumo.push({ papel: l.papel, stockItemId: null, nome: l.nome, qtd: l.qtd,
        custoUnit: 0, motivo: l.motivo || 'Sem item de estoque vinculado', baixado: false });
      continue;
    }
    moveStock(l.stockItemId, 'saida', l.qtd, 'productionOrders', atual.id,
      `Produção pedido nº ${atual.pedidoNumero}`, user,
      { papel: l.papel, productId: atual.productId || null, composicao: true });
    consumo.push({ papel: l.papel, stockItemId: l.stockItemId, nome: l.nome, qtd: l.qtd,
      custoUnit: l.custoUnit, baixado: true });
  }
  const pendentes = consumo.filter(c => !c.baixado);
  db.update('productionOrders', atual.id, {
    estoqueBaixado: true, consumo,
    custoComponentes: Math.round(consumo.reduce((s, c) => s + (c.custoUnit || 0) * (c.qtd || 0), 0) * 100) / 100,
    componentesPendentes: pendentes.length
  });
  audit(user, 'concluiu', 'productionOrders', atual.id,
    `Ordem de produção #${atual.id} pronta — ${consumo.length - pendentes.length} componente(s) baixado(s) do estoque` +
    (pendentes.length ? `; ${pendentes.length} sem item de estoque vinculado` : ''));
  return andamentoDaOrdem(db.get('productionOrders', atual.id));
}

/* =====================================================================
   COMPOSIÇÃO E BAIXAS DE UMA VENDA — e a auditoria de todas elas

   O cabeçote vendido consome componentes na PRODUÇÃO, quando a ordem fica
   pronta — não no instante da venda. É isso que estas funções mostram:
   o que cada pedido deve consumir, o que já saiu do estoque, e a diferença.
   ===================================================================== */

/** Soma, por item, o que uma ordem de produção já movimentou no estoque. */
function movimentosDaOrdem(ordemId) {
  const movs = db.all('stockMoves').filter(m =>
    m.refType === 'productionOrders' && m.refId === ordemId && !m.estornada);
  const porItem = {};
  for (const m of movs) {
    const q = Number(m.qtd) || 0;
    const d = m.tipo === 'saida' ? q : -q;
    porItem[m.itemId] = (porItem[m.itemId] || 0) + d;
  }
  return { movs, porItem };
}

const C3 = (v) => Math.round((Number(v) || 0) * 1000) / 1000;

/** Situação de cada componente de uma ordem: esperado × movimentado. */
function componentesComSituacao(po) {
  const { movs, porItem } = movimentosDaOrdem(po.id);
  const linhas = componentesDaOrdem(po);
  const pronta = po.status === 'pronto' || po.estoqueBaixado;
  const usados = new Set();
  const out = linhas.map(l => {
    const esperado = C3(l.qtd);
    const movido = l.stockItemId ? C3(porItem[l.stockItemId] || 0) : 0;
    if (l.stockItemId) usados.add(l.stockItemId);
    let situacao;
    if (!l.vinculado) situacao = 'sem_vinculo';
    else if (!pronta) situacao = movido > 0 ? 'baixado' : 'aguardando';
    else if (Math.abs(movido - esperado) < 0.001) situacao = 'baixado';
    else if (movido <= 0) situacao = 'pendente';
    else if (movido < esperado) situacao = 'parcial';
    else situacao = 'duplicado';
    return Object.assign({}, l, {
      esperado, movido, diferenca: C3(esperado - movido), situacao,
      movimentos: (l.stockItemId ? movs.filter(m => m.itemId === l.stockItemId) : []).map(m => ({
        id: m.id, data: m.data, tipo: m.tipo, qtd: Number(m.qtd) || 0, obs: m.obs || ''
      }))
    });
  });
  /* Saídas registradas para esta ordem que a composição não prevê —
     normalmente de uma composição antiga. Aparecem para conferência. */
  for (const [itemId, q] of Object.entries(porItem)) {
    const id = Number(itemId);
    if (usados.has(id) || C3(q) === 0) continue;
    const item = db.get('stockItems', id);
    out.push({
      papel: 'extra', stockItemId: id, nome: item ? item.nome : `Item #${id}`,
      categoria: item ? item.categoria : '', qtd: 0, esperado: 0, movido: C3(q),
      diferenca: C3(-q), situacao: 'fora_da_composicao', vinculado: true, motivo:
        'Saiu do estoque por esta ordem, mas não está na composição atual do produto',
      custoUnit: item ? (Number(item.custoUnit) || 0) : 0, custoTotal: 0,
      movimentos: movs.filter(m => m.itemId === id).map(m => ({
        id: m.id, data: m.data, tipo: m.tipo, qtd: Number(m.qtd) || 0, obs: m.obs || ''
      }))
    });
  }
  return out;
}

const SITUACOES_PROBLEMA = ['pendente', 'parcial', 'duplicado', 'sem_vinculo', 'fora_da_composicao'];

/** Composição e baixas de uma venda inteira, cabeçote por cabeçote. */
function composicaoDaVenda(sale, user) {
  const sensivel = can(user, 'finance_sensitive');
  const ordens = db.all('productionOrders')
    .filter(p => p.saleId === sale.id).sort((a, b) => a.id - b.id);

  const unidades = ordens.map(po => {
    const componentes = componentesComSituacao(po);
    const conta = (s) => componentes.filter(c => c.situacao === s).length;
    return {
      ordemId: po.id, produto: po.produto, tipo: po.tipo, stage: po.stage,
      rotuloStage: po.rotuloStage || domain.rotuloStage(po.stage, po.variante),
      comando: po.comando, tucho: po.tucho,
      status: po.status, estoqueBaixado: !!po.estoqueBaixado,
      /* Ordem concluída antes desta versão não guarda o que consumiu: ali
         o sistema baixava 1 de cada peça, fosse qual fosse a montagem. */
      baixaLegado: !!po.estoqueBaixado && !(po.consumo || []).length,
      componentes: componentes.map(c => sensivel ? c
        : Object.assign({}, c, { custoUnit: undefined, custoTotal: undefined })),
      custoComponentes: sensivel
        ? C3(componentes.reduce((s, c) => s + (c.custoUnit || 0) * (c.esperado || 0), 0)) : undefined,
      resumo: { total: componentes.length, baixados: conta('baixado'), aguardando: conta('aguardando'),
        pendentes: conta('pendente') + conta('parcial'), duplicados: conta('duplicado'),
        semVinculo: conta('sem_vinculo'), foraDaComposicao: conta('fora_da_composicao') }
    };
  });

  /* Peças revendidas: baixam na própria venda, não na produção. */
  const pecas = (sale.itens || []).filter(i => i.kind === 'peca').map(i => {
    const movs = db.all('stockMoves').filter(m =>
      m.refType === 'sales' && m.refId === sale.id && m.itemId === i.stockItemId && !m.estornada);
    const movido = C3(movs.reduce((s, m) => s + (m.tipo === 'saida' ? (Number(m.qtd) || 0) : -(Number(m.qtd) || 0)), 0));
    const esperado = C3(i.qtd);
    return {
      stockItemId: i.stockItemId, nome: i.produto, esperado, movido,
      situacao: Math.abs(movido - esperado) < 0.001 ? 'baixado'
        : movido <= 0 ? 'pendente' : movido < esperado ? 'parcial' : 'duplicado',
      movimentos: movs.map(m => ({ id: m.id, data: m.data, tipo: m.tipo, qtd: Number(m.qtd) || 0, obs: m.obs || '' }))
    };
  });

  const problemas = unidades.reduce((s, u) =>
    s + u.resumo.pendentes + u.resumo.duplicados + u.resumo.semVinculo + u.resumo.foraDaComposicao, 0)
    + pecas.filter(p => p.situacao !== 'baixado').length;

  return {
    vendaId: sale.id, pedido: sale.numero, status: sale.status,
    semOrdem: !ordens.length && (sale.itens || []).some(i => i.kind !== 'peca'),
    unidades, pecas, problemas,
    aguardandoProducao: unidades.filter(u => !u.estoqueBaixado).length
  };
}

/* ------------------------------------------------------------------
   AUDITORIA GERAL DAS BAIXAS

   Separa o que é problema de verdade do que só ainda não chegou a hora:
   ordem que não ficou pronta ainda NÃO deve ter baixado nada.
   ------------------------------------------------------------------ */
function auditarBaixasDeEstoque() {
  const ordens = db.all('productionOrders').filter(p => p.origem !== 'servico' && p.status !== 'cancelado');
  const casos = [], aguardando = [], legado = [];
  let componentesAnalisados = 0, ordensBaixadas = 0;

  for (const po of ordens) {
    const sale = po.saleId ? db.get('sales', po.saleId) : null;
    if (sale && (sale.status === 'cancelado' || sale.status === 'cancelada')) continue;
    const componentes = componentesComSituacao(po);
    componentesAnalisados += componentes.length;
    const pronta = po.status === 'pronto' || po.estoqueBaixado;
    if (pronta) ordensBaixadas++;
    const base = {
      ordemId: po.id, vendaId: po.saleId || null, pedido: po.pedidoNumero,
      cliente: po.clienteNome || '', produto: po.produto,
      tipo: po.tipo, stage: po.stage,
      rotuloStage: po.rotuloStage || domain.rotuloStage(po.stage, po.variante),
      comando: po.comando, tucho: po.tucho, status: po.status,
      estoqueBaixado: !!po.estoqueBaixado,
      baixaLegado: !!po.estoqueBaixado && !(po.consumo || []).length,
      semComposicao: !componentes.length
    };
    if (!pronta) {
      aguardando.push(Object.assign({}, base, { componentes: componentes.length }));
      continue;
    }
    const ruins = componentes.filter(c => SITUACOES_PROBLEMA.includes(c.situacao));
    if (!ruins.length && !base.semComposicao) continue;
    const caso = Object.assign({}, base, {
      componentes: ruins.map(c => ({
        papel: c.papel, stockItemId: c.stockItemId, nome: c.nome, situacao: c.situacao,
        esperado: c.esperado, movido: c.movido, diferenca: c.diferenca, motivo: c.motivo || '',
        corrigivel: !!c.stockItemId && (c.situacao === 'pendente' || c.situacao === 'parcial' || c.situacao === 'duplicado')
      }))
    });
    (base.baixaLegado ? legado : casos).push(caso);
  }

  const contaPorSituacao = (lista) => {
    const m = {};
    for (const c of lista) for (const x of c.componentes || []) m[x.situacao] = (m[x.situacao] || 0) + 1;
    return m;
  };
  /* Vendas de cabeçote sem nenhuma ordem de produção: não há o que baixar. */
  const semOrdem = db.all('sales')
    .filter(s => s.status !== 'cancelado' && s.status !== 'cancelada'
      && (s.itens || []).some(i => i.kind !== 'peca')
      && !db.all('productionOrders').some(p => p.saleId === s.id))
    .map(s => ({ vendaId: s.id, pedido: s.numero, cliente: (db.get('clients', s.clienteId) || {}).nome || '' }));

  /* Produtos cuja composição ainda não foi conferida por gente. */
  const produtosNaoConferidos = db.all('products')
    .filter(p => p.ativo !== false && p.composicaoConfirmada !== true)
    .map(p => ({ id: p.id, nome: p.nome, linhas: (p.composicao || []).length }));

  return {
    geradoEm: new Date().toISOString(),
    ordensAnalisadas: ordens.length, ordensBaixadas, componentesAnalisados,
    totais: {
      casos: casos.length, legado: legado.length, aguardando: aguardando.length,
      semOrdem: semOrdem.length, produtosNaoConferidos: produtosNaoConferidos.length,
      porSituacao: contaPorSituacao(casos.concat(legado))
    },
    casos, legado, aguardando, semOrdem, produtosNaoConferidos
  };
}

/**
 * Corrige baixa por baixa, só o que foi marcado. Nunca em massa e nunca
 * sozinho: cada linha é uma ordem + um componente, com a diferença exata.
 */
function corrigirBaixasDeEstoque(alvos, user) {
  const copia = backupArquivo('antes-corrigir-baixas');
  const feitas = [], ignoradas = [];
  for (const a of alvos) {
    const po = db.get('productionOrders', a.ordemId);
    if (!po) { ignoradas.push({ ordemId: a.ordemId, motivo: 'ordem de produção não encontrada' }); continue; }
    const componentes = componentesComSituacao(po);
    const alvo = componentes.find(c => c.stockItemId === Number(a.stockItemId));
    if (!alvo) { ignoradas.push({ ordemId: a.ordemId, stockItemId: a.stockItemId, motivo: 'componente não faz parte desta ordem' }); continue; }
    const dif = C3(alvo.diferenca);
    if (!dif) { ignoradas.push({ ordemId: po.id, nome: alvo.nome, motivo: 'já está certo — nada a fazer' }); continue; }
    moveStock(alvo.stockItemId, dif > 0 ? 'saida' : 'entrada', Math.abs(dif),
      'productionOrders', po.id,
      dif > 0
        ? `Baixa que faltava — pedido nº ${po.pedidoNumero} (conferência de composição)`
        : `Estorno de baixa em dobro — pedido nº ${po.pedidoNumero} (conferência de composição)`,
      user, { papel: alvo.papel, correcaoAuditoria: true, productId: po.productId || null });
    feitas.push({ ordemId: po.id, pedido: po.pedidoNumero, stockItemId: alvo.stockItemId,
      nome: alvo.nome, situacaoAnterior: alvo.situacao, ajuste: dif });
    /* O consumo da ordem passa a refletir o que ela realmente consumiu. */
    const consumo = componentesComSituacao(db.get('productionOrders', po.id))
      .filter(c => c.papel !== 'extra')
      .map(c => ({ papel: c.papel, stockItemId: c.stockItemId, nome: c.nome, qtd: c.esperado,
        custoUnit: c.custoUnit || 0, baixado: c.situacao === 'baixado' }));
    db.update('productionOrders', po.id, { consumo, estoqueBaixado: true });
  }
  if (feitas.length) {
    audit(user, 'corrigiu', 'stockMoves', null,
      `Conferência de baixas: ${feitas.length} ajuste(s) de estoque, um a um`);
  }
  return { feitas, ignoradas, copiaDeSeguranca: copia, auditoria: auditarBaixasDeEstoque() };
}

/**
 * Ordem de produção com o andamento calculado: etapa atual, progresso de
 * cada etapa e o status derivado do próprio checklist — assim o que a tela
 * mostra nunca briga com o que a equipe marcou.
 */
function andamentoDaOrdem(po) {
  if (!po) return po;
  const checklist = domain.migrarChecklist(po.checklist);
  if (JSON.stringify(checklist) !== JSON.stringify(po.checklist)) {
    db.update('productionOrders', po.id, { checklist });
  }
  const etapas = domain.ETAPAS_PRODUCAO.map(([chave, nome]) => {
    const itens = checklist.filter(c => c.etapa === chave);
    const feitos = itens.filter(c => c.done).length;
    return {
      chave, nome, total: itens.length, feitos,
      situacao: !itens.length ? 'vazia' : feitos === itens.length ? 'concluida' : feitos ? 'andamento' : 'pendente'
    };
  });
  const derivado = domain.statusPorEtapa(checklist);
  // Cancelado é decisão de gente, não do checklist: esse nunca é sobrescrito.
  const status = po.status === 'cancelado' ? 'cancelado' : derivado;
  if (status !== po.status) db.update('productionOrders', po.id, { status });
  return Object.assign({}, db.get('productionOrders', po.id), {
    etapas, etapaAtual: domain.etapaAtual(checklist),
    feitos: checklist.filter(c => c.done).length, totalItens: checklist.length
  });
}

/* ===================================================================== */
/* Sincronização entre módulos                                           */
/* --------------------------------------------------------------------- */
/* O mesmo trabalho aparece em abas diferentes — a OS é o lado comercial, a
   Produção é o lado físico, a Venda é o lado do pedido. Quem registra o
   fato uma vez não deve precisar repetir nas outras. As funções abaixo são
   o único lugar onde essa propagação acontece, e cada uma:
     - só mexe quando o dado realmente representa a MESMA etapa;
     - nunca sobrescreve uma decisão humana (cancelamento);
     - deixa registrado por que mexeu, no histórico e na auditoria.          */
/* ===================================================================== */

/* A ordem em que a produção anda. Serve para saber qual ordem está mais
   atrasada quando uma venda tem vários cabeçotes. */
const PRODUCAO_ORDEM = ['nao_produzido', 'preparacao', 'usinagem', 'montagem', 'pronto'];
/* Estágios de venda que são do EXPEDIÇÃO, não da produção: depois que saiu
   da empresa, a produção não manda mais no status do pedido. */
const VENDA_EXPEDIDA = ['enviado', 'entregue', 'cancelado', 'cancelada'];

/** Anota no histórico da OS o que o sistema fez sozinho, e por quê. */
function historicoOS(os, texto, user) {
  const hist = (os.historico || []).concat([{
    at: new Date().toISOString(), por: user ? user.name : 'sistema',
    evento: texto, automatico: true
  }]);
  db.update('serviceOrders', os.id, { historico: hist });
}

/**
 * Conclui o checklist das ordens de produção de uma OS ou venda.
 *
 * O status de uma ordem de produção NÃO é digitado: ele nasce do checklist
 * (statusPorEtapa). Então, para a Produção reconhecer que o trabalho acabou,
 * o caminho certo é marcar os itens que faltavam — escrever no status seria
 * desfeito no próximo cálculo.
 */
function concluirProducaoDe(filtro, user, motivo) {
  let ordens = 0, itens = 0;
  for (const po of db.all('productionOrders').filter(p => filtro(p) && p.status !== 'cancelado')) {
    const checklist = po.checklist || [];
    const pendentes = checklist.filter(c => !c.done);
    if (!pendentes.length) continue;
    const em = new Date().toISOString();
    for (const c of pendentes) {
      c.done = true;
      c.por = user ? user.name : 'sistema';
      c.em = em;
      c.automatico = motivo; // fica visível no checklist de quem abrir a ordem
    }
    db.update('productionOrders', po.id, { checklist });
    itens += pendentes.length;
    ordens++;
    audit(user, 'sincronizou', 'productionOrders', po.id,
      `Ordem de produção #${po.id} concluída automaticamente porque ${motivo} ` +
      `(${pendentes.length} item(ns) do checklist marcados)`);
    // Ordem pronta baixa os componentes do estoque — uma vez só, como sempre.
    baixarComponentesSePronto(db.get('productionOrders', po.id), user);
  }
  return { ordens, itens };
}

/**
 * Produção → OS.
 * Quando TODAS as ordens de produção de um serviço ficam prontas, o trabalho
 * acabou: a OS passa a "Finalizado" e o cabeçote fica "Pronto para envio".
 * Não mexe em OS cancelada, nem em OS que já passou desse ponto (aguardando
 * pagamento é etapa seguinte, não anterior).
 */
function sincronizarOSComProducao(po, user) {
  if (!po || po.origem !== 'servico' || !po.osId) return;
  const os = db.get('serviceOrders', po.osId);
  if (!os || osCancelada(os)) return;
  const irmas = db.all('productionOrders').filter(p => p.osId === os.id && p.status !== 'cancelado');
  if (!irmas.length || !irmas.every(p => p.status === 'pronto')) return;
  if (['finalizado', 'aguardando_pagamento'].includes(os.status)) return;

  const patch = { status: 'finalizado', dataFinalizacao: os.dataFinalizacao || domain.today() };
  // O cabeçote está pronto para sair; quem já despachou não volta atrás.
  if (!os.envioStatus || os.envioStatus === 'na_empresa') patch.envioStatus = 'pronto';
  db.update('serviceOrders', os.id, patch);
  for (const p of irmas) db.update('productionOrders', p.id, { osStatus: 'finalizado' });

  historicoOS(os, `OS finalizada automaticamente — a produção concluiu o trabalho` +
    (patch.envioStatus === 'pronto' ? ' (cabeçote pronto para envio)' : ''), user);
  audit(user, 'sincronizou', 'serviceOrders', os.id,
    `OS nº ${os.numero} → Finalizado automaticamente porque a ordem de produção #${po.id} ficou pronta`);
  db.insert('audit', {
    at: new Date().toISOString(), userId: user ? user.id : null, userName: user ? user.name : 'sistema',
    action: 'timeline', entity: 'serviceOrders', entityId: os.id, clientId: os.clienteId,
    details: `OS nº ${os.numero} finalizada automaticamente pela conclusão da produção`
  });
}

/**
 * Produção → Venda.
 * O status do pedido de cabeçote é o andamento do que está sendo produzido
 * nele — o pedido não tem andamento próprio. Com vários cabeçotes, vale o
 * mais atrasado: o pedido só fica pronto quando o último ficar.
 * Pedido já enviado/entregue/cancelado é assunto da expedição, não da
 * produção: esse não é tocado.
 */
function sincronizarVendaComProducao(po, user) {
  if (!po || po.origem === 'servico' || !po.saleId) return;
  const sale = db.get('sales', po.saleId);
  if (!sale || VENDA_EXPEDIDA.includes(sale.status)) return;
  const irmas = db.all('productionOrders').filter(p => p.saleId === sale.id && p.status !== 'cancelado');
  if (!irmas.length) return;
  const indice = irmas.reduce((menor, p) => {
    const i = PRODUCAO_ORDEM.indexOf(p.status);
    return Math.min(menor, i < 0 ? 0 : i);
  }, PRODUCAO_ORDEM.length - 1);
  const novo = PRODUCAO_ORDEM[indice];
  if (!novo || novo === sale.status) return;

  db.update('sales', sale.id, { status: novo });
  audit(user, 'sincronizou', 'sales', sale.id,
    `Pedido nº ${sale.numero} → ${novo} automaticamente, acompanhando a produção` +
    (irmas.length > 1 ? ` (${irmas.length} cabeçotes — vale o mais atrasado)` : ''));
}

/**
 * OS → Bem de terceiro e Entrada de cabeçote.
 * O cabeçote do cliente aparece em três lugares: a entrada que o registrou, o
 * bem guardado e a OS. Quem despachou o cabeçote pela OS não precisa ir
 * baixar o bem em "Bens de clientes" nem mexer na entrada.
 */
function sincronizarEntregaDaOS(os, user) {
  if (!os) return;
  const entregue = os.envioStatus === 'entregue' || os.envioStatus === 'enviado';
  const entry = os.entryId ? db.get('headEntries', os.entryId) : null;

  if (entry && entregue && entry.status !== 'entregue') {
    db.update('headEntries', entry.id, { status: 'entregue' });
    audit(user, 'sincronizou', 'headEntries', entry.id,
      `Entrada ${entry.codigo} → entregue automaticamente porque a OS nº ${os.numero} foi ${
        os.envioStatus === 'entregue' ? 'entregue' : 'enviada'}`);
  }
  /* O bem só sai da empresa de verdade quando é entregue. "Enviado" ainda
     está a caminho, mas já não está aqui — a data de saída é a do envio. */
  const assetId = (entry && entry.assetId) || null;
  const asset = assetId ? db.get('assets', assetId) : null;
  if (asset && entregue && asset.status !== 'devolvido') {
    db.update('assets', asset.id, {
      status: 'devolvido',
      dataSaida: asset.dataSaida || domain.today(),
      nfRetorno: asset.nfRetorno || os.nfRetorno || ''
    });
    audit(user, 'sincronizou', 'assets', asset.id,
      `Bem "${asset.identificacao}" baixado automaticamente porque a OS nº ${os.numero} foi ${
        os.envioStatus === 'entregue' ? 'entregue' : 'enviada'}${os.nfRetorno ? ' — NF retorno ' + os.nfRetorno : ''}`);
    db.insert('audit', {
      at: new Date().toISOString(), userId: user ? user.id : null, userName: user ? user.name : 'sistema',
      action: 'timeline', entity: 'assets', entityId: asset.id, clientId: asset.clienteId,
      details: `Bem devolvido junto com o envio da OS nº ${os.numero}: ${asset.identificacao}`
    });
  }
}

/** Cria as ordens de produção dos cabeçotes de uma venda. */
function gerarProducaoDaVenda(sale, cliente, user) {
  const itens = sale.itens || [], numero = sale.numero;
  // Ordens de produção (uma por unidade de cabeçote) com checklist automático.
  for (const item of itens.filter(i => i.kind !== 'peca')) {
    for (let u = 0; u < item.qtd; u++) {
      db.insert('productionOrders', {
        origem: 'venda',
        saleId: sale.id, pedidoNumero: numero, clienteId: cliente.id, clienteNome: cliente.nome,
        productId: item.productId, produto: item.produto,
        tipo: item.tipo, stage: item.stage, variante: item.variante || '',
        rotuloStage: item.rotuloStage || domain.rotuloStage(item.stage, item.variante),
        comando: item.comando, tucho: item.tucho,
        qtd: 1, qtdPedido: item.qtd,
        observacoes: sale.observacoes || '',
        /* A separação do checklist sai da composição cadastrada: a bancada
           vê peça e quantidade iguais ao que o estoque vai baixar. */
        checklist: domain.productionChecklist(item.tipo, item.stage, item.comando, item.tucho,
          composicaoResolvida(db.get('products', item.productId),
            { tipo: item.tipo, comando: item.comando, tucho: item.tucho }), item.variante),
        status: 'nao_produzido', responsavelId: suggestAssignee('production'),
        previsaoEntrega: sale.previsaoEntrega
      });
    }
  }
}

/**
 * Ordem de produção do serviço de um cabeçote de cliente. Nasce da OS —
 * a equipe nunca redigita nada. Idempotente: se a OS já tem ordem, atualiza
 * os dados (menos o que já foi marcado) em vez de criar outra.
 */
function gerarProducaoDaOS(os, user) {
  if (!os || osCancelada(os)) return null;
  const cliente = db.get('clients', os.clienteId);
  const operacoes = (os.itens || []).filter(i => i && i.nome)
    .map(i => ({ nome: i.nome, qtd: Number(i.qtd) || 1 }));
  // "Peças necessárias" saem das linhas de material/componente do custo do serviço.
  const pecas = (os.custoBase || []).concat(os.custoReal || [])
    .filter(c => ['materiais', 'componentes'].includes(c.tipo) && c.descricao)
    .map(c => c.descricao);
  const dados = {
    origem: 'servico',
    osId: os.id, osNumero: os.numero, quoteId: os.quoteId || null,
    clienteId: os.clienteId, clienteNome: cliente ? cliente.nome : '',
    produto: os.modelo || 'Cabeçote de cliente',
    identificacao: os.identificacao || '',
    problema: os.problema || '',
    descricaoServico: os.descricaoServico || '',
    operacoes,
    pecas: [...new Set(pecas)],
    observacoes: os.observacoes || '',
    previsaoEntrega: os.previsaoEntrega || '',
    osStatus: os.status
  };
  const existente = db.all('productionOrders').find(p => p.osId === os.id && p.status !== 'cancelado');
  if (existente) {
    // Nunca sobrescreve o andamento: só reflete os dados da OS.
    db.update('productionOrders', existente.id, dados);
    return db.get('productionOrders', existente.id);
  }
  return db.insert('productionOrders', Object.assign({}, dados, {
    checklist: domain.serviceChecklist(os),
    status: 'nao_produzido',
    responsavelId: os.responsavelId || suggestAssignee('production')
  }));
}

/** Cria contas a receber / caixa de uma venda, conforme a forma de pagamento. */
/**
 * Financeiro de uma venda: o que o cliente DEVE pagar.
 *
 * REGRA FUNDAMENTAL: cadastrar uma venda não é receber dinheiro. Esta função
 * só cria contas a receber — nunca lança entrada no Fluxo de caixa. O caixa
 * é alimentado exclusivamente por "Registrar recebimento" (que grava o
 * recebimento na venda e a entrada correspondente no caixa).
 *
 * Isto já esteve errado: venda em Pix ou dinheiro "à vista" lançava sozinha
 * o valor cheio no caixa e criava um recebível já quitado. Quem depois
 * registrava o recebimento de verdade via o mesmo valor entrar duas vezes.
 * "À vista" é condição de pagamento, não comprovante de pagamento.
 */
function gerarFinanceiroDaVenda(sale, cliente, user) {
  const { valorTotal, numero, pagamento } = sale;
  if (pagamento.condicao === 'parcelado' && (pagamento.forma === 'boleto' || pagamento.forma === 'cheque')) {
    const parcels = domain.generateInstallments(sale.dataPedido, valorTotal,
      pagamento.parcelas, pagamento.intervaloDias, pagamento.primeiroVencimento);
    for (const p of parcels) {
      db.insert('receivables', {
        clienteId: cliente.id, origem: 'venda', refType: 'sales', refId: sale.id,
        descricao: `Pedido nº ${numero} — parcela ${p.parcela}/${p.parcelas}`,
        forma: pagamento.forma, valor: p.valor, vencimento: p.vencimento,
        status: 'aberto', parcela: p.parcela, parcelas: p.parcelas
      });
    }
  } else if (pagamento.forma === 'cartao' || pagamento.forma === 'link') {
    db.insert('receivables', {
      clienteId: cliente.id, origem: 'venda', refType: 'sales', refId: sale.id,
      descricao: `Pedido nº ${numero} — ${pagamento.forma} ${pagamento.parcelas || 1}x (líquido de taxa)`,
      /* Cobrança própria: a baixa é dada nesta linha, pelo líquido que a
         operadora deposita — não é espelho do valor cheio do pedido. */
      cobrancaPropria: true,
      forma: pagamento.forma, valor: pagamento.valorLiquido,
      vencimento: pagamento.dataPrevRecebimento || domain.addDays(sale.dataPedido, 30),
      status: 'aberto', parcela: 1, parcelas: 1, taxa: pagamento.taxa
    });
    if (pagamento.taxa > 0) {
      db.insert('cashflow', {
        tipo: 'saida', valor: pagamento.taxa, data: sale.dataPedido, conta: 'operadora',
        formaPagamento: 'cartao_credito',
        categoria: 'taxa_cartao', origem: `Pedido nº ${numero}`, documento: '',
        refType: 'sales', refId: sale.id, descricao: 'Taxa da operadora (cartão/link)'
      });
    }
  } else {
    /* Todo o resto — Pix, dinheiro, boleto/cheque à vista, outro — vira UMA
       linha em Contas a receber espelhando a venda: valor devido, quanto já
       entrou e a situação. Quem mantém essa linha em dia é uma função só,
       usada também a cada recebimento, edição e cancelamento. */
    sincronizarReceberDaVenda(sale, { forma: pagamento.forma });
  }
}

/* ---------------------------------------------------------------------
   Quanto já entrou de uma venda, e quanto falta.

   O dinheiro de uma venda pode chegar por dois caminhos, e só por eles:
     1. "Registrar recebimento" na venda  → sale.recebimentos
     2. baixa de uma parcela em Contas a receber → recebido da parcela
   Os dois são somados aqui, uma vez cada. Nenhum outro lugar cria
   recebimento de venda — é isso que impede o valor de contar em dobro.   */
/* A linha da venda em Contas a receber é um ESPELHO: ela mostra o valor da
   venda, quanto já entrou e quanto falta, mas o dinheiro não mora nela —
   mora em sale.recebimentos. Por isso ela nunca entra na soma do recebido:
   somar as duas contaria o mesmo dinheiro duas vezes.

   O caso do boleto parcelado é outro: ali cada parcela é um registro
   financeiro de verdade, com o próprio recebimento, e é ela que soma. */
/* Cartão e link têm cobrança própria: o valor a receber é o líquido que a
   operadora deposita, e a baixa é dada naquela linha. */
const FORMAS_COBRANCA_PROPRIA = ['cartao', 'link'];

/**
 * A linha da venda em Contas a receber é ESPELHO ou COBRANÇA PRÓPRIA?
 *
 *   ESPELHO           projeta a venda: valor do pedido, quanto já entrou e a
 *                     situação. O dinheiro mora em sale.recebimentos.
 *   COBRANÇA PRÓPRIA  guarda o próprio recebimento. É o caso das parcelas de
 *                     um plano de boleto/cheque e da cobrança de cartão/link.
 *
 * Linha única e antiga (sem marca) de uma venda conta como espelho: é assim
 * que o histórico é religado em cima do registro que já existe, mantendo id,
 * vencimento e observações.
 */
function ehEspelhoDaVenda(r) {
  if (!r || r.refType !== 'sales') return false;
  if (r.espelhoVenda === true || r.origem === 'saldo') return true;
  if ((Number(r.parcelas) || 1) > 1) return false;          // parcela de plano
  if (r.cobrancaPropria === true) return false;             // marcada na origem
  if (FORMAS_COBRANCA_PROPRIA.includes(String(r.forma || '').toLowerCase())) return false;
  return r.origem === 'venda';
}

/** Cobranças próprias de uma venda — onde o dinheiro mora, quando é o caso. */
function parcelasDaVenda(saleId) {
  return db.all('receivables').filter(r =>
    r.refType === 'sales' && r.refId === saleId && !ehEspelhoDaVenda(r));
}
/** A venda tem cobrança própria (parcelas ou cartão)? Então não tem espelho. */
function vendaComPlano(saleId) {
  return parcelasDaVenda(saleId).length > 0;
}

function recebidoDaVenda(sale) {
  const naVenda = (sale.recebimentos || []).reduce((s, r) => s + (Number(r.valor) || 0), 0);
  const nasParcelas = parcelasDaVenda(sale.id).reduce((s, r) => s + recebidoDaParcela(r), 0);
  return Math.round((naVenda + nasParcelas) * 100) / 100;
}

function resumoFinanceiroVenda(sale) {
  const total = Math.round((Number(sale.valorTotal) || 0) * 100) / 100;
  const recebido = recebidoDaVenda(sale);
  return { total, recebido, saldo: Math.round((total - recebido) * 100) / 100 };
}

route('POST', '/api/sales', 'sales', async (req, res, user) => {
  const b = await readBody(req);
  const cliente = db.get('clients', b.clienteId);
  if (!cliente) return bad(res, 'Cliente é obrigatório');
  if (!Array.isArray(b.itens) || !b.itens.length) return bad(res, 'A venda precisa de ao menos um item');

  const montado = montarItensVenda(b.itens);
  if (montado.erro) return bad(res, montado.erro);
  const { itens, valorTotal, custoBaseTotal } = montado;

  const pagamento = b.pagamento || {};
  pagamento.taxa = Number(pagamento.taxa) || 0;
  pagamento.valorLiquido = valorTotal - pagamento.taxa;

  const numero = db.nextNumber('pedido', 1);
  const sale = db.insert('sales', {
    numero, clienteId: cliente.id,
    cidade: b.cidade || cliente.cidade || '', estado: b.estado || cliente.estado || '',
    dataPedido: b.dataPedido || domain.today(),
    previsaoEntrega: b.previsaoEntrega || '', dataEnvio: null,
    itens, valorTotal,
    custoBaseTotal,
    custosAdicionais: b.custosAdicionais || [], // [{desc, valor}] — frete grátis, brindes extras...
    pagamento,
    recebimentos: [],          // pagamentos parciais: [{valor, data, forma, obs}]
    observacoes: b.observacoes || '',
    status: 'nao_produzido' // nao_produzido → preparacao → usinagem → montagem → pronto → enviado → entregue
  });

  // Peças do estoque saem na hora da venda (cabeçotes saem na produção).
  estoquePecasDaVenda(sale, user);
  gerarProducaoDaVenda(sale, cliente, user);
  gerarFinanceiroDaVenda(sale, cliente, user);

  audit(user, 'criou', 'sales', sale.id, `Pedido nº ${numero} — ${cliente.nome} — R$ ${valorTotal.toFixed(2)}`);
  db.insert('audit', {
    at: new Date().toISOString(), userId: user.id, userName: user.name, action: 'timeline',
    entity: 'sales', entityId: sale.id, clientId: cliente.id,
    details: `Pedido nº ${numero} registrado (R$ ${valorTotal.toFixed(2)})`
  });
  ok(res, sale);
});

const SALE_STATUS = ['nao_produzido', 'preparacao', 'usinagem', 'montagem', 'pronto', 'enviado', 'entregue', 'cancelado'];
/**
 * Cancelar um pedido é uma decisão comercial que precisa atravessar o
 * sistema inteiro. Antes, marcar "Cancelado" mudava só a etiqueta: os
 * boletos continuavam sendo cobrados, a produção continuava na fila e as
 * peças seguiam baixadas do estoque.
 */
function cancelarVendaEDependentes(sale, user, motivo) {
  const efeitos = [];

  // Parcelas em aberto saem da cobrança; as recebidas ficam (o dinheiro entrou).
  const recs = db.all('receivables').filter(r => r.refType === 'sales' && r.refId === sale.id);
  const aCancelar = recs.filter(r => r.status !== 'paga' && r.status !== 'cancelada');
  for (const r of aCancelar) db.update('receivables', r.id, { status: 'cancelada' });
  if (aCancelar.length) efeitos.push(`${aCancelar.length} parcela(s) em aberto cancelada(s)`);
  const recebidas = recs.filter(r => r.status === 'paga' || r.status === 'parcial');
  if (recebidas.length) {
    efeitos.push(`${recebidas.length} parcela(s) já com recebimento mantida(s) — o dinheiro entrou e continua no caixa`);
  }

  // Produção: sai da fila. A que já consumiu componentes fica registrada.
  const pos = db.all('productionOrders').filter(p => p.saleId === sale.id && p.status !== 'cancelado');
  let consumiram = 0;
  for (const po of pos) {
    db.update('productionOrders', po.id, { status: 'cancelado', vendaStatus: 'cancelado' });
    if (po.estoqueBaixado) consumiram++;
  }
  if (pos.length) efeitos.push(`${pos.length} ordem(ns) de produção cancelada(s)`);
  if (consumiram) {
    efeitos.push(`${consumiram} dela(s) já tinha(m) consumido componentes — o estoque desses NÃO foi devolvido automaticamente`);
  }

  // Peças de revenda voltam para a prateleira: não foram vendidas.
  if (sale.estoquePecasBaixado) {
    estoquePecasDaVenda(sale, user, { devolver: true });
    efeitos.push('peças de revenda devolvidas ao estoque');
  }

  db.update('sales', sale.id, { status: 'cancelado', canceladaEm: domain.today(), motivoCancelamento: motivo || '' });
  audit(user, 'cancelou', 'sales', sale.id,
    `Pedido nº ${sale.numero} cancelado${motivo ? ' — ' + motivo : ''}` +
    (efeitos.length ? `; ${efeitos.join('; ')}` : ''));
  db.insert('audit', {
    at: new Date().toISOString(), userId: user.id, userName: user.name, action: 'timeline',
    entity: 'sales', entityId: sale.id, clientId: sale.clienteId,
    details: `Pedido nº ${sale.numero} cancelado${motivo ? ': ' + motivo : ''}`
  });
  return efeitos;
}

route('POST', '/api/sales/:id/cancel', 'sales', async (req, res, user, params) => {
  const b = await readBody(req);
  const sale = db.get('sales', params.id);
  if (!sale) return notFound(res);
  if (sale.status === 'cancelado') return bad(res, 'Este pedido já está cancelado.');
  const efeitos = cancelarVendaEDependentes(sale, user, b.motivo);
  ok(res, { ok: true, efeitos, venda: db.get('sales', sale.id) });
});

route('POST', '/api/sales/:id/status', 'sales', async (req, res, user, params) => {
  const b = await readBody(req);
  const sale = db.get('sales', params.id);
  if (!sale) return notFound(res);
  if (!SALE_STATUS.includes(b.status)) return bad(res, 'Status inválido');

  /* Cancelar não é uma etiqueta: passa pelo caminho que desfaz a cobrança,
     a produção e o estoque. */
  if (b.status === 'cancelado') {
    if (sale.status === 'cancelado') return bad(res, 'Este pedido já está cancelado.');
    const efeitos = cancelarVendaEDependentes(sale, user, b.motivo);
    return ok(res, Object.assign({}, db.get('sales', sale.id), { efeitos }));
  }
  if (sale.status === 'cancelado') {
    return bad(res, 'Este pedido está cancelado. Para refazer o trabalho, use Duplicar — assim o histórico do cancelamento continua de pé.');
  }

  const patch = { status: b.status };
  if (b.status === 'enviado') patch.dataEnvio = b.data || domain.today();
  db.update('sales', sale.id, patch);

  /* Despachar o pedido quer dizer que os cabeçotes ficaram prontos: a
     produção reconhece a conclusão sem ninguém remarcar o checklist. */
  if (['pronto', 'enviado', 'entregue'].includes(b.status)) {
    const rotulo = { pronto: 'ficou pronto', enviado: 'foi enviado', entregue: 'foi entregue' }[b.status];
    concluirProducaoDe(p => p.saleId === sale.id, user, `o pedido nº ${sale.numero} ${rotulo}`);
  }
  audit(user, 'status', 'sales', sale.id, `Pedido nº ${sale.numero} → ${b.status}`);
  ok(res, db.get('sales', sale.id));
});

/* Editar venda: atualiza o lançamento existente. Se mexer em itens, valor
   ou pagamento, desfaz o que a venda gerou e refaz — nunca duplica. */
route('PUT', '/api/sales/:id', 'sales', async (req, res, user, params) => {
  const antes = db.get('sales', params.id);
  if (!antes) return notFound(res);
  const b = await readBody(req);

  const mexeEstruturaOuDinheiro = b.itens !== undefined || b.pagamento !== undefined;
  let itens = antes.itens, valorTotal = antes.valorTotal, custoBaseTotal = antes.custoBaseTotal;
  if (b.itens !== undefined) {
    if (!Array.isArray(b.itens) || !b.itens.length) return bad(res, 'A venda precisa de ao menos um item');
    const m = montarItensVenda(b.itens);
    if (m.erro) return bad(res, m.erro);
    ({ itens, valorTotal, custoBaseTotal } = m);
  }

  if (mexeEstruturaOuDinheiro) {
    const travas = reverterVenda(antes, user);
    if (travas) {
      return bad(res, 'Não dá para alterar os itens ou o pagamento desta venda porque ' + travas.join('; ') +
        '. Desfaça o recebimento (ou o estoque da produção) antes, ou edite apenas os dados cadastrais.');
    }
  }

  const cliente = b.clienteId ? db.get('clients', b.clienteId) : db.get('clients', antes.clienteId);
  if (!cliente) return bad(res, 'Cliente inválido');
  const pagamento = b.pagamento !== undefined ? Object.assign({}, b.pagamento) : antes.pagamento;
  pagamento.taxa = Number(pagamento.taxa) || 0;
  pagamento.valorLiquido = valorTotal - pagamento.taxa;

  const patch = {
    clienteId: cliente.id,
    cidade: b.cidade !== undefined ? b.cidade : antes.cidade,
    estado: b.estado !== undefined ? b.estado : antes.estado,
    dataPedido: b.dataPedido || antes.dataPedido,
    previsaoEntrega: b.previsaoEntrega !== undefined ? b.previsaoEntrega : antes.previsaoEntrega,
    itens, valorTotal, custoBaseTotal, pagamento,
    custosAdicionais: b.custosAdicionais !== undefined ? b.custosAdicionais : antes.custosAdicionais,
    observacoes: b.observacoes !== undefined ? b.observacoes : antes.observacoes
  };
  if (mexeEstruturaOuDinheiro) patch.estoquePecasBaixado = false;

  const sale = db.update('sales', antes.id, patch);

  if (mexeEstruturaOuDinheiro) {
    estoquePecasDaVenda(sale, user);
    gerarProducaoDaVenda(sale, cliente, user);
    gerarFinanceiroDaVenda(sale, cliente, user);
  }

  const mudou = [];
  if (antes.valorTotal !== sale.valorTotal) mudou.push(`Valor: ${antes.valorTotal} → ${sale.valorTotal}`);
  if (antes.clienteId !== sale.clienteId) mudou.push('Cliente alterado');
  if (JSON.stringify(antes.itens) !== JSON.stringify(sale.itens)) mudou.push(`Itens: ${antes.itens.length} → ${sale.itens.length}`);
  audit(user, 'alterou', 'sales', sale.id, `Pedido nº ${sale.numero} editado${mudou.length ? ' — ' + mudou.join('; ') : ''}`);
  ok(res, sale);
});

/* Duplicar: nova venda independente, com a original como modelo. */
route('POST', '/api/sales/:id/duplicate', 'sales', async (req, res, user, params) => {
  const origem = db.get('sales', params.id);
  if (!origem) return notFound(res);
  const b = await readBody(req);
  const cliente = db.get('clients', b.clienteId || origem.clienteId);
  if (!cliente) return bad(res, 'Cliente inválido');

  const m = montarItensVenda(origem.itens.map(i => i.kind === 'peca'
    ? { kind: 'peca', stockItemId: i.stockItemId, qtd: i.qtd, valorUnit: i.valorUnit }
    : { productId: i.productId, comando: i.comando, tucho: i.tucho, qtd: i.qtd, valorUnit: i.valorUnit }));
  if (m.erro) return bad(res, m.erro);

  const numero = db.nextNumber('pedido', 1);
  const sale = db.insert('sales', {
    numero, clienteId: cliente.id,
    cidade: cliente.cidade || '', estado: cliente.estado || '',
    dataPedido: b.dataPedido || domain.today(),
    previsaoEntrega: '', dataEnvio: null,
    itens: m.itens, valorTotal: m.valorTotal, custoBaseTotal: m.custoBaseTotal,
    custosAdicionais: [],
    pagamento: { forma: (origem.pagamento || {}).forma || 'pix', taxa: 0, valorLiquido: m.valorTotal },
    recebimentos: [],
    observacoes: origem.observacoes || '',
    status: 'nao_produzido',
    duplicadoDe: origem.numero
  });
  estoquePecasDaVenda(sale, user);
  gerarProducaoDaVenda(sale, cliente, user);
  gerarFinanceiroDaVenda(sale, cliente, user);
  audit(user, 'criou', 'sales', sale.id, `Pedido nº ${numero} duplicado do nº ${origem.numero} — ${cliente.nome}`);
  ok(res, sale);
});

route('DELETE', '/api/sales/:id', 'sales', async (req, res, user, params) => {
  const sale = db.get('sales', params.id);
  if (!sale) return notFound(res);
  const travas = reverterVenda(sale, user);
  if (travas) {
    return bad(res, 'Esta venda não pode ser excluída porque ' + travas.join('; ') +
      '. Cancele o recebimento (Contas a receber) ou estorne a produção antes — assim o estoque e o caixa não ficam errados.');
  }
  db.remove('sales', sale.id);
  audit(user, 'excluiu', 'sales', sale.id, `Pedido nº ${sale.numero} excluído — produção, recebíveis e estoque de peças estornados`);
  ok(res, { ok: true });
});

/* Recebimento parcial: entrada + saldo na entrega, por exemplo.
   O saldo continua em contas a receber e na projeção. */
/**
 * Depois de abater qualquer coisa numa venda — dinheiro recebido ou crédito
 * do cliente usado — Contas a receber precisa mostrar só o que ainda falta.
 * Sem isto o mesmo valor apareceria duas vezes: a cobrança cheia e o saldo.
 * Devolve o saldo que sobrou.
 */
/**
 * Deixa o registro de saldo em Contas a receber igual ao que ainda falta
 * receber da venda. Não mexe em dinheiro: só na cobrança.
 *
 * Quitada, a linha de saldo SAI de Contas a receber. Antes ela ficava lá
 * marcada como "paga" guardando o valor antigo — e aí o sistema somava
 * aquele valor como recebido ALÉM dos recebimentos da venda, mostrando
 * "recebido" maior que o total e saldo negativo ("a devolver ao cliente").
 * O que foi recebido continua registrado na venda e no Fluxo de caixa.
 */
/**
 * Põe a linha da venda em Contas a receber em dia com a venda.
 *
 * Esta linha é o ESPELHO da venda: valor da venda, quanto já entrou, quanto
 * falta e a situação (a vencer / parcialmente pago / pago). Ela não guarda
 * dinheiro — projeta o que está registrado na venda. Por isso:
 *   - nunca encolhe: o valor continua sendo o valor da venda;
 *   - nunca desaparece quando a venda é quitada — fica como "Pago";
 *   - sincronizar duas vezes não muda nada e não cria lançamento algum.
 *
 * Antes daqui a linha era um "saldo em aberto" que encolhia a cada
 * recebimento e era APAGADA ao quitar. Era por isso que uma venda recebida
 * em Vendas parecia não existir em Contas a receber, e uma venda recebida
 * em parte mostrava só o resto, sem o total nem o quanto já tinha entrado.
 *
 * Venda com plano de parcelas não tem espelho: lá cada parcela é o registro
 * financeiro, com o próprio recebimento.
 */
function sincronizarReceberDaVenda(sale, { data, forma, vencimentoSaldo } = {}) {
  const atual = db.get('sales', sale.id) || sale;
  const espelho = db.all('receivables').find(r =>
    r.refType === 'sales' && r.refId === atual.id && ehEspelhoDaVenda(r));

  // Com plano de parcelas, as parcelas mandam: o espelho sai de cena.
  if (vendaComPlano(atual.id)) {
    if (espelho) db.remove('receivables', espelho.id);
    return resumoFinanceiroVenda(atual).saldo;
  }

  const { total, recebido, saldo } = resumoFinanceiroVenda(atual);
  const cancelada = atual.status === 'cancelado' || atual.status === 'cancelada';
  const ultimo = (atual.recebimentos || []).slice(-1)[0];
  const situacao = cancelada ? 'cancelada'
    : saldo <= 0.005 && total > 0 ? 'paga'
      : recebido > 0.005 ? 'parcial' : 'aberto';

  const dados = {
    clienteId: atual.clienteId, origem: 'venda', refType: 'sales', refId: atual.id,
    espelhoVenda: true,
    descricao: `Pedido nº ${atual.numero}`,
    forma: forma || (atual.pagamento || {}).forma || 'pix',
    valor: total,
    recebido,
    status: situacao,
    dataRecebimento: ultimo ? ultimo.data : null,
    parcela: 1, parcelas: 1
  };
  if (espelho) {
    // Mantém o vencimento que já estava lá (alguém pode ter ajustado).
    dados.vencimento = vencimentoSaldo || espelho.vencimento
      || atual.previsaoEntrega || atual.dataPedido || domain.today();
    db.update('receivables', espelho.id, dados);
  } else {
    dados.vencimento = vencimentoSaldo
      || (atual.pagamento || {}).vencimento
      || ((atual.pagamento || {}).condicao !== 'parcelado' ? atual.dataPedido : '')
      || atual.previsaoEntrega || domain.addDays(data || atual.dataPedido || domain.today(), 7);
    db.insert('receivables', dados);
  }
  return saldo;
}

/* Nome antigo mantido para as chamadas que já existem. */
function ajustarSaldoDaVenda(sale, opcoes = {}) {
  return sincronizarReceberDaVenda(sale, opcoes);
}

/**
 * Depois de abater qualquer coisa numa venda — dinheiro recebido ou crédito
 * do cliente usado — Contas a receber precisa mostrar só o que ainda falta.
 * A cobrança cheia em aberto dá lugar ao saldo.
 */
function reequilibrarReceberDaVenda(sale, opcoes = {}) {
  /* Limpa cobrança antiga em aberto que não é parcela nem espelho — resto
     de versões anteriores. Parcela com dinheiro dentro nunca é tocada. */
  /* Mais de um espelho para a mesma venda (resto de versões anteriores):
     fica o mais antigo, que é o que carrega vencimento e observações. */
  const espelhos = db.all('receivables')
    .filter(r => r.refType === 'sales' && r.refId === sale.id && ehEspelhoDaVenda(r))
    .sort((a, b) => a.id - b.id);
  for (const extra of espelhos.slice(1)) db.remove('receivables', extra.id);
  return sincronizarReceberDaVenda(sale, opcoes);
}

route('POST', '/api/sales/:id/receive', 'receivables', async (req, res, user, params) => {
  const b = await readBody(req);
  const sale = db.get('sales', params.id);
  if (!sale) return notFound(res);
  const valor = Math.round((Number(b.valor) || 0) * 100) / 100;
  if (valor <= 0) return bad(res, 'Informe o valor recebido.');
  /* O saldo considera TUDO que já entrou desta venda — recebimentos
     lançados aqui e parcelas baixadas em Contas a receber. É esta conta que
     impede receber duas vezes o mesmo valor. */
  /* Com plano de boleto, o registro financeiro é a PARCELA. Receber aqui
     criaria um segundo controle do mesmo dinheiro. */
  if (vendaComPlano(sale.id) && !b.confirmarPlano) {
    const n = parcelasDaVenda(sale.id).length;
    return bad(res, `Este pedido tem ${n} cobrança(s) própria(s) em Contas a receber ` +
      `(${n > 1 ? 'parcelas do plano' : 'cartão/link'}). Dê a baixa lá — em Contas a receber → Boletos a receber — ` +
      'para o dinheiro ser registrado uma vez só.');
  }
  const resumo = resumoFinanceiroVenda(sale);
  if (valor > resumo.saldo + 0.005) {
    return bad(res, `Desta venda já entraram ${brl(resumo.recebido)} de ${brl(resumo.total)}. ` +
      `Falta receber ${brl(resumo.saldo)} — não dá para lançar ${brl(valor)}.`);
  }
  const data = b.data || domain.today();
  /* Proteção contra duplicidade: mesmo valor na mesma data já lançado nesta
     venda quase sempre é o segundo clique, não um segundo pagamento. */
  const igual = (sale.recebimentos || []).find(r =>
    Math.round((Number(r.valor) || 0) * 100) === Math.round(valor * 100) && r.data === data);
  if (igual && !b.confirmar) {
    return send(res, 409, {
      error: `Já existe um recebimento de ${brl(valor)} em ${dataBR(data)} neste pedido. ` +
             'Lançar de novo somaria o mesmo dinheiro duas vezes. O cliente pagou duas vezes esse valor?',
      precisaConfirmar: true
    });
  }
  /* Cada recebimento ganha um identificador próprio, e a entrada de caixa
     que ele gera carrega esse identificador. É isso que permite estornar e
     reconciliar pelo vínculo, em vez de procurar por valor e data — e o que
     garante que o mesmo recebimento nunca gere duas entradas. */
  const recId = db.nextNumber('recebimentoVenda', 1);
  const rec = { recId, valor, data, forma: b.forma || 'pix', obs: b.obs || '', por: user.name };
  const lista = (sale.recebimentos || []).concat([rec]);
  db.update('sales', sale.id, { recebimentos: lista });
  db.insert('cashflow', {
    tipo: 'entrada', valor, data, conta: b.conta || 'principal',
    formaPagamento: normalizaForma(rec.forma) || 'outro',
    categoria: 'venda_cabecote', origem: `Pedido nº ${sale.numero} — recebimento`,
    documento: '', refType: 'sales', refId: sale.id, recebimentoId: recId,
    descricao: `Recebimento (${rec.forma})`
  });

  const novoSaldo = reequilibrarReceberDaVenda(sale,
    { data, forma: b.forma, vencimentoSaldo: b.vencimentoSaldo });

  audit(user, 'recebeu', 'sales', sale.id,
    `Pedido nº ${sale.numero} — recebido R$ ${valor.toFixed(2)} (${rec.forma}); saldo R$ ${novoSaldo.toFixed(2)}`);
  ok(res, { recebido: lista.reduce((s, r) => s + r.valor, 0), saldo: novoSaldo });
});

route('POST', '/api/sales/:id/unreceive', 'receivables', async (req, res, user, params) => {
  const b = await readBody(req);
  const sale = db.get('sales', params.id);
  if (!sale) return notFound(res);
  const idx = Number(b.index);
  const lista = (sale.recebimentos || []).slice();
  if (!lista[idx]) return bad(res, 'Recebimento não encontrado.');
  const [removido] = lista.splice(idx, 1);
  db.update('sales', sale.id, { recebimentos: lista });
  /* Estorna a entrada daquele recebimento pelo identificador. Recebimentos
     antigos (sem identificador) caem no casamento por valor e data. */
  const cx = db.all('cashflow').find(c => c.refType === 'sales' && c.refId === sale.id &&
    c.tipo === 'entrada' && removido.recId && c.recebimentoId === removido.recId)
    || db.all('cashflow').find(c => c.refType === 'sales' && c.refId === sale.id &&
      c.tipo === 'entrada' && !c.recebimentoId &&
      Math.round((Number(c.valor) || 0) * 100) === Math.round((Number(removido.valor) || 0) * 100) &&
      c.data === removido.data);
  if (cx) db.remove('cashflow', cx.id);
  // A dívida volta para Contas a receber pelo que passou a faltar.
  const novoSaldo = ajustarSaldoDaVenda(sale, { data: removido.data });
  audit(user, 'estornou', 'sales', sale.id, `Recebimento de R$ ${removido.valor.toFixed(2)} desfeito — saldo R$ ${novoSaldo.toFixed(2)}`);
  ok(res, { saldo: novoSaldo });
});

/** Resumo financeiro da venda para a tela — a mesma conta que o servidor usa. */
/** Dados comuns de uma configuração vindos da tela, já validados. */
function lerConfiguracao(b, atual) {
  const tipo = b.tipo !== undefined ? String(b.tipo) : (atual ? atual.tipo : '');
  if (!['unilateral', 'crossflow'].includes(tipo)) {
    return { erro: 'A linha do cabeçote precisa ser Unilateral ou Fluxo Cruzado.' };
  }
  const stage = b.stage !== undefined ? Number(b.stage) : Number(atual && atual.stage);
  if (!stage || stage < 1) return { erro: 'Informe o Stage da configuração.' };
  const variante = (b.variante !== undefined ? String(b.variante || '') : (atual ? atual.variante || '' : '')).trim();
  if (variante && variante !== 'plus') return { erro: 'Variante inválida — use vazio ou "plus" (Stage X Plus).' };

  const limpa = (lista) => [...new Set((Array.isArray(lista) ? lista : [])
    .map(x => String(x || '').trim()).filter(Boolean))];
  const comandos = b.comandos !== undefined ? limpa(b.comandos) : domain.opcoesDoProduto(atual).comandos;
  if (!comandos.length) return { erro: 'Cadastre ao menos um comando para esta configuração.' };
  const tuchos = b.tuchos !== undefined ? limpa(b.tuchos) : domain.opcoesDoProduto(atual).tuchos;
  if (!tuchos.length) return { erro: 'Cadastre ao menos uma medida de tucho para esta configuração.' };

  const dados = {
    tipo, stage, variante, comandos, tuchos,
    rotuloStage: (b.rotuloStage && String(b.rotuloStage).trim()) || domain.rotuloStage(stage, variante),
    nome: (b.nome && String(b.nome).trim()) || domain.nomeProduto(tipo, stage, variante)
  };
  if (b.preco !== undefined) dados.preco = Number(b.preco) || 0;
  if (b.custoBaseAuto !== undefined) dados.custoBaseAuto = !!b.custoBaseAuto;
  if (b.custoBase !== undefined) dados.custoBase = Number(b.custoBase) || 0;
  if (b.composicaoObs !== undefined) dados.composicaoObs = String(b.composicaoObs || '');
  if (b.ativo !== undefined) dados.ativo = b.ativo !== false;
  return { dados };
}

/** Custo-base recalculado pela composição, quando o produto está nesse modo. */
function recalcularCustoBase(id) {
  const p = db.get('products', id);
  if (!p || !p.custoBaseAuto) return p;
  const cfg = produtoComConfig(p);
  const custo = custoDaComposicao(p, { tipo: p.tipo, comando: cfg.comandos[0], tucho: cfg.tuchos[0] });
  db.update('products', id, { custoBase: custo.total });
  return db.get('products', id);
}

route('POST', '/api/products/configuracao', ['products', 'finance_sensitive'], async (req, res, user) => {
  const b = await readBody(req);
  const { dados, erro } = lerConfiguracao(b, null);
  if (erro) return bad(res, erro);
  const igual = db.all('products').find(p => p.tipo === dados.tipo
    && Number(p.stage) === dados.stage && (p.variante || '') === dados.variante);
  if (igual) {
    return bad(res, `Já existe a configuração ${igual.nome}. Edite essa em vez de criar outra.`);
  }
  const novo = db.insert('products', Object.assign({
    preco: 0, custoBase: 0, custoBaseAuto: false, ativo: true,
    composicao: composicaoSugerida(dados.tipo), composicaoConfirmada: false,
    composicaoObs: ''
  }, dados));
  recalcularCustoBase(novo.id);
  audit(user, 'criou', 'products', novo.id, `Configuração "${novo.nome}" criada`);
  ok(res, produtoComConfig(db.get('products', novo.id)));
});

route('PUT', '/api/products/:id/configuracao', ['products', 'finance_sensitive'], async (req, res, user, params) => {
  const prod = db.get('products', params.id);
  if (!prod) return notFound(res);
  const b = await readBody(req);
  const { dados, erro } = lerConfiguracao(b, prod);
  if (erro) return bad(res, erro);
  const igual = db.all('products').find(p => p.id !== prod.id && p.tipo === dados.tipo
    && Number(p.stage) === dados.stage && (p.variante || '') === dados.variante);
  if (igual) return bad(res, `Essa combinação já é a configuração ${igual.nome}.`);

  /* Comando que sai da lista continua gravado nos pedidos antigos — o que
     muda é só o que aparece para escolher de agora em diante. */
  const antes = domain.opcoesDoProduto(prod);
  const removidos = antes.comandos.filter(c => !dados.comandos.includes(c));
  const emUso = removidos.filter(c => db.all('sales').some(s =>
    (s.itens || []).some(i => i.productId === prod.id && i.comando === c)));

  db.update('products', prod.id, dados);
  recalcularCustoBase(prod.id);
  const mudancas = [];
  if (dados.nome !== prod.nome) mudancas.push(`nome: "${prod.nome}" → "${dados.nome}"`);
  const novos = dados.comandos.filter(c => !antes.comandos.includes(c));
  if (novos.length) mudancas.push('comandos adicionados: ' + novos.join(', '));
  if (removidos.length) mudancas.push('comandos retirados da escolha: ' + removidos.join(', '));
  if (String(antes.tuchos) !== String(dados.tuchos)) mudancas.push('tuchos: ' + dados.tuchos.join('/') + ' mm');
  if (mudancas.length) audit(user, 'editou', 'products', prod.id, `Configuração "${dados.nome}" — ` + mudancas.join('; '));
  ok(res, Object.assign(produtoComConfig(db.get('products', prod.id)), {
    avisoHistorico: emUso.length
      ? `Os comandos ${emUso.join(', ')} saíram da lista de escolha, mas continuam nos pedidos antigos — nada foi alterado no histórico.`
      : ''
  }));
});

/* ---- produtos: configuração, composição e custo ----
   Administrar aqui é administrar em todo lugar: venda, orçamento,
   produção, baixa de estoque e custo leem esta mesma composição. */

route('GET', '/api/products/configuracoes', 'sales', async (req, res, user) => {
  const lista = db.all('products').map(p => {
    const cfg = produtoComConfig(p);
    const custo = custoDaComposicao(p, { tipo: p.tipo, comando: cfg.comandos[0], tucho: cfg.tuchos[0] });
    return Object.assign(sanitize(user, 'products', cfg), {
      composicaoLinhas: p.composicao ? p.composicao.length : 0,
      composicaoConfirmada: p.composicaoConfirmada === true,
      semVinculo: custo.semVinculo,
      custoComposicao: can(user, 'finance_sensitive') ? custo.total : undefined
    });
  }).sort((a, b) => (a.tipo || '').localeCompare(b.tipo || '')
    || (Number(a.stage) - Number(b.stage))
    || String(a.variante || '').localeCompare(String(b.variante || '')));
  ok(res, { produtos: lista, papeis: domain.PAPEIS });
});

/** Composição de um produto, resolvida para uma configuração concreta. */
route('GET', '/api/products/:id/composicao', 'sales', async (req, res, user, params, query) => {
  const prod = db.get('products', params.id);
  if (!prod) return notFound(res);
  const cfg = produtoComConfig(prod);
  const comando = query.comando || cfg.comandos[0] || '';
  const tucho = query.tucho || cfg.tuchos[0] || '';
  const custo = custoDaComposicao(prod, { tipo: prod.tipo, comando, tucho });
  const sensivel = can(user, 'finance_sensitive');
  ok(res, {
    produto: sanitize(user, 'products', cfg),
    comando, tucho,
    confirmada: prod.composicaoConfirmada === true,
    linhas: custo.linhas.map(l => sensivel ? l
      : Object.assign({}, l, { custoUnit: undefined, custoTotal: undefined })),
    custoTotal: sensivel ? custo.total : undefined,
    semCusto: custo.semCusto, semVinculo: custo.semVinculo,
    /* Onde cada peça da composição é usada — a consulta inversa. */
    itensDeEstoque: db.all('stockItems').filter(i => i.ativo !== false)
      .map(i => ({ id: i.id, nome: i.nome, categoria: i.categoria, qtd: i.qtd,
        custoUnit: sensivel ? (Number(i.custoUnit) || 0) : undefined }))
  });
});

/** Grava a composição e marca que foi conferida por gente. */
route('PUT', '/api/products/:id/composicao', ['products', 'finance_sensitive'], async (req, res, user, params) => {
  const prod = db.get('products', params.id);
  if (!prod) return notFound(res);
  const b = await readBody(req);
  if (!Array.isArray(b.linhas)) return bad(res, 'Informe as linhas da composição.');
  const linhas = [];
  for (const l of b.linhas) {
    const papel = domain.PAPEIS.includes(l.papel) ? l.papel : 'fixo';
    const qtd = Math.round((Number(l.qtd) || 0) * 1000) / 1000;
    if (qtd <= 0) return bad(res, 'Toda peça da composição precisa de uma quantidade maior que zero.');
    if (papel === 'fixo') {
      const item = db.get('stockItems', l.stockItemId);
      if (!item) return bad(res, 'Escolha o item de estoque de cada peça da composição.');
      linhas.push({ papel, stockItemId: item.id, qtd, obs: String(l.obs || '').slice(0, 200) });
    } else {
      linhas.push({ papel, stockItemId: null, qtd, obs: String(l.obs || '').slice(0, 200) });
    }
  }
  const comandoDuplicado = linhas.filter(l => l.papel === 'comando').length > 1;
  const tuchoDuplicado = linhas.filter(l => l.papel === 'tucho').length > 1;
  if (comandoDuplicado || tuchoDuplicado) {
    return bad(res, `A composição tem ${comandoDuplicado ? 'duas linhas de comando' : 'duas linhas de tucho'} — ` +
      'o estoque baixaria a mesma peça duas vezes. Deixe uma só.');
  }
  const repetido = linhas.filter(l => l.papel === 'fixo')
    .map(l => l.stockItemId).find((id, i, arr) => arr.indexOf(id) !== i);
  if (repetido) {
    const it = db.get('stockItems', repetido);
    return bad(res, `"${it ? it.nome : 'Esta peça'}" aparece duas vezes na composição — ` +
      'some as quantidades numa linha só para o estoque não baixar em dobro.');
  }
  db.update('products', prod.id, {
    composicao: linhas,
    composicaoConfirmada: b.confirmada !== false,
    composicaoObs: b.composicaoObs !== undefined ? String(b.composicaoObs || '') : prod.composicaoObs
  });
  /* Custo-base calculado pela composição, quando o produto está nesse modo. */
  recalcularCustoBase(prod.id);
  audit(user, 'editou', 'products', prod.id,
    `Composição de "${prod.nome}" atualizada — ${linhas.length} peça(s)`);
  ok(res, Object.assign({ ok: true }, produtoComConfig(db.get('products', prod.id))));
});

/** Onde cada item de estoque é usado: a consulta inversa da composição. */
route('GET', '/api/stockItems/:id/usos', 'stock', async (req, res, user, params) => {
  const item = db.get('stockItems', params.id);
  if (!item) return notFound(res);
  const usos = [];
  for (const p of db.all('products')) {
    for (const l of p.composicao || []) {
      const casa = l.papel === 'fixo' ? l.stockItemId === item.id
        : l.papel === 'comando' ? item.categoria === 'comando'
          : l.papel === 'tucho' ? (item.categoria === 'tucho35' || item.categoria === 'tucho37') : false;
      if (!casa) continue;
      usos.push({ productId: p.id, produto: p.nome, tipo: p.tipo, stage: p.stage,
        rotuloStage: p.rotuloStage || domain.rotuloStage(p.stage, p.variante),
        qtd: l.qtd, papel: l.papel, ativo: p.ativo !== false,
        porConfiguracao: l.papel !== 'fixo' });
    }
  }
  ok(res, { item: sanitize(user, 'stockItems', item), usos });
});

/** Composição e baixas de uma venda, cabeçote por cabeçote. */
route('GET', '/api/sales/:id/composicao', ['sales', 'stock'], async (req, res, user, params) => {
  const sale = db.get('sales', params.id);
  if (!sale) return notFound(res);
  ok(res, composicaoDaVenda(sale, user));
});

/* ---- auditoria das baixas automáticas de estoque ---- */
route('GET', '/api/auditoria/baixas-estoque', ['stock', 'stock_history'], async (req, res, user) => {
  ok(res, auditarBaixasDeEstoque());
});

route('POST', '/api/auditoria/baixas-estoque/corrigir', 'stock_history_edit', async (req, res, user) => {
  const b = await readBody(req);
  const alvos = Array.isArray(b.correcoes) ? b.correcoes : [];
  if (!alvos.length) return bad(res, 'Marque o que deve ser corrigido.');
  if (req.headers['x-confirmar'] !== 'sim') {
    return send(res, 409, { error: 'Confirme a correção das baixas de estoque.', precisaConfirmar: true });
  }
  try { ok(res, corrigirBaixasDeEstoque(alvos, user)); }
  catch (e) { bad(res, 'Não foi possível gravar a cópia de segurança: ' + e.message); }
});

route('GET', '/api/sales/:id/financeiro', 'receivables', async (req, res, user, params) => {
  const sale = db.get('sales', params.id);
  if (!sale) return notFound(res);
  /* "parcelas" são as cobranças PRÓPRIAS (boleto parcelado, cartão, link):
     cada uma tem baixa em Contas a receber. A linha espelho da venda não é
     cobrança — é o reflexo do pedido — e vai à parte para a tela não somar
     o mesmo dinheiro duas vezes. */
  const doPedido = withOverdue(db.all('receivables')
    .filter(r => r.refType === 'sales' && r.refId === sale.id))
    .sort((a, b) => String(a.vencimento || '').localeCompare(String(b.vencimento || '')));
  const parcelas = doPedido.filter(r => !ehEspelhoDaVenda(r));
  const espelho = doPedido.find(r => ehEspelhoDaVenda(r)) || null;
  ok(res, Object.assign(resumoFinanceiroVenda(sale), {
    pagamento: sale.pagamento || {}, recebimentos: sale.recebimentos || [],
    parcelas, espelho, cobrancaPropria: parcelas.length > 0
  }));
});

route('GET', '/api/sales/:id/result', 'finance_sensitive', async (req, res, user, params) => {
  const sale = db.get('sales', params.id);
  if (!sale) return notFound(res);
  ok(res, domain.saleResult(sale));
});

/* ---- ordens de produção ---- */
/* Lista de trabalho da produção: cabeçotes vendidos e serviços de cliente
   no mesmo lugar, cada um com os dados de onde veio. */
route('GET', '/api/producao', 'production', async (req, res, user) => {
  const lista = db.all('productionOrders').map(andamentoDaOrdem).map(po => {
    if (po.origem === 'servico') {
      const os = db.get('serviceOrders', po.osId);
      return Object.assign({}, po, {
        osStatus: os ? os.status : po.osStatus,
        previsaoEntrega: os ? (os.previsaoEntrega || po.previsaoEntrega) : po.previsaoEntrega
      });
    }
    const sale = db.get('sales', po.saleId);
    return Object.assign({}, po, {
      vendaStatus: sale ? sale.status : null,
      previsaoEntrega: sale ? (sale.previsaoEntrega || po.previsaoEntrega) : po.previsaoEntrega
    });
  });
  lista.sort((a, b) => b.id - a.id);
  ok(res, { ordens: lista, etapas: domain.ETAPAS_PRODUCAO.map(([chave, nome]) => ({ chave, nome })) });
});

route('POST', '/api/productionOrders/:id/check', 'production', async (req, res, user, params) => {
  const b = await readBody(req);
  const po = db.get('productionOrders', params.id);
  if (!po) return notFound(res);
  if (po.checklist[b.index] === undefined) return bad(res, 'Item inválido');
  po.checklist[b.index].done = !!b.done;
  po.checklist[b.index].por = user.name;
  po.checklist[b.index].em = new Date().toISOString();
  db.save();
  ok(res, concluirSePronto(po, user));
});

/* Conclui (ou reabre) uma etapa inteira de uma vez — é assim que a equipe
   trabalha: termina a separação, marca a etapa, parte para a usinagem. */
route('POST', '/api/productionOrders/:id/etapa', 'production', async (req, res, user, params) => {
  const b = await readBody(req);
  const po = db.get('productionOrders', params.id);
  if (!po) return notFound(res);
  if (!domain.ETAPAS_ORDEM.includes(b.etapa)) return bad(res, 'Etapa inválida: ' + b.etapa);
  const done = !!b.done;
  let n = 0;
  for (const c of po.checklist || []) {
    if (c.etapa !== b.etapa || c.done === done) continue;
    c.done = done;
    c.por = user.name;
    c.em = new Date().toISOString();
    n++;
  }
  db.save();
  const nome = (domain.ETAPAS_PRODUCAO.find(e => e[0] === b.etapa) || [])[1] || b.etapa;
  audit(user, 'etapa', 'productionOrders', po.id,
    `OP #${po.id} — etapa "${nome}" ${done ? 'concluída' : 'reaberta'} (${n} item(ns))`);
  ok(res, concluirSePronto(po, user));
});

/* Trocar o responsável (ou cancelar/reabrir a ordem). O ANDAMENTO não é
   digitado: ele vem do checklist, para a etapa marcada e o status nunca
   contarem histórias diferentes. */
route('POST', '/api/productionOrders/:id/status', 'production', async (req, res, user, params) => {
  const b = await readBody(req);
  const po = db.get('productionOrders', params.id);
  if (!po) return notFound(res);
  const patch = {};
  if (b.responsavelId !== undefined) patch.responsavelId = b.responsavelId;
  // Cancelar/reabrir é decisão de gente; os demais status saem do checklist.
  if (b.status === 'cancelado' || (po.status === 'cancelado' && b.status && b.status !== 'cancelado')) {
    patch.status = b.status === 'cancelado' ? 'cancelado' : domain.statusPorEtapa(po.checklist);
    audit(user, 'status', 'productionOrders', po.id,
      `Ordem de produção #${po.id} → ${patch.status === 'cancelado' ? 'cancelada' : 'reaberta'}`);
  }
  if (Object.keys(patch).length) db.update('productionOrders', po.id, patch);
  ok(res, concluirSePronto(db.get('productionOrders', po.id), user));
});

/* ---- estoque: ajustes manuais ---- */
route('POST', '/api/stock/:id/move', 'stock', async (req, res, user, params) => {
  const b = await readBody(req);
  const item = moveStock(Number(params.id), b.tipo === 'entrada' ? 'entrada' : 'saida', Math.abs(Number(b.qtd) || 0), 'manual', null, b.obs, user);
  if (!item) return notFound(res);
  ok(res, item);
});

/* ================= Correção do histórico de estoque (Direção) =================
   Lançamento retroativo é o caso que motiva isto: uma venda antiga é
   cadastrada hoje só para o histórico financeiro fechar, mas a peça já saiu
   fisicamente há semanas. O sistema, que não tem como saber disso, dá a
   baixa de novo — e o saldo passa a acusar uma unidade a menos do que existe
   na prateleira.

   Aqui a Direção acerta a movimentação. O saldo do item NUNCA é digitado: ele
   é recalculado a partir da diferença entre o que a movimentação dizia e o
   que passa a dizer, para a correção não virar uma segunda baixa. Toda
   alteração exige motivo e fica na auditoria. */

/** Quanto esta movimentação soma (+) ou tira (−) do saldo do item. */
const efeitoDaMovimentacao = (m) =>
  (m.estornada ? 0 : (m.tipo === 'entrada' ? 1 : -1) * (Math.abs(Number(m.qtd)) || 0));

route('GET', '/api/stock/history', ['stock_history', 'stock'], async (req, res, user, params, query) => {
  let list = db.all('stockMoves').slice().reverse();
  if (query.itemId) list = list.filter(m => Number(m.itemId) === Number(query.itemId));
  const itens = db.all('stockItems');
  ok(res, list.slice(0, Number(query.limit) || 400).map(m => Object.assign({}, m, {
    itemNome: m.itemNome || (itens.find(i => i.id === m.itemId) || {}).nome || '—',
    efeito: efeitoDaMovimentacao(m)
  })));
});

route('PUT', '/api/stock/history/:id', 'stock_history_edit', async (req, res, user, params) => {
  const b = await readBody(req);
  const mov = db.get('stockMoves', params.id);
  if (!mov) return notFound(res);
  if (!b.motivo) return bad(res, 'Explique o motivo da correção — ele fica registrado na auditoria.');
  if (mov.estornada) return bad(res, 'Esta movimentação está estornada. Reative-a antes de corrigir os dados.');

  const tipo = b.tipo === 'entrada' ? 'entrada' : (b.tipo === 'saida' ? 'saida' : mov.tipo);
  const qtd = b.qtd === undefined || b.qtd === null || b.qtd === '' ? Math.abs(Number(mov.qtd) || 0) : Math.abs(Number(b.qtd) || 0);
  if (qtd <= 0) return bad(res, 'A quantidade precisa ser maior que zero.');

  const item = db.get('stockItems', mov.itemId);
  if (!item) return bad(res, 'O item desta movimentação não existe mais.');

  const antes = efeitoDaMovimentacao(mov);
  const depois = efeitoDaMovimentacao({ tipo, qtd });
  const patch = {
    tipo, qtd,
    data: b.data || mov.data,
    refType: b.refType === undefined ? mov.refType : (b.refType || null),
    refId: b.refId === undefined ? mov.refId : (b.refId ? Number(b.refId) : null),
    obs: b.obs === undefined ? mov.obs : b.obs,
    corrigidaPor: user.name, corrigidaEm: new Date().toISOString(), motivoCorrecao: b.motivo
  };
  const rec = db.update('stockMoves', mov.id, patch);

  /* Só a diferença mexe no saldo: trocar uma saída de 3 por uma de 1 devolve
     2 ao estoque, não lança uma entrada de 1.
     O saldo novo é calculado UMA vez e reaproveitado: db.get devolve o
     próprio registro, então reler item.qtd depois do update somaria de novo. */
  const ajuste = depois - antes;
  const saldoItem = Math.round(((Number(item.qtd) || 0) + ajuste) * 100) / 100;
  if (ajuste) db.update('stockItems', item.id, { qtd: saldoItem });

  audit(user, 'corrigiu', 'stockMoves', rec.id,
    `Movimentação #${rec.id} de ${item.nome}: ${mov.tipo} ${mov.qtd} → ${tipo} ${qtd}` +
    (patch.data !== mov.data ? `, data ${mov.data} → ${patch.data}` : '') +
    `; saldo do item ${ajuste >= 0 ? '+' : ''}${ajuste} (agora ${saldoItem}). Motivo: ${b.motivo}`);
  ok(res, { movimentacao: rec, ajusteNoSaldo: ajuste, saldoItem });
});

/**
 * Estorna (ou reativa) uma movimentação indevida. Ela continua no histórico,
 * marcada — apagar a linha esconderia que o acerto aconteceu, que é
 * justamente o que a Direção precisa conseguir provar depois.
 */
route('POST', '/api/stock/history/:id/estornar', 'stock_history_edit', async (req, res, user, params) => {
  const b = await readBody(req);
  const mov = db.get('stockMoves', params.id);
  if (!mov) return notFound(res);
  if (!b.motivo) return bad(res, 'Explique o motivo — ele fica registrado na auditoria.');
  const item = db.get('stockItems', mov.itemId);
  if (!item) return bad(res, 'O item desta movimentação não existe mais.');

  const reativar = !!mov.estornada;
  const antes = efeitoDaMovimentacao(mov);
  const depois = efeitoDaMovimentacao(Object.assign({}, mov, { estornada: !reativar }));
  const ajuste = depois - antes;

  db.update('stockMoves', mov.id, {
    estornada: !reativar,
    motivoEstorno: b.motivo,
    estornadaPor: user.name, estornadaEm: new Date().toISOString()
  });
  const saldoItem = Math.round(((Number(item.qtd) || 0) + ajuste) * 100) / 100;
  if (ajuste) db.update('stockItems', item.id, { qtd: saldoItem });

  audit(user, reativar ? 'reativou' : 'estornou', 'stockMoves', mov.id,
    `Movimentação #${mov.id} de ${item.nome} (${mov.tipo} ${mov.qtd}) ${reativar ? 'reativada' : 'estornada'}; ` +
    `saldo do item ${ajuste >= 0 ? '+' : ''}${ajuste} (agora ${saldoItem}). Motivo: ${b.motivo}`);
  ok(res, { estornada: !reativar, ajusteNoSaldo: ajuste, saldoItem });
});

/* ---- compras ---- */
/**
 * Gera as contas a pagar de uma compra, respeitando o agendamento escolhido
 * (sexta anterior, imediato, a cada 30 dias, início do mês, data combinada).
 * Usada na criação e na edição — a edição apaga as parcelas em aberto e
 * chama isto de novo, o que garante que nunca exista obrigação duplicada.
 */
function gerarContasPagarDaCompra(rec, { intervaloDias } = {}) {
  const tipo = rec.tipoPagamento || 'programado';
  const base = domain.programarPagamento(tipo, rec.data, rec.vencimento || '', {
    diaMes: rec.agendamentoDia, dataManual: rec.agendamentoData
  });
  const parcels = rec.parcelas > 1
    ? domain.generateInstallments(rec.data, rec.valor, rec.parcelas, intervaloDias || 30)
    : [{ parcela: 1, parcelas: 1, vencimento: base.vencimento, valor: rec.valor }];
  for (const p of parcels) {
    // Com várias parcelas, cada uma agenda pela própria data de vencimento;
    // com uma só, vale o cálculo base (que já partiu do vencimento certo).
    const prog = rec.parcelas > 1
      ? domain.programarPagamento(tipo, rec.data, p.vencimento,
          { diaMes: rec.agendamentoDia, dataManual: rec.agendamentoData })
      : base;
    db.insert('payables', {
      descricao: `Compra ${rec.fornecedorNome || ''} ${rec.documentoNumero ? 'NF ' + rec.documentoNumero : ''}`.trim()
        + (p.parcelas > 1 ? ` — parcela ${p.parcela}/${p.parcelas}` : ''),
      categoria: rec.categoria, fornecedorId: rec.fornecedorId,
      formaPagamento: normalizaForma(rec.formaPagamento) || '',
      valor: p.valor, vencimento: p.vencimento,
      tipoPagamento: tipo,
      dataProgramada: prog.dataProgramada,
      status: 'aberto', refType: 'purchases', refId: rec.id, documento: rec.documentoNumero
    });
  }
}

/* ---------------------------------------------------------------------
   Compra no CARTÃO DE CRÉDITO.

   A despesa é da data da COMPRA, não da fatura. Então a compra no cartão
   lança a saída no caixa na hora, com forma "cartão de crédito", e NÃO
   gera conta a pagar — quem se paga depois é a fatura, não cada compra.

   É isso que evita a duplicidade: as compras do mês já estão no caixa;
   pagar a fatura apenas quita o cartão, sem lançar a despesa outra vez
   (ver a trava de "fatura de cartão" em contas a pagar).

   A função é idempotente: mantém no máximo UMA saída por compra e a
   atualiza quando valor, data ou forma mudam. Chamada na criação e na
   edição, nunca duplica.                                                 */
function noCartao(compra) {
  return normalizaForma(compra && compra.formaPagamento) === 'cartao_credito';
}

function sincronizarCaixaDaCompra(compra, user) {
  const atuais = db.all('cashflow').filter(c =>
    c.refType === 'purchases' && c.refId === compra.id && c.tipo === 'saida');
  if (!noCartao(compra)) {
    for (const c of atuais) db.remove('cashflow', c.id);
    return { removidas: atuais.length };
  }
  const dados = {
    tipo: 'saida', valor: Math.round((Number(compra.valor) || 0) * 100) / 100,
    data: compra.data, conta: 'principal', formaPagamento: 'cartao_credito',
    categoria: compra.categoria || 'componentes',
    origem: `Compra ${compra.fornecedorNome || ''}`.trim() +
      (compra.documentoNumero ? ` — NF ${compra.documentoNumero}` : ''),
    documento: compra.documentoNumero || '',
    refType: 'purchases', refId: compra.id,
    descricao: 'Compra no cartão de crédito'
  };
  if (atuais.length) {
    db.update('cashflow', atuais[0].id, dados);
    for (const extra of atuais.slice(1)) db.remove('cashflow', extra.id);
    return { atualizada: atuais[0].id };
  }
  const nova = db.insert('cashflow', dados);
  if (user) {
    audit(user, 'lançou', 'cashflow', nova.id,
      `Compra no cartão de ${brl(dados.valor)} em ${dataBR(dados.data)} — despesa na data da compra; ` +
      'a fatura, ao ser paga, não lança de novo');
  }
  return { criada: nova.id };
}

route('POST', '/api/purchases', 'purchases', async (req, res, user) => {
  const b = await readBody(req);
  const forn = b.fornecedorId ? db.get('suppliers', b.fornecedorId) : null;
  const valor = Number(b.valor) || (b.itens || []).reduce((s, i) => s + (Number(i.total) || 0), 0);
  let rec;
  try {
    rec = db.insert('purchases', {
      fornecedorId: forn ? forn.id : null, fornecedorNome: forn ? forn.nome : (b.fornecedorNome || ''),
      data: b.data || domain.today(),
      itens: b.itens || [], valor,
      formaPagamento: b.formaPagamento || '',
      vencimento: b.vencimento || '',
      parcelas: Number(b.parcelas) || 1,
      documentoTipo: b.documentoTipo || 'sem_documento', // nf | recibo | comprovante | sem_documento | outro
      documentoNumero: b.documentoNumero || '',
      categoria: b.categoria || 'componentes',
      observacoes: b.observacoes || '',
      // programado | imediato | a_cada_30 | inicio_mes | outro
      tipoPagamento: b.tipoPagamento || 'programado',
      agendamentoDia: b.agendamentoDia ? Number(b.agendamentoDia) : null,
      agendamentoData: b.agendamentoData || '',
      vinculo: b.vinculo || { tipo: 'sem_vinculo', refId: null },
      status: 'registrada'
    });
    /* No cartão, a despesa entra direto no caixa e não vira conta a pagar:
       o que se paga depois é a fatura. */
    if (noCartao(rec)) {
      sincronizarCaixaDaCompra(rec, user);
    } else if (b.gerarContasPagar !== false && valor > 0) {
      gerarContasPagarDaCompra(rec, { intervaloDias: b.intervaloDias });
    }
  } catch (e) {
    if (rec) db.remove('purchases', rec.id);
    return bad(res, e.message);
  }

  // Itens vinculados a um produto do estoque próprio entram sozinhos.
  const estoque = sincronizarEstoqueDaCompra(rec, user);

  audit(user, 'criou', 'purchases', rec.id,
    `Compra ${rec.fornecedorNome} — R$ ${valor.toFixed(2)} (${rec.documentoTipo})` +
    (noCartao(rec) ? ' — no cartão de crédito: despesa lançada na data da compra, sem conta a pagar' : '') +
    (estoque.length ? `; estoque: ${estoque.join('; ')}` : ''));
  ok(res, Object.assign({}, rec, { estoque }));
});

/** Leitura automática de NF-e (XML) — sempre com conferência antes de confirmar. */
/* O que um fornecedor tem em aberto: as compras cujas contas a pagar ainda
   não foram quitadas + os gastos diários do fechamento mensal. Calculado
   sempre a partir dos lançamentos — nunca digitado à mão. */
function abertoDoFornecedor(fornecedorId) {
  const compras = db.all('purchases').filter(c => c.fornecedorId === Number(fornecedorId));
  const itens = [];
  for (const c of compras) {
    const parcelas = db.all('payables').filter(p => p.refType === 'purchases' && p.refId === c.id);
    // Sem conta a pagar gerada, a compra conta como aberta pelo próprio valor.
    const emAberto = parcelas.length
      ? parcelas.filter(p => p.status !== 'pago' && p.status !== 'cancelado')
      : [{ valor: c.valor, vencimento: c.vencimento || '', status: 'aberto' }];
    if (!emAberto.length) continue;
    const vinc = c.vinculo || {};
    itens.push({
      origem: 'compra', id: c.id, data: c.data,
      descricao: (c.itens || []).map(i => i.descricao).filter(Boolean).join(', ')
        || App_categoriaNome(c.categoria),
      vinculo: vinc.refNome || (vinc.tipo ? vinc.tipo : ''),
      documento: c.documentoNumero ? `${(c.documentoTipo || '').toUpperCase()} ${c.documentoNumero}` : '',
      valor: emAberto.reduce((s, p) => s + (Number(p.valor) || 0), 0),
      parcelas: parcelas.length,
      status: parcelas.length ? 'aguardando pagamento' : 'sem conta a pagar'
    });
  }
  for (const e of db.all('supplierExpenses').filter(e => e.fornecedorId === Number(fornecedorId) && e.status === 'aberto')) {
    itens.push({
      origem: 'gasto', id: e.id, data: e.data, descricao: e.descricao,
      vinculo: e.osRef || (e.clienteId ? (db.get('clients', e.clienteId) || {}).nome || '' : ''),
      documento: '', valor: Number(e.valor) || 0, parcelas: 0, status: 'aberto'
    });
  }
  itens.sort((a, b) => (a.data || '') < (b.data || '') ? -1 : 1);
  return { total: itens.reduce((s, i) => s + i.valor, 0), itens };
}

/* Nome legível da categoria de compra, para a descrição da conferência. */
function App_categoriaNome(k) {
  const m = {
    componentes: 'Componentes', materiais: 'Materiais', mao_obra_direta: 'Mão de obra direta',
    terceirizacao: 'Terceirização', custo_producao: 'Outros custos de produção',
    pos_operacao: 'Pós-operação', manutencao: 'Manutenção',
    despesa_operacional: 'Despesas operacionais', outros: 'Outros', custo_direto: 'Custos diretos'
  };
  return m[k] || k || 'Compra';
}

/* Panorama de um fornecedor: total em aberto + o detalhamento que permite
   conferir a cobrança do mês contra o que a empresa registrou. */
route('GET', '/api/suppliers/:id/open', 'purchases', async (req, res, user, params) => {
  const forn = db.get('suppliers', params.id);
  if (!forn) return notFound(res);
  const r = abertoDoFornecedor(forn.id);
  ok(res, { fornecedor: { id: forn.id, nome: forn.nome }, total: r.total, itens: r.itens });
});

/* Totais de todos os fornecedores de uma vez (para a lista). */
route('GET', '/api/suppliers/open-summary', 'purchases', async (req, res) => {
  const out = {};
  for (const f of db.all('suppliers')) out[f.id] = abertoDoFornecedor(f.id).total;
  ok(res, out);
});

/* ---- edição de compra ----
   Regras inegociáveis do pedido:
   - editar ATUALIZA o lançamento, nunca cria outro;
   - as contas a pagar ligadas são atualizadas, nunca duplicadas;
   - o histórico guarda quem alterou, quando e cada valor antes → depois. */
route('PUT', '/api/purchases/:id', 'purchases', async (req, res, user, params) => {
  const antes = db.get('purchases', params.id);
  if (!antes) return notFound(res);
  const b = await readBody(req);

  const ligadas = db.all('payables').filter(p => p.refType === 'purchases' && p.refId === antes.id);
  const pagas = ligadas.filter(p => p.status === 'pago');

  const forn = b.fornecedorId ? db.get('suppliers', b.fornecedorId) : null;
  const valor = b.valor !== undefined
    ? (Number(b.valor) || (b.itens || []).reduce((s, i) => s + (Number(i.total) || 0), 0))
    : antes.valor;

  const patch = {
    fornecedorId: forn ? forn.id : (b.fornecedorId === null ? null : antes.fornecedorId),
    fornecedorNome: forn ? forn.nome : (b.fornecedorNome !== undefined ? b.fornecedorNome : antes.fornecedorNome),
    data: b.data || antes.data,
    itens: b.itens !== undefined ? b.itens : antes.itens,
    valor,
    formaPagamento: b.formaPagamento !== undefined ? b.formaPagamento : antes.formaPagamento,
    vencimento: b.vencimento !== undefined ? b.vencimento : antes.vencimento,
    parcelas: b.parcelas !== undefined ? (Number(b.parcelas) || 1) : antes.parcelas,
    documentoTipo: b.documentoTipo || antes.documentoTipo,
    documentoNumero: b.documentoNumero !== undefined ? b.documentoNumero : antes.documentoNumero,
    categoria: b.categoria || antes.categoria,
    observacoes: b.observacoes !== undefined ? b.observacoes : antes.observacoes,
    tipoPagamento: b.tipoPagamento || antes.tipoPagamento || 'programado',
    agendamentoDia: b.agendamentoDia !== undefined ? (b.agendamentoDia ? Number(b.agendamentoDia) : null) : antes.agendamentoDia,
    agendamentoData: b.agendamentoData !== undefined ? b.agendamentoData : antes.agendamentoData,
    vinculo: b.vinculo !== undefined ? b.vinculo : antes.vinculo
  };

  // O que muda o dinheiro (valor, parcelas, vencimento, agendamento) só pode
  // mudar enquanto nenhuma parcela foi paga — senão o caixa já registrado
  // divergiria do lançamento. O caminho é desfazer o pagamento antes.
  const mudouFinanceiro =
    patch.valor !== antes.valor ||
    patch.parcelas !== antes.parcelas ||
    patch.vencimento !== antes.vencimento ||
    patch.tipoPagamento !== (antes.tipoPagamento || 'programado') ||
    patch.agendamentoDia !== (antes.agendamentoDia || null) ||
    (patch.agendamentoData || '') !== (antes.agendamentoData || '') ||
    patch.data !== antes.data;
  if (mudouFinanceiro && pagas.length) {
    return bad(res, `Esta compra já tem ${pagas.length} parcela(s) paga(s). Valor, parcelas, vencimento e agendamento não podem mudar depois do pagamento — desfaça o pagamento na tela de Contas a pagar e edite em seguida. Os demais campos (categoria, vínculo, descrição…) podem ser editados normalmente.`);
  }

  // Histórico antes → depois, campo a campo, só do que mudou.
  const NOMES = {
    fornecedorNome: 'Fornecedor', data: 'Data', valor: 'Valor', formaPagamento: 'Forma de pagamento',
    vencimento: 'Vencimento', parcelas: 'Parcelas', documentoTipo: 'Tipo de documento',
    documentoNumero: 'Nº do documento', categoria: 'Categoria', observacoes: 'Observações',
    tipoPagamento: 'Agendamento', agendamentoDia: 'Dia do pagamento', agendamentoData: 'Data combinada'
  };
  const mudancas = [];
  for (const k of Object.keys(NOMES)) {
    const a = antes[k], d = patch[k];
    if (JSON.stringify(a ?? '') !== JSON.stringify(d ?? '')) {
      mudancas.push(`${NOMES[k]}: ${a === undefined || a === null || a === '' ? '—' : a} → ${d === '' || d == null ? '—' : d}`);
    }
  }
  const vincAntes = JSON.stringify(antes.vinculo || {}), vincDepois = JSON.stringify(patch.vinculo || {});
  if (vincAntes !== vincDepois) {
    const nome = v => v && v.tipo ? `${v.tipo}${v.refNome ? ' (' + v.refNome + ')' : ''}` : '—';
    mudancas.push(`Vínculo: ${nome(antes.vinculo)} → ${nome(patch.vinculo)}`);
  }
  if (JSON.stringify(antes.itens || []) !== JSON.stringify(patch.itens || [])) {
    mudancas.push(`Itens: ${(antes.itens || []).length} → ${(patch.itens || []).length} linha(s)`);
  }

  let rec;
  try {
    // Valida o agendamento ANTES de gravar qualquer coisa.
    domain.programarPagamento(patch.tipoPagamento, patch.data, patch.vencimento || '',
      { diaMes: patch.agendamentoDia, dataManual: patch.agendamentoData });

    rec = db.update('purchases', antes.id, patch);

    if (mudouFinanceiro) {
      // Regenera as parcelas em aberto a partir do zero: apagar + recriar é o
      // que garante que nunca fique obrigação duplicada nem órfã.
      for (const p of ligadas.filter(p => p.status !== 'pago')) db.remove('payables', p.id);
      gerarContasPagarDaCompra(rec, { intervaloDias: b.intervaloDias });
    } else {
      // Só metadados: propaga aos lançamentos ligados (inclusive pagos —
      // categoria e documento são classificação, não dinheiro).
      for (const p of ligadas) {
        const sufixo = (String(p.descricao || '').match(/ — parcela \d+\/\d+$/) || [''])[0];
        db.update('payables', p.id, {
          categoria: rec.categoria, fornecedorId: rec.fornecedorId, documento: rec.documentoNumero,
          descricao: `Compra ${rec.fornecedorNome || ''} ${rec.documentoNumero ? 'NF ' + rec.documentoNumero : ''}`.trim() + sufixo
        });
      }
    }
  } catch (e) {
    return bad(res, e.message);
  }

  /* Estoque e caixa acompanham a edição pela diferença — nunca recriando,
     para a compra editada não virar entrada dupla. */
  const estoque = sincronizarEstoqueDaCompra(rec, user);
  sincronizarCaixaDaCompra(rec, user);

  audit(user, 'alterou', 'purchases', rec.id,
    `Compra editada${mudancas.length ? ' — ' + mudancas.join('; ') : ''}` +
    (estoque.length ? `; estoque ajustado: ${estoque.join('; ')}` : ''));
  ok(res, Object.assign({}, rec, { estoque }));
});

/**
 * De onde veio (ou para onde foi) um lançamento do caixa.
 *
 * O caixa mostra "entrada de R$ 2.362,00 — OS nº 7" e a pessoa precisa saber
 * o resto sem sair da tela e caçar a OS: quanto era o serviço inteiro, quanto
 * já tinha sido recebido antes, quanto ainda falta, se é parcela e de quantas.
 * Tudo isso é derivado aqui, a partir do documento de origem — nada é
 * guardado em duplicidade no lançamento.
 */
function detalheDoLancamento(c) {
  const out = { lancamento: c, origem: null };
  if (!c.refType || !c.refId) return out;

  /* Quanto deste documento já havia entrado ANTES deste lançamento. Ordena
     por data e id para "antes" significar a mesma coisa em qualquer leitura. */
  const irmaos = db.all('cashflow')
    .filter(x => x.refType === c.refType && x.refId === c.refId && x.tipo === c.tipo)
    .sort((a, b) => String(a.data).localeCompare(String(b.data)) || a.id - b.id);
  const anteriores = irmaos.filter(x => (String(x.data) + String(x.id).padStart(9, '0')) <
    (String(c.data) + String(c.id).padStart(9, '0')));
  const recebidoAntes = Math.round(anteriores.reduce((s, x) => s + (Number(x.valor) || 0), 0) * 100) / 100;

  const clienteNome = (id) => (db.get('clients', id) || {}).nome || '';
  const parcelaDoDoc = () => {
    /* A parcela cujo valor e data batem com este lançamento — é assim que se
       descobre "3 de 5" sem gravar o número dentro do caixa. */
    const lista = db.all('receivables').filter(r => r.refType === c.refType && r.refId === c.refId);
    const exata = lista.find(r => Math.abs(Number(r.valor) - Number(c.valor)) < 0.005 &&
      (r.dataRecebimento === c.data || r.status === 'paga'));
    return exata || null;
  };

  if (c.refType === 'sales') {
    const v = db.get('sales', c.refId);
    if (!v) return out;
    const total = Number(v.valorTotal) || 0;
    const par = parcelaDoDoc();
    out.origem = {
      tipo: 'Venda', titulo: v.numero ? `Pedido nº ${v.numero}` : `Pedido #${v.id}`,
      clienteId: v.clienteId, cliente: clienteNome(v.clienteId),
      itens: (v.itens || []).map(i => `${i.qtd}× ${i.produto}` +
        (i.kind === 'peca' ? '' : ` (comando ${i.comando}, tucho ${i.tucho} mm)`)),
      valorTotal: total, recebidoAntes,
      valorLancamento: Number(c.valor) || 0,
      saldo: Math.round((total - recebidoAntes - (Number(c.valor) || 0)) * 100) / 100,
      forma: (v.pagamento || {}).forma || c.descricao || '',
      parcela: par ? par.parcela : null, parcelas: par ? par.parcelas : (v.pagamento || {}).parcelas || null,
      vencimento: par ? par.vencimento : (v.previsaoEntrega || ''),
      data: c.data, status: v.status, observacoes: v.observacoes || '',
      atalho: '#/sales'
    };
  } else if (c.refType === 'serviceOrders') {
    const o = db.get('serviceOrders', c.refId);
    if (!o) return out;
    const total = Number(o.valorTotal) || 0;
    const par = parcelaDoDoc();
    out.origem = {
      tipo: 'Ordem de serviço', titulo: o.numero ? `OS nº ${o.numero}` : `OS #${o.id}`,
      clienteId: o.clienteId, cliente: clienteNome(o.clienteId),
      itens: (o.itens || []).map(i => `${i.qtd || 1}× ${i.nome}`),
      identificacao: o.identificacao || '', modelo: o.modelo || '',
      valorTotal: total, recebidoAntes,
      valorLancamento: Number(c.valor) || 0,
      saldo: Math.round((total - recebidoAntes - (Number(c.valor) || 0)) * 100) / 100,
      forma: (o.pagamento || {}).forma || c.descricao || '',
      parcela: par ? par.parcela : null, parcelas: par ? par.parcelas : null,
      vencimento: par ? par.vencimento : (o.previsaoEntrega || ''),
      data: c.data, status: o.status, observacoes: o.observacoes || '',
      atalho: '#/os'
    };
  } else if (c.refType === 'payables') {
    const p = db.get('payables', c.refId);
    if (!p) return out;
    const forn = p.fornecedorId ? db.get('suppliers', p.fornecedorId) : null;
    out.origem = {
      tipo: 'Conta a pagar', titulo: p.descricao || `Conta #${p.id}`,
      fornecedor: forn ? forn.nome : '',
      valorTotal: Number(p.valor) || 0, recebidoAntes,
      valorLancamento: Number(c.valor) || 0,
      saldo: Math.round(((Number(p.valor) || 0) - recebidoAntes - (Number(c.valor) || 0)) * 100) / 100,
      categoria: p.categoria || '', documento: p.documento || '',
      vencimento: p.vencimento || '', agendado: p.dataProgramada || '',
      forma: p.forma || '', data: c.data, status: p.status,
      observacoes: p.observacoes || '', atalho: '#/payables'
    };
  } else if (c.refType === 'receivables') {
    const r = db.get('receivables', c.refId);
    if (!r) return out;
    out.origem = {
      tipo: 'Conta a receber', titulo: r.descricao || `Parcela #${r.id}`,
      clienteId: r.clienteId, cliente: clienteNome(r.clienteId),
      valorTotal: Number(r.valor) || 0, recebidoAntes,
      valorLancamento: Number(c.valor) || 0,
      saldo: Math.round(((Number(r.valor) || 0) - recebidoAntes - (Number(c.valor) || 0)) * 100) / 100,
      parcela: r.parcela || null, parcelas: r.parcelas || null,
      vencimento: r.vencimento || '', forma: r.forma || '',
      data: c.data, status: r.status, atalho: '#/receivables'
    };
  } else if (c.refType === 'purchases') {
    const p = db.get('purchases', c.refId);
    if (!p) return out;
    out.origem = {
      tipo: 'Compra', titulo: p.documentoNumero || `Compra #${p.id}`,
      fornecedor: p.fornecedorNome || '',
      itens: (p.itens || []).map(i => `${i.qtd || 1}× ${i.descricao || ''}`),
      valorTotal: Number(p.valor) || 0, recebidoAntes,
      valorLancamento: Number(c.valor) || 0,
      saldo: Math.round(((Number(p.valor) || 0) - recebidoAntes - (Number(c.valor) || 0)) * 100) / 100,
      categoria: p.categoria || '', data: c.data, atalho: '#/purchases'
    };
  } else if (c.refType === 'freights') {
    const f = db.get('freights', c.refId);
    if (!f) return out;
    out.origem = {
      tipo: 'Frete', titulo: f.transportadora || `Frete #${f.id}`,
      clienteId: f.clienteId, cliente: clienteNome(f.clienteId),
      valorTotal: Number(f.valor) || 0, recebidoAntes,
      valorLancamento: Number(c.valor) || 0, saldo: 0,
      data: c.data, status: f.status || '', atalho: '#/freights'
    };
  } else if (c.refType === 'hrPayments') {
    const h = db.get('hrPayments', c.refId);
    if (!h) return out;
    const col = h.employeeId ? db.get('employees', h.employeeId) : null;
    out.origem = {
      tipo: 'Pagamento de RH', titulo: h.descricao || `Pagamento #${h.id}`,
      colaborador: col ? col.nome : '',
      valorTotal: Number(h.valor) || 0, recebidoAntes,
      valorLancamento: Number(c.valor) || 0, saldo: 0,
      data: c.data, status: h.status || '', atalho: '#/hr'
    };
  }
  return out;
}

route('GET', '/api/cashflow/:id/detalhe', 'cashflow', async (req, res, user, params) => {
  const c = db.get('cashflow', params.id);
  if (!c) return notFound(res);
  ok(res, detalheDoLancamento(c));
});

/**
 * Excluir lançamento do fluxo de caixa — função da Direção.
 *
 * Lançamento que nasceu de outro módulo (pagamento de conta, recebimento de
 * venda, taxa de cartão) NÃO se apaga por aqui: ele é o reflexo do outro
 * registro, e apagá-lo sozinho deixaria a conta constando paga com o
 * dinheiro fora do caixa. O caminho é desfazer na origem, que estorna os
 * dois lados juntos — por isso a resposta diz onde ir. Lançamento manual,
 * esse sim, some direto.
 */
route('DELETE', '/api/cashflow/:id', 'cashflow_edit', async (req, res, user, params) => {
  const c = db.get('cashflow', params.id);
  if (!c) return notFound(res);
  const ORIGEM = {
    payables: ['Contas a pagar', 'use “Desfazer pagamento” na conta'],
    receivables: ['Contas a receber', 'use “Estornar” na parcela'],
    sales: ['Vendas', 'use “Estornar” no recebimento do pedido'],
    serviceOrders: ['Ordens de serviço', 'use “Estornar” no recebimento da OS'],
    hrPayments: ['RH', 'desfaça o pagamento do colaborador'],
    freights: ['Fretes', 'use “Desfazer pagamento” no frete'],
    purchases: ['Compras', 'desfaça o pagamento da parcela em Contas a pagar']
  };
  if (c.refType && ORIGEM[c.refType]) {
    const [modulo, comoFazer] = ORIGEM[c.refType];
    return bad(res, `Este lançamento é o reflexo de um registro em ${modulo} — apagá-lo aqui ` +
      `deixaria os dois lados divergentes. Para desfazer, ${comoFazer}: o caixa é estornado junto.`);
  }
  db.remove('cashflow', c.id);
  audit(user, 'excluiu', 'cashflow', Number(params.id),
    `${c.tipo === 'entrada' ? 'Entrada' : 'Saída'} de ${brl(c.valor)} em ${dataBR(c.data)} — ` +
    `${c.origem || c.descricao || 'lançamento manual'}`);
  ok(res, { ok: true });
});

/**
 * Excluir compra: leva junto as contas a pagar que ela gerou e a entrada de
 * estoque que ela deu. Sem isso sobraria obrigação a pagar de uma compra que
 * não existe mais, e o estoque continuaria contando peça que não entrou.
 */
route('DELETE', '/api/purchases/:id', 'purchases', async (req, res, user, params) => {
  const compra = db.get('purchases', params.id);
  if (!compra) return notFound(res);
  const confirmado = String(req.headers['x-confirmar'] || '').toLowerCase() === 'sim';

  const contas = db.all('payables').filter(p => p.refType === 'purchases' && p.refId === compra.id);
  const pagas = contas.filter(p => p.status === 'pago');
  const movs = db.all('stockMoves').filter(m => m.refType === 'purchases' && m.refId === compra.id && !m.estornada);
  const caixa = db.all('cashflow').filter(c =>
    (c.refType === 'payables' && contas.some(p => p.id === c.refId)) ||
    (c.refType === 'purchases' && c.refId === compra.id));

  if ((contas.length || movs.length) && !confirmado) {
    const partes = [];
    if (contas.length) {
      partes.push(`${contas.length} conta(s) a pagar foram geradas por esta compra` +
        (pagas.length ? `, sendo ${pagas.length} já paga(s) — as saídas no caixa serão estornadas` : ''));
    }
    if (movs.length) partes.push(`${movs.length} entrada(s) de estoque serão desfeitas`);
    return send(res, 409, {
      error: partes.join('. ') + '. Tudo isso é excluído junto. Confirma?',
      precisaConfirmar: true, contas: contas.length, pagas: pagas.length, movimentacoes: movs.length
    });
  }

  for (const c of caixa) db.remove('cashflow', c.id);
  for (const p of contas) db.remove('payables', p.id);
  /* O estoque volta pela diferença, com a movimentação de estorno registrada
     — o histórico precisa mostrar que a entrada foi desfeita, não sumir. */
  for (const m of movs) {
    const item = db.get('stockItems', m.itemId);
    if (item) db.update('stockItems', item.id, { qtd: (Number(item.qtd) || 0) - (Math.abs(Number(m.qtd)) || 0) });
    db.update('stockMoves', m.id, {
      estornada: true, motivoEstorno: 'Compra excluída',
      estornadaPor: user.name, estornadaEm: new Date().toISOString()
    });
  }
  db.remove('purchases', compra.id);
  audit(user, 'excluiu', 'purchases', Number(params.id),
    `Compra ${compra.documentoNumero || '#' + compra.id} de ${brl(compra.valor)} excluída` +
    (contas.length ? `; ${contas.length} conta(s) a pagar removida(s)` : '') +
    (caixa.length ? `; ${caixa.length} saída(s) de caixa estornada(s)` : '') +
    (movs.length ? `; ${movs.length} entrada(s) de estoque desfeita(s)` : ''));
  ok(res, { ok: true, contas: contas.length, movimentacoes: movs.length, caixa: caixa.length });
});

/* ================= Programas CNC — ROMI D600 =================
   O banco de dados dos programas da máquina, no lugar da planilha: qual é o
   programa, para que serve, qual o nome que o programador deu, em que pé
   está, o que deu no teste de bancada e quem mexeu nele.

   A regra que molda tudo aqui é física: o visor da ROMI D600 mostra só os
   CINCO primeiros caracteres do nome. Então a identificação precisa caber
   nesses cinco — daí a nomenclatura UN/FC + ADM/ESC, que dá "UNADM", "FCESC"
   já legíveis na máquina, antes de qualquer número de sequência.

   Nome original NUNCA é alterado nem apagado: é por ele que o programador se
   entende com os arquivos que já existem. O nome padronizado vive ao lado. */

const CNC_DIR = path.join(db.DATA_DIR, 'cnc');
const CNC_EXTS = ['nc', 'txt', 'min', 'mpf', 'tap', 'cnc', 'iso', 'eia', 'gcode', 'ngc', 'h', 'prg'];

const CNC_STATUS = ['em_teste', 'aprovado', 'reprovado', 'nao_utiliza'];
const CNC_STATUS_LABEL = {
  em_teste: 'Em teste', aprovado: 'Aprovado',
  reprovado: 'Reprovado', nao_utiliza: 'Não utiliza mais'
};

/* ---------------- Catálogo de classificação ----------------

   As classificações vivem no banco, não no código: a oficina cadastra um
   cabeçote ou uma área de usinagem novos sozinha, sem depender de alteração
   no sistema. Uma coleção só guarda os quatro tipos, ligados por paiId:

       aplicacao (UN, FC, EA, Fiat, Toyota…)
         └── casco (Germany, México, China…)
               └── modelo (T, BA, AB, AD…)
       area (ADM, ESC, Dutos, Sedes, Molas…)   — solta, vale para qualquer um

   Os programas continuam gravando SIGLAS, não ids: um programa cadastrado
   antes desta mudança tem aplicacao:'UN' e segue funcionando, e uma sigla que
   não esteja no catálogo aparece como ela mesma em vez de sumir da tela. */

const CNC_TIPOS = ['aplicacao', 'casco', 'modelo', 'area'];
const CNC_TIPO_LABEL = {
  aplicacao: 'Aplicação / tipo de cabeçote', casco: 'Origem / tipo do casco',
  modelo: 'Modelo / código', area: 'Área de operação'
};

/* O que a empresa já usava. Entra uma vez, na primeira subida com esta
   versão, e nunca sobrescreve o que a pessoa tiver editado depois. */
const CNC_CATALOGO_INICIAL = [
  { tipo: 'aplicacao', sigla: 'UN', nome: 'Unilateral' },
  { tipo: 'aplicacao', sigla: 'FC', nome: 'Fluxo cruzado' },
  { tipo: 'aplicacao', sigla: 'EA', nome: 'EA888' },
  { tipo: 'area', sigla: 'ADM', nome: 'Admissão' },
  { tipo: 'area', sigla: 'ESC', nome: 'Escape' },
  { tipo: 'area', sigla: 'DUT', nome: 'Dutos' },
  { tipo: 'area', sigla: 'ALT', nome: 'Alojamento de tuchos' },
  { tipo: 'area', sigla: 'MOL', nome: 'Molas' },
  { tipo: 'area', sigla: 'CAM', nome: 'Câmara de combustão' },
  { tipo: 'area', sigla: 'SED', nome: 'Sedes' }
];

/**
 * Semeia o catálogo sem tocar no que já existe.
 *
 * Roda a cada subida, mas só acrescenta o que falta — e nunca ressuscita uma
 * entrada que a oficina apagou de propósito, porque só semeia enquanto o
 * catálogo estiver completamente vazio. Depois disso, quem manda é o cadastro.
 */
function semearCatalogoCnc() {
  if (db.all('cncCatalogo').length) return;
  /* Só faz sentido semear se o módulo já estiver em uso ou começando agora:
     em qualquer caso, as classificações antigas precisam existir para os
     programas já cadastrados continuarem legíveis. */
  for (const e of CNC_CATALOGO_INICIAL) {
    db.insert('cncCatalogo', Object.assign({ paiId: null, ativo: true }, e));
  }
  /* Siglas que a versão anterior trazia embutidas no código e que podem
     estar gravadas em programas antigos — adotadas com o nome que tinham,
     em vez de aparecerem como a sigla crua. */
  const NOMES_ANTIGOS = { OU: 'Outra aplicação' };

  /* Sigla usada em programa antigo que não esteja na lista acima vira
     entrada do catálogo, para nada ficar órfão na tela. */
  for (const p of db.all('cncPrograms')) {
    for (const [campo, tipo] of [['aplicacao', 'aplicacao'], ['operacao', 'area']]) {
      const sigla = String(p[campo] || '').toUpperCase();
      if (!sigla) continue;
      if (db.all('cncCatalogo').some(c => c.tipo === tipo && c.sigla === sigla)) continue;
      db.insert('cncCatalogo', { tipo, sigla, nome: NOMES_ANTIGOS[sigla] || sigla, paiId: null, ativo: true });
    }
  }
}

/* Chamado aqui, e não junto das outras rotinas de subida: a lista inicial é
   um const declarado acima, que só existe a partir deste ponto do arquivo. */
semearCatalogoCnc();

const cncCat = (tipo) => db.all('cncCatalogo').filter(c => c.tipo === tipo);
const cncCatPorSigla = (tipo, sigla) => sigla
  ? cncCat(tipo).find(c => c.sigla === String(sigla).toUpperCase()) || null : null;
/** Nome por extenso de uma sigla; se não estiver no catálogo, a própria sigla. */
const cncNomeDe = (tipo, sigla) => {
  if (!sigla) return '';
  const c = cncCatPorSigla(tipo, sigla);
  return c ? c.nome : String(sigla);
};

/** Os 5 caracteres que aparecem no visor da máquina. */
const cncVisor = (nome) => String(nome || '').slice(0, 5).toUpperCase();

/**
 * Próximo nome sugerido.
 *
 * A identificação precisa caber nos 5 caracteres do visor, então eles são
 * sempre aplicação + área — o que a pessoa na máquina precisa saber primeiro.
 * O modelo/código, quando existe, entra depois da sequência: UNADM01T continua
 * mostrando UNADM no visor e carrega o "T" para quem lê o nome inteiro.
 */
function proximoNomeCnc(aplicacao, area, modelo) {
  const prefixo = (String(aplicacao || '').toUpperCase() + String(area || '').toUpperCase()).slice(0, 5);
  if (!prefixo) return '';
  const sufixo = String(modelo || '').toUpperCase();
  const usados = db.all('cncPrograms')
    .map(p => String(p.nome || '').toUpperCase())
    .filter(n => n.startsWith(prefixo))
    .map(n => parseInt(n.slice(prefixo.length).replace(/\D.*$/, ''), 10))
    .filter(n => !isNaN(n));
  const proximo = (usados.length ? Math.max(...usados) : 0) + 1;
  return prefixo + String(proximo).padStart(2, '0') + sufixo;
}

function cncComExtras(p) {
  return Object.assign({}, p, {
    visor: cncVisor(p.nome || p.nomeOriginal),
    statusLabel: CNC_STATUS_LABEL[p.status] || p.status,
    aplicacaoLabel: cncNomeDe('aplicacao', p.aplicacao),
    operacaoLabel: cncNomeDe('area', p.operacao),
    cascoLabel: cncNomeDe('casco', p.casco),
    modeloLabel: cncNomeDe('modelo', p.modelo)
  });
}

/* Catálogo inteiro, com os filhos já aninhados para a tela montar as listas
   em cascata sem precisar cruzar nada. */
function catalogoCnc() {
  const porTipo = (t) => cncCat(t).slice()
    .sort((a, b) => String(a.sigla).localeCompare(String(b.sigla), 'pt-BR'));
  const usoDe = (c) => db.all('cncPrograms').filter(p =>
    (c.tipo === 'aplicacao' && p.aplicacao === c.sigla) ||
    (c.tipo === 'area' && p.operacao === c.sigla) ||
    (c.tipo === 'casco' && p.casco === c.sigla) ||
    (c.tipo === 'modelo' && p.modelo === c.sigla)).length;
  const enriquecer = (c) => Object.assign({}, c, { emUso: usoDe(c) });
  return {
    aplicacoes: porTipo('aplicacao').map(enriquecer),
    cascos: porTipo('casco').map(enriquecer),
    modelos: porTipo('modelo').map(enriquecer),
    areas: porTipo('area').map(enriquecer)
  };
}

route('GET', '/api/cnc/catalogo', 'cnc', async (req, res) => ok(res, catalogoCnc()));

route('POST', '/api/cnc/catalogo', 'cnc', async (req, res, user) => {
  const b = await readBody(req);
  const tipo = CNC_TIPOS.includes(b.tipo) ? b.tipo : null;
  if (!tipo) return bad(res, 'Tipo de cadastro inválido.');
  const sigla = String(b.sigla || '').trim().toUpperCase();
  const nome = String(b.nome || '').trim();
  if (!sigla) return bad(res, 'Informe a sigla — é ela que entra no nome do programa.');
  if (!nome) return bad(res, 'Informe o nome por extenso.');
  if (!/^[A-Z0-9]{1,6}$/.test(sigla)) {
    return bad(res, 'A sigla aceita de 1 a 6 letras ou números, sem espaços nem acentos.');
  }
  if (cncCatPorSigla(tipo, sigla)) {
    return bad(res, `Já existe ${CNC_TIPO_LABEL[tipo].toLowerCase()} com a sigla ${sigla}.`);
  }
  /* Casco pertence a uma aplicação; modelo pertence a um casco. É o que
     permite "FC → México → BA" sem misturar com os códigos da Germany. */
  let paiId = null;
  if (tipo === 'casco' || tipo === 'modelo') {
    const tipoPai = tipo === 'casco' ? 'aplicacao' : 'casco';
    const pai = b.paiId ? db.get('cncCatalogo', b.paiId) : null;
    if (!pai || pai.tipo !== tipoPai) {
      return bad(res, `Escolha ${tipo === 'casco' ? 'a aplicação' : 'o casco'} a que este cadastro pertence.`);
    }
    paiId = pai.id;
  }
  const rec = db.insert('cncCatalogo', { tipo, sigla, nome, paiId, ativo: true });
  audit(user, 'criou', 'cncCatalogo', rec.id, `${CNC_TIPO_LABEL[tipo]}: ${sigla} — ${nome}`);
  ok(res, rec);
});

route('PUT', '/api/cnc/catalogo/:id', 'cnc', async (req, res, user, params) => {
  const c = db.get('cncCatalogo', params.id);
  if (!c) return notFound(res);
  const b = await readBody(req);
  const sigla = b.sigla === undefined ? c.sigla : String(b.sigla).trim().toUpperCase();
  const nome = b.nome === undefined ? c.nome : String(b.nome).trim();
  if (!sigla || !nome) return bad(res, 'Sigla e nome são obrigatórios.');
  if (!/^[A-Z0-9]{1,6}$/.test(sigla)) {
    return bad(res, 'A sigla aceita de 1 a 6 letras ou números, sem espaços nem acentos.');
  }
  if (sigla !== c.sigla && cncCatPorSigla(c.tipo, sigla)) {
    return bad(res, `Já existe ${CNC_TIPO_LABEL[c.tipo].toLowerCase()} com a sigla ${sigla}.`);
  }

  /* Trocar a sigla precisa levar junto os programas que a usam — senão eles
     ficariam apontando para uma classificação que não existe mais. O nome
     padronizado do programa NÃO é mexido: renomear programa antigo é decisão
     de quem opera a máquina, não efeito colateral de editar o catálogo. */
  let migrados = 0;
  if (sigla !== c.sigla) {
    const campo = { aplicacao: 'aplicacao', area: 'operacao', casco: 'casco', modelo: 'modelo' }[c.tipo];
    for (const p of db.all('cncPrograms').filter(p => p[campo] === c.sigla)) {
      db.update('cncPrograms', p.id, {
        [campo]: sigla,
        historico: (p.historico || []).concat([{
          at: new Date().toISOString(), por: user.name,
          evento: `${CNC_TIPO_LABEL[c.tipo]} renomeada no catálogo: ${c.sigla} → ${sigla} ` +
                  '(o nome do programa não foi alterado)'
        }])
      });
      migrados++;
    }
  }

  const rec = db.update('cncCatalogo', c.id, {
    sigla, nome, ativo: b.ativo === undefined ? c.ativo : !!b.ativo
  });
  audit(user, 'alterou', 'cncCatalogo', rec.id,
    `${CNC_TIPO_LABEL[c.tipo]}: ${c.sigla} — ${c.nome} → ${sigla} — ${nome}` +
    (migrados ? `; ${migrados} programa(s) acompanharam a sigla` : ''));
  ok(res, Object.assign({}, rec, { migrados }));
});

route('DELETE', '/api/cnc/catalogo/:id', 'cnc', async (req, res, user, params) => {
  const c = db.get('cncCatalogo', params.id);
  if (!c) return notFound(res);
  const campo = { aplicacao: 'aplicacao', area: 'operacao', casco: 'casco', modelo: 'modelo' }[c.tipo];
  const emUso = db.all('cncPrograms').filter(p => p[campo] === c.sigla).length;
  const filhos = db.all('cncCatalogo').filter(x => x.paiId === c.id).length;

  /* Classificação em uso não some: os programas que a usam ficariam sem
     identificação. Inativar tira das listas de escolha e mantém o histórico. */
  if (emUso || filhos) {
    const partes = [];
    if (emUso) partes.push(`${emUso} programa(s) usam esta classificação`);
    if (filhos) partes.push(`${filhos} cadastro(s) dependem dela`);
    return send(res, 409, {
      error: partes.join(' e ') + '. Excluir deixaria esses registros sem referência — ' +
        'use "Inativar" para tirá-la das listas de escolha sem perder o histórico.',
      emUso, filhos, podeInativar: true
    });
  }
  db.remove('cncCatalogo', c.id);
  audit(user, 'excluiu', 'cncCatalogo', Number(params.id), `${CNC_TIPO_LABEL[c.tipo]}: ${c.sigla} — ${c.nome}`);
  ok(res, { ok: true });
});

route('GET', '/api/cnc/meta', 'cnc', async (req, res) => {
  const cat = catalogoCnc();
  ok(res, {
    catalogo: cat,
    /* Formato antigo mantido para nada que já consome isto quebrar. */
    aplicacoes: cat.aplicacoes.filter(a => a.ativo).map(a => [a.sigla, a.nome, a.sigla]),
    operacoes: cat.areas.filter(a => a.ativo).map(a => [a.sigla, a.nome, a.sigla])
      .concat([['', 'Não se aplica', '—']]),
    status: CNC_STATUS.map(s => [s, CNC_STATUS_LABEL[s]]),
    extensoes: CNC_EXTS,
    tipos: CNC_TIPOS.map(t => [t, CNC_TIPO_LABEL[t]])
  });
});

route('GET', '/api/cnc/proximo-nome', 'cnc', async (req, res, user, params, query) => {
  ok(res, { nome: proximoNomeCnc(query.aplicacao, query.operacao || query.area, query.modelo) });
});

route('GET', '/api/cnc', 'cnc', async (req, res) => {
  ok(res, db.all('cncPrograms').map(cncComExtras)
    .sort((a, b) => String(a.nome || a.nomeOriginal || '').localeCompare(String(b.nome || b.nomeOriginal || ''), 'pt-BR')));
});

route('GET', '/api/cnc/:id', 'cnc', async (req, res, user, params) => {
  const p = db.get('cncPrograms', params.id);
  return p ? ok(res, cncComExtras(p)) : notFound(res);
});

/* Campos que o histórico acompanha, com o nome que a pessoa lê na tela. */
const CNC_CAMPOS = {
  nome: 'nome padronizado', nomeOriginal: 'nome original', aplicacao: 'aplicação',
  operacao: 'área de operação', casco: 'origem/casco', modelo: 'modelo/código',
  dataCriacao: 'data de criação', dataAlteracao: 'último salvamento',
  status: 'status', cfm: 'CFM', observacoes: 'observações'
};

route('POST', '/api/cnc', 'cnc', async (req, res, user) => {
  const b = await readBody(req);
  const nome = String(b.nome || '').trim().toUpperCase();
  const nomeOriginal = String(b.nomeOriginal || '').trim();
  if (!nome && !nomeOriginal) return bad(res, 'Informe ao menos o nome padronizado ou o nome original.');

  /* Nome padronizado repetido confundiria na máquina, onde só os 5 primeiros
     caracteres aparecem — dois programas com o mesmo nome são indistinguíveis. */
  if (nome && db.all('cncPrograms').some(p => String(p.nome || '').toUpperCase() === nome)) {
    return bad(res, `Já existe um programa com o nome ${nome}.`);
  }

  const rec = db.insert('cncPrograms', {
    nome, nomeOriginal,
    aplicacao: String(b.aplicacao || '').toUpperCase(),
    operacao: String(b.operacao || '').toUpperCase(),
    /* Casco e modelo são opcionais: nem todo programa precisa da
       classificação inteira, e exigi-la travaria o cadastro do dia a dia. */
    casco: String(b.casco || '').toUpperCase(),
    modelo: String(b.modelo || '').toUpperCase(),
    dataCriacao: b.dataCriacao || domain.today(),
    dataAlteracao: b.dataAlteracao || b.dataCriacao || domain.today(),
    status: CNC_STATUS.includes(b.status) ? b.status : 'em_teste',
    cfm: b.cfm === '' || b.cfm === undefined || b.cfm === null ? null : Number(b.cfm),
    observacoes: b.observacoes || '',
    arquivo: null, arquivoNome: '', arquivoTamanho: 0,
    historico: [{
      at: new Date().toISOString(), por: user.name,
      evento: 'Programa cadastrado' + (nome ? ` como ${nome}` : '') +
        (nomeOriginal ? ` (original: ${nomeOriginal})` : '')
    }]
  });
  audit(user, 'criou', 'cncPrograms', rec.id,
    `Programa CNC ${rec.nome || rec.nomeOriginal} — ${rec.aplicacao}${rec.operacao} (${CNC_STATUS_LABEL[rec.status]})`);
  ok(res, cncComExtras(rec));
});

route('PUT', '/api/cnc/:id', 'cnc', async (req, res, user, params) => {
  const antes = db.get('cncPrograms', params.id);
  if (!antes) return notFound(res);
  const b = await readBody(req);
  const nome = b.nome === undefined ? antes.nome : String(b.nome || '').trim().toUpperCase();

  if (nome && db.all('cncPrograms').some(p => p.id !== antes.id && String(p.nome || '').toUpperCase() === nome)) {
    return bad(res, `Já existe outro programa com o nome ${nome}.`);
  }

  const patch = {
    nome,
    /* O nome original é o que o programador usa para achar o arquivo dele.
       Só muda se vier preenchido — nunca é esvaziado por um formulário
       que não trouxe o campo. */
    nomeOriginal: b.nomeOriginal === undefined || b.nomeOriginal === '' ? antes.nomeOriginal : String(b.nomeOriginal).trim(),
    aplicacao: b.aplicacao === undefined ? antes.aplicacao : String(b.aplicacao || '').toUpperCase(),
    operacao: b.operacao === undefined ? antes.operacao : String(b.operacao || '').toUpperCase(),
    casco: b.casco === undefined ? (antes.casco || '') : String(b.casco || '').toUpperCase(),
    modelo: b.modelo === undefined ? (antes.modelo || '') : String(b.modelo || '').toUpperCase(),
    dataCriacao: b.dataCriacao || antes.dataCriacao,
    dataAlteracao: b.dataAlteracao || domain.today(),
    status: CNC_STATUS.includes(b.status) ? b.status : antes.status,
    cfm: b.cfm === '' || b.cfm === undefined || b.cfm === null ? antes.cfm : Number(b.cfm),
    observacoes: b.observacoes === undefined ? antes.observacoes : b.observacoes
  };

  const mudancas = Object.keys(CNC_CAMPOS)
    .filter(k => patch[k] !== undefined && JSON.stringify(antes[k] ?? '') !== JSON.stringify(patch[k] ?? ''))
    .map(k => `${CNC_CAMPOS[k]}: ${antes[k] || '—'} → ${patch[k] || '—'}`);

  if (mudancas.length) {
    patch.historico = (antes.historico || []).concat([{
      at: new Date().toISOString(), por: user.name,
      evento: mudancas.join('; ') + (b.motivo ? ` — ${b.motivo}` : '')
    }]);
  }
  const rec = db.update('cncPrograms', antes.id, patch);
  audit(user, 'alterou', 'cncPrograms', rec.id,
    `Programa CNC ${rec.nome || rec.nomeOriginal}` + (mudancas.length ? ' — ' + mudancas.join('; ') : ' (sem alteração)'));
  ok(res, Object.assign(cncComExtras(rec), { mudancas }));
});

/**
 * Excluir é a última opção — e o servidor diz isso. Programa com histórico
 * técnico ou com o arquivo anexado guarda conhecimento que some junto; o
 * caminho normal é marcar "Não utiliza mais", que tira das listas de trabalho
 * sem perder o que foi aprendido. Quem insiste confirma uma segunda vez.
 */
route('DELETE', '/api/cnc/:id', 'cnc_delete', async (req, res, user, params) => {
  const p = db.get('cncPrograms', params.id);
  if (!p) return notFound(res);
  const confirmado = String(req.headers['x-confirmar'] || '').toLowerCase() === 'sim';
  const alteracoes = (p.historico || []).length;

  if ((alteracoes > 1 || p.arquivo) && !confirmado) {
    const partes = [];
    if (alteracoes > 1) partes.push(`Este programa tem ${alteracoes} registro(s) no histórico técnico`);
    if (p.arquivo) partes.push('e o arquivo do programa anexado');
    return send(res, 409, {
      error: partes.join(' ') + '. Marcar como "Não utiliza mais" tira ele das listas ' +
        'e preserva tudo isso. Excluir apaga de vez. Confirma a exclusão?',
      precisaConfirmar: true, alteracoes, temArquivo: !!p.arquivo
    });
  }

  if (p.arquivo) { try { fs.unlinkSync(path.join(CNC_DIR, p.arquivo)); } catch (e) { /* já não existe */ } }
  db.remove('cncPrograms', p.id);
  audit(user, 'excluiu', 'cncPrograms', Number(params.id),
    `Programa CNC ${p.nome || p.nomeOriginal} excluído` + (alteracoes > 1 ? ` (${alteracoes} registros de histórico)` : ''));
  ok(res, { ok: true });
});

/* ---- arquivo do programa ---- */
route('POST', '/api/cnc/:id/arquivo', 'cnc', async (req, res, user, params, query) => {
  const p = db.get('cncPrograms', params.id);
  if (!p) return notFound(res);
  const nomeArq = String(query.nome || 'programa.nc').slice(0, 160);
  const ext = (nomeArq.split('.').pop() || '').toLowerCase();
  if (!CNC_EXTS.includes(ext)) {
    return bad(res, `Extensão .${ext} não reconhecida. Aceitos: ${CNC_EXTS.map(e => '.' + e).join(', ')}.`);
  }
  const MAX = 20 * 1024 * 1024;   // programa de CNC é texto: 20 MB já é folgado
  if (Number(req.headers['content-length'] || 0) > MAX) {
    return send(res, 413, { error: 'Arquivo grande demais (limite: 20 MB).' });
  }
  fs.mkdirSync(CNC_DIR, { recursive: true });
  const fname = `${p.id}-${Date.now()}.${ext}`;
  const fpath = path.join(CNC_DIR, fname);
  let size = 0, aborted = false;
  const ws = fs.createWriteStream(fpath);
  req.on('data', chunk => {
    if (aborted) return;
    size += chunk.length;
    if (size > MAX) {
      aborted = true; ws.destroy(); fs.unlink(fpath, () => {});
      send(res, 413, { error: 'Arquivo grande demais (limite: 20 MB).' });
      res.on('finish', () => req.destroy());
      return;
    }
    ws.write(chunk);
  });
  req.on('end', () => {
    if (aborted) return;
    ws.end(() => {
      /* Substituir o anexo apaga o anterior: guardar versões antigas sem
         ninguém pedir encheria o disco da oficina em silêncio. */
      if (p.arquivo) { try { fs.unlinkSync(path.join(CNC_DIR, p.arquivo)); } catch (e) { /* já não existe */ } }
      const rec = db.update('cncPrograms', p.id, {
        arquivo: fname, arquivoNome: nomeArq, arquivoTamanho: size,
        historico: (p.historico || []).concat([{
          at: new Date().toISOString(), por: user.name,
          evento: `Arquivo anexado: ${nomeArq} (${(size / 1024).toFixed(1)} KB)`
        }])
      });
      audit(user, 'anexou', 'cncPrograms', p.id, `Arquivo ${nomeArq} no programa ${p.nome || p.nomeOriginal}`);
      ok(res, cncComExtras(rec));
    });
  });
  req.on('error', () => { aborted = true; ws.destroy(); fs.unlink(fpath, () => {}); });
});

route('GET', '/api/cnc/:id/arquivo', 'cnc', async (req, res, user, params) => {
  const p = db.get('cncPrograms', params.id);
  if (!p || !p.arquivo) return notFound(res);
  const fpath = path.join(CNC_DIR, p.arquivo);
  if (!fs.existsSync(fpath)) return notFound(res);
  res.writeHead(200, {
    'Content-Type': 'text/plain; charset=utf-8',
    'Content-Disposition': `attachment; filename="${encodeURIComponent(p.arquivoNome || p.arquivo)}"`,
    'Content-Length': fs.statSync(fpath).size
  });
  fs.createReadStream(fpath).pipe(res);
});

/* ================= Créditos de clientes =================
   Saldo que a empresa deve ao cliente e que ele abate numa compra futura.
   Nasce principalmente de cliente que também é lojista/fornecedor: a empresa
   compra dele e, em vez de pagar, o valor fica combinado como crédito.

   NÃO é conta a receber — ali o cliente deve à empresa, aqui é o contrário.
   Por isso o crédito não entra em Contas a receber nem na projeção de
   entradas; ele só reduz o que o cliente tem a pagar quando é usado.

   Cada registro é uma origem de crédito com seus usos dentro; o saldo é
   sempre valor − usos, nunca um número guardado que pode divergir. */

const creditoSaldo = (c) => Math.round(
  ((Number(c.valor) || 0) - (c.usos || []).reduce((s, u) => s + (Number(u.valor) || 0), 0)) * 100) / 100;

function creditoComSaldo(c) {
  const usado = Math.round((c.usos || []).reduce((s, u) => s + (Number(u.valor) || 0), 0) * 100) / 100;
  return Object.assign({}, c, { usado, saldo: creditoSaldo(c) });
}

/** Saldo de crédito disponível de um cliente (só o que não foi cancelado). */
function saldoDeCreditos(clienteId) {
  return Math.round(db.all('clientCredits')
    .filter(c => c.clienteId === Number(clienteId) && c.status !== 'cancelado')
    .reduce((s, c) => s + creditoSaldo(c), 0) * 100) / 100;
}

/** Texto curto do documento ligado ao crédito ou ao uso, para as telas. */
function refDoCredito(refType, refId) {
  if (!refType || !refId) return '';
  if (refType === 'sales') {
    const v = db.get('sales', refId);
    return v ? `Pedido nº ${v.numero}` : `Pedido #${refId}`;
  }
  if (refType === 'purchases') {
    const c = db.get('purchases', refId);
    return c ? `Compra ${c.documento || '#' + c.id}` : `Compra #${refId}`;
  }
  if (refType === 'serviceOrders') {
    const o = db.get('serviceOrders', refId);
    return o ? `OS nº ${o.numero}` : `OS #${refId}`;
  }
  return `${refType} #${refId}`;
}

route('GET', '/api/credits', ['credits', 'clients'], async (req, res, user, params, query) => {
  let list = db.all('clientCredits');
  if (query.clienteId) list = list.filter(c => c.clienteId === Number(query.clienteId));
  ok(res, list.map(c => Object.assign(creditoComSaldo(c), {
    refLabel: refDoCredito(c.refType, c.refId),
    usos: (c.usos || []).map(u => Object.assign({}, u, { refLabel: refDoCredito(u.refType, u.refId) }))
  })).sort((a, b) => (b.data || '').localeCompare(a.data || '') || b.id - a.id));
});

/** Aba de créditos do cliente: saldo, cada crédito e a linha do tempo. */
route('GET', '/api/clients/:id/credits', ['credits', 'clients'], async (req, res, user, params) => {
  const cliente = db.get('clients', params.id);
  if (!cliente) return notFound(res);
  const creditos = db.all('clientCredits').filter(c => c.clienteId === cliente.id)
    .map(c => Object.assign(creditoComSaldo(c), { refLabel: refDoCredito(c.refType, c.refId) }));

  /* Uma linha só por acontecimento — gerou, usou, cancelou — que é como a
     pessoa confere o extrato do cliente. */
  const movimentos = [];
  for (const c of creditos) {
    movimentos.push({
      tipo: 'geracao', creditoId: c.id, data: c.data, valor: c.valor,
      origem: c.origemLabel || c.origem, descricao: c.descricao || '',
      refLabel: c.refLabel, observacoes: c.observacoes || '', por: c.por || ''
    });
    for (const u of (c.usos || [])) {
      movimentos.push({
        tipo: 'uso', creditoId: c.id, data: u.data, valor: -Math.abs(Number(u.valor) || 0),
        origem: 'Uso do crédito', descricao: u.descricao || '',
        refLabel: refDoCredito(u.refType, u.refId), observacoes: u.obs || '', por: u.por || ''
      });
    }
    if (c.status === 'cancelado') {
      movimentos.push({
        tipo: 'cancelamento', creditoId: c.id, data: c.canceladoEm || c.data, valor: 0,
        origem: 'Crédito cancelado', descricao: c.motivoCancelamento || '',
        refLabel: '', observacoes: '', por: c.canceladoPor || ''
      });
    }
  }
  movimentos.sort((a, b) => (b.data || '').localeCompare(a.data || ''));

  ok(res, {
    clienteId: cliente.id, clienteNome: cliente.nome,
    saldo: saldoDeCreditos(cliente.id),
    gerado: Math.round(creditos.filter(c => c.status !== 'cancelado')
      .reduce((s, c) => s + (Number(c.valor) || 0), 0) * 100) / 100,
    usado: Math.round(creditos.reduce((s, c) => s + c.usado, 0) * 100) / 100,
    creditos: creditos.sort((a, b) => (b.data || '').localeCompare(a.data || '') || b.id - a.id),
    movimentos
  });
});

const ORIGENS_CREDITO = [
  ['compra', 'Compra feita com o cliente (lojista/fornecedor)'],
  ['devolucao', 'Devolução de peça ou serviço'],
  ['acordo', 'Acordo comercial'],
  ['pagamento_maior', 'Pagamento a maior do cliente'],
  ['outro', 'Outro']
];

route('POST', '/api/credits', 'credits_manage', async (req, res, user) => {
  const b = await readBody(req);
  const cliente = db.get('clients', b.clienteId);
  if (!cliente) return bad(res, 'Escolha o cliente do crédito.');
  const valor = Math.round((Number(b.valor) || 0) * 100) / 100;
  if (valor <= 0) return bad(res, 'O valor do crédito precisa ser maior que zero.');
  const origem = (ORIGENS_CREDITO.find(o => o[0] === b.origem) || ORIGENS_CREDITO[0])[0];
  const rec = db.insert('clientCredits', {
    clienteId: cliente.id, valor,
    origem, origemLabel: (ORIGENS_CREDITO.find(o => o[0] === origem) || [])[1] || origem,
    descricao: b.descricao || '',
    data: b.data || domain.today(),
    refType: b.refType || null, refId: b.refId ? Number(b.refId) : null,
    observacoes: b.observacoes || '',
    status: 'aberto', usos: [],
    por: user.name
  });
  audit(user, 'criou', 'clientCredits', rec.id,
    `Crédito de R$ ${valor.toFixed(2)} para ${cliente.nome} — ${rec.origemLabel}`);
  ok(res, creditoComSaldo(rec));
});

/**
 * Usa parte (ou todo) do crédito. Apontado a uma venda, o valor entra como
 * um abatimento dela e Contas a receber passa a cobrar só o que falta.
 *
 * De propósito não mexe no fluxo de caixa: nenhum dinheiro entrou. O crédito
 * já existia como obrigação da empresa e agora encontrou a dívida do cliente
 * — lançar entrada aqui inflaria o caixa com dinheiro que não circulou.
 */
route('POST', '/api/credits/:id/usar', 'credits_manage', async (req, res, user, params) => {
  const b = await readBody(req);
  const c = db.get('clientCredits', params.id);
  if (!c) return notFound(res);
  if (c.status === 'cancelado') return bad(res, 'Este crédito foi cancelado.');
  const valor = Math.round((Number(b.valor) || 0) * 100) / 100;
  if (valor <= 0) return bad(res, 'Informe o valor a usar.');
  const saldo = creditoSaldo(c);
  if (valor > saldo + 0.005) {
    return bad(res, `O saldo deste crédito é R$ ${saldo.toFixed(2)} — não dá para usar R$ ${valor.toFixed(2)}.`);
  }

  const data = b.data || domain.today();
  let sale = null;
  if (b.refType === 'sales' && b.refId) {
    sale = db.get('sales', Number(b.refId));
    if (!sale) return bad(res, 'Pedido não encontrado.');
    if (sale.clienteId !== c.clienteId) return bad(res, 'O pedido é de outro cliente.');
    const jaAbatido = (sale.recebimentos || []).reduce((s, r) => s + r.valor, 0);
    const emAberto = Math.round((sale.valorTotal - jaAbatido) * 100) / 100;
    if (valor > emAberto + 0.005) {
      return bad(res, `O pedido tem R$ ${emAberto.toFixed(2)} em aberto — não dá para abater R$ ${valor.toFixed(2)}.`);
    }
  }

  const uso = {
    valor, data, refType: b.refType || null, refId: b.refId ? Number(b.refId) : null,
    descricao: b.descricao || (sale ? `Abatido no pedido nº ${sale.numero}` : 'Uso do crédito'),
    obs: b.obs || '', por: user.name, em: new Date().toISOString()
  };
  const usos = (c.usos || []).concat([uso]);
  const restante = Math.round((c.valor - usos.reduce((s, u) => s + u.valor, 0)) * 100) / 100;
  db.update('clientCredits', c.id, { usos, status: restante <= 0.005 ? 'usado' : 'aberto' });

  if (sale) {
    const lista = (sale.recebimentos || []).concat([
      { valor, data, forma: 'credito', obs: `Crédito #${c.id}${uso.obs ? ' — ' + uso.obs : ''}` }]);
    db.update('sales', sale.id, { recebimentos: lista });
    reequilibrarReceberDaVenda(Object.assign({}, sale, { recebimentos: lista }),
      { data, forma: 'credito', vencimentoSaldo: b.vencimentoSaldo });
    audit(user, 'abateu', 'sales', sale.id,
      `Pedido nº ${sale.numero} — R$ ${valor.toFixed(2)} abatidos do crédito #${c.id}`);
  }
  audit(user, 'usou', 'clientCredits', c.id,
    `R$ ${valor.toFixed(2)} usados${sale ? ` no pedido nº ${sale.numero}` : ''}; ` +
    `saldo do crédito R$ ${restante.toFixed(2)}`);
  ok(res, { credito: creditoComSaldo(db.get('clientCredits', c.id)), saldoCliente: saldoDeCreditos(c.clienteId) });
});

/** Desfaz um uso — o valor volta para o saldo e o abatimento sai da venda. */
route('POST', '/api/credits/:id/estornar-uso', 'credits_manage', async (req, res, user, params) => {
  const b = await readBody(req);
  const c = db.get('clientCredits', params.id);
  if (!c) return notFound(res);
  const idx = Number(b.index);
  const usos = (c.usos || []).slice();
  if (!usos[idx]) return bad(res, 'Uso não encontrado.');
  const [removido] = usos.splice(idx, 1);
  db.update('clientCredits', c.id, { usos, status: 'aberto' });

  if (removido.refType === 'sales' && removido.refId) {
    const sale = db.get('sales', removido.refId);
    if (sale) {
      /* Tira exatamente o abatimento deste crédito, não um recebimento
         qualquer de mesmo valor que possa existir na venda. */
      const lista = (sale.recebimentos || []).slice();
      const alvo = lista.findIndex(r => r.forma === 'credito' && r.valor === removido.valor &&
        r.data === removido.data && String(r.obs || '').includes(`Crédito #${c.id}`));
      if (alvo >= 0) {
        lista.splice(alvo, 1);
        db.update('sales', sale.id, { recebimentos: lista });
        reequilibrarReceberDaVenda(Object.assign({}, sale, { recebimentos: lista }),
          { data: removido.data, forma: 'credito' });
      }
    }
  }
  audit(user, 'estornou', 'clientCredits', c.id,
    `Uso de R$ ${Number(removido.valor).toFixed(2)} estornado — motivo: ${b.motivo || 'não informado'}`);
  ok(res, { credito: creditoComSaldo(db.get('clientCredits', c.id)), saldoCliente: saldoDeCreditos(c.clienteId) });
});

/** Cancela o crédito inteiro. Só enquanto nada dele foi usado. */
route('POST', '/api/credits/:id/cancelar', 'credits_manage', async (req, res, user, params) => {
  const b = await readBody(req);
  const c = db.get('clientCredits', params.id);
  if (!c) return notFound(res);
  if ((c.usos || []).length) {
    return bad(res, 'Este crédito já foi usado. Estorne os usos antes de cancelá-lo.');
  }
  if (!b.motivo) return bad(res, 'Explique o motivo do cancelamento — ele fica registrado.');
  db.update('clientCredits', c.id, {
    status: 'cancelado', motivoCancelamento: b.motivo,
    canceladoPor: user.name, canceladoEm: domain.today()
  });
  audit(user, 'cancelou', 'clientCredits', c.id,
    `Crédito de R$ ${Number(c.valor).toFixed(2)} cancelado — motivo: ${b.motivo}`);
  ok(res, { ok: true, saldoCliente: saldoDeCreditos(c.clienteId) });
});

/* ================= Fretes pagos pela empresa =================
   Custo de logística das vendas em que a empresa banca o envio.
   Vinculado à venda, entra no lucro real dela (venda − taxa − custo −
   frete) e na DRE como "Frete de venda / Logística". */
route('POST', '/api/freights', ['freights', 'payables'], async (req, res, user) => {
  const b = await readBody(req);
  const sale = b.saleId ? db.get('sales', b.saleId) : null;
  const cliente = b.clienteId ? db.get('clients', b.clienteId) : (sale ? db.get('clients', sale.clienteId) : null);
  const valor = Number(b.valor) || 0;
  if (valor <= 0) return bad(res, 'Informe o valor do frete.');
  const rec = db.insert('freights', {
    clienteId: cliente ? cliente.id : null,
    saleId: sale ? sale.id : null,
    produto: b.produto || (sale ? (sale.itens || []).map(i => i.produto).join(', ') : ''),
    dataEnvio: b.dataEnvio || domain.today(),
    transportadora: b.transportadora || '',
    conhecimento: b.conhecimento || '',
    origem: b.origem || (db.settings.empresa && db.settings.empresa.cidade) || '',
    destino: b.destino || (cliente ? [cliente.cidade, cliente.estado].filter(Boolean).join('/') : ''),
    valor,
    formaPagamento: b.formaPagamento || 'pix',
    dataPagamento: b.dataPagamento || '',
    observacoes: b.observacoes || '',
    status: 'aberto'
  });
  if (b.pagoAgora) {
    const data = b.dataPagamento || domain.today();
    db.update('freights', rec.id, { status: 'pago', dataPagamento: data });
    db.insert('cashflow', {
      tipo: 'saida', valor, data, conta: b.conta || 'principal',
      formaPagamento: normalizaForma(b.formaPagamento || rec.formaPagamento) || 'outro',
      categoria: 'frete_venda',
      origem: `Frete — ${rec.transportadora || 'envio'}${sale ? ` (Pedido nº ${sale.numero})` : ''}`,
      documento: rec.conhecimento, refType: 'freights', refId: rec.id,
      descricao: 'Frete pago pela empresa'
    });
  }
  audit(user, 'criou', 'freights', rec.id,
    `Frete ${rec.transportadora || ''} R$ ${valor.toFixed(2)}${sale ? ` — Pedido nº ${sale.numero}` : ''}${b.pagoAgora ? ' (pago)' : ''}`);
  ok(res, db.get('freights', rec.id));
});

route('POST', '/api/freights/:id/pay', ['freights', 'payables'], async (req, res, user, params) => {
  const b = await readBody(req);
  const f = db.get('freights', params.id);
  if (!f) return notFound(res);
  if (f.status === 'pago') return bad(res, 'Este frete já está pago.');
  const data = b.data || domain.today();
  const sale = f.saleId ? db.get('sales', f.saleId) : null;
  db.update('freights', f.id, { status: 'pago', dataPagamento: data });
  db.insert('cashflow', {
    tipo: 'saida', valor: f.valor, data, conta: b.conta || 'principal',
    formaPagamento: normalizaForma(b.forma || f.formaPagamento) || 'outro',
    categoria: 'frete_venda',
    origem: `Frete — ${f.transportadora || 'envio'}${sale ? ` (Pedido nº ${sale.numero})` : ''}`,
    documento: f.conhecimento, refType: 'freights', refId: f.id,
    descricao: 'Frete pago pela empresa'
  });
  audit(user, 'pagou', 'freights', f.id, `Frete R$ ${Number(f.valor).toFixed(2)} em ${data}`);
  ok(res, { ok: true });
});

/* Desfaz o pagamento: estorna a saída de caixa e volta para aberto. */
route('POST', '/api/freights/:id/unpay', ['freights', 'payables'], async (req, res, user, params) => {
  const f = db.get('freights', params.id);
  if (!f) return notFound(res);
  if (f.status !== 'pago') return bad(res, 'Este frete não está pago.');
  const lanc = db.all('cashflow').filter(c => c.refType === 'freights' && c.refId === f.id);
  for (const c of lanc) db.remove('cashflow', c.id);
  db.update('freights', f.id, { status: 'aberto', dataPagamento: '' });
  audit(user, 'estornou', 'freights', f.id, `Pagamento de frete desfeito — ${lanc.length} lançamento(s) de caixa estornado(s)`);
  ok(res, { ok: true, estornados: lanc.length });
});

route('POST', '/api/purchases/parse-nfe', 'purchases', async (req, res, user) => {
  const b = await readBody(req);
  if (!b.xml) return bad(res, 'Envie o conteúdo XML da NF-e');
  const parsed = parseNfeXml(b.xml);
  if (!parsed || (!parsed.fornecedorNome && !parsed.numeroNF)) return bad(res, 'Não foi possível interpretar o XML. Confira o arquivo ou lance manualmente.');
  const forn = db.all('suppliers').find(s => s.cnpj && s.cnpj.replace(/\D/g, '') === parsed.fornecedorCnpj);
  ok(res, Object.assign(parsed, { fornecedorId: forn ? forn.id : null }));
});

/* ---- fornecedores: fechamento mensal ---- */
route('GET', '/api/suppliers/:id/open', 'suppliers', async (req, res, user, params) => {
  const exps = db.all('supplierExpenses').filter(e => e.fornecedorId === Number(params.id) && e.status === 'aberto');
  ok(res, { despesas: exps, total: exps.reduce((s, e) => s + e.valor, 0) });
});

/**
 * Fechamento da fatura mensal do fornecedor: compara o valor cobrado com os
 * registros internos e aponta divergência antes de permitir o pagamento.
 */
route('POST', '/api/supplierInvoices', 'suppliers', async (req, res, user) => {
  const b = await readBody(req);
  const forn = db.get('suppliers', b.fornecedorId);
  if (!forn) return bad(res, 'Fornecedor inválido');
  const exps = db.all('supplierExpenses').filter(e => e.fornecedorId === forn.id && e.status === 'aberto');
  const valorRegistrado = exps.reduce((s, e) => s + e.valor, 0);
  const valorCobrado = Number(b.valorCobrado) || 0;
  const diferenca = valorCobrado - valorRegistrado;
  const rec = db.insert('supplierInvoices', {
    fornecedorId: forn.id, fornecedorNome: forn.nome,
    mes: b.mes || domain.today().slice(0, 7),
    valorCobrado, valorRegistrado, diferenca,
    status: Math.abs(diferenca) < 0.005 ? 'conferida' : 'divergente',
    expenseIds: exps.map(e => e.id),
    vencimento: b.vencimento || '',
    observacoes: b.observacoes || ''
  });
  audit(user, 'fechamento', 'supplierInvoices', rec.id,
    `Fatura ${forn.nome} ${rec.mes}: cobrado R$ ${valorCobrado.toFixed(2)} × registrado R$ ${valorRegistrado.toFixed(2)}`
    + (rec.status === 'divergente' ? ` — DIVERGÊNCIA R$ ${diferenca.toFixed(2)}` : ''));
  ok(res, rec);
});

/** Confirma a fatura (após conferência) e gera a conta a pagar na agenda de sexta. */
route('POST', '/api/supplierInvoices/:id/confirm', 'suppliers', async (req, res, user, params) => {
  const b = await readBody(req);
  const inv = db.get('supplierInvoices', params.id);
  if (!inv) return notFound(res);
  if (inv.payableId) return bad(res, 'Fatura já confirmada');
  const valorFinal = Number(b.valorFinal) || inv.valorCobrado;
  for (const eid of inv.expenseIds) db.update('supplierExpenses', eid, { status: 'faturado', faturaId: inv.id });
  const venc = b.vencimento || inv.vencimento || domain.addDays(domain.today(), 10);
  const payable = db.insert('payables', {
    descricao: `Fatura mensal ${inv.fornecedorNome} — ${inv.mes}`,
    categoria: 'componentes', fornecedorId: inv.fornecedorId,
    valor: valorFinal, vencimento: venc,
    tipoPagamento: 'programado', dataProgramada: domain.previousFriday(venc),
    status: 'aberto', refType: 'supplierInvoices', refId: inv.id
  });
  db.update('supplierInvoices', inv.id, { status: 'confirmada', payableId: payable.id, valorFinal });
  audit(user, 'confirmou', 'supplierInvoices', inv.id, `Fatura ${inv.fornecedorNome} ${inv.mes} — R$ ${valorFinal.toFixed(2)}`);
  ok(res, { ok: true, payableId: payable.id });
});

/* ---- contas a pagar ---- */
route('POST', '/api/payables', 'payables', async (req, res, user) => {
  const b = await readBody(req);
  if (!b.descricao || !b.valor || !b.vencimento) return bad(res, 'Descrição, valor e vencimento são obrigatórios');
  const imediato = b.tipoPagamento === 'imediato';
  const rec = db.insert('payables', {
    descricao: b.descricao, categoria: b.categoria || 'despesa_operacional',
    fornecedorId: b.fornecedorId || null,
    formaPagamento: normalizaForma(b.formaPagamento) || '',
    /* Fatura do cartão: as compras do mês já lançaram a despesa na data em
       que foram feitas. Pagar a fatura quita o cartão — não lança de novo. */
    faturaCartao: !!b.faturaCartao,
    valor: Number(b.valor), vencimento: b.vencimento,
    tipoPagamento: imediato ? 'imediato' : 'programado',
    dataProgramada: imediato ? (b.data || domain.today()) : domain.previousFriday(b.vencimento),
    status: 'aberto', documento: b.documento || '', observacoes: b.observacoes || '',
    recurringId: b.recurringId ? Number(b.recurringId) : null
  });
  completeRecurringTask(rec.recurringId, rec.vencimento); // dá baixa na pendência do mês
  audit(user, 'criou', 'payables', rec.id, `${rec.descricao} — R$ ${rec.valor.toFixed(2)} (venc. ${rec.vencimento}, pgto ${rec.dataProgramada})`);
  // Pagamento imediato já sai do caixa na data em que ocorreu.
  if (imediato && b.pagarAgora) {
    db.update('payables', rec.id, { status: 'pago', dataPagamento: rec.dataProgramada });
    db.insert('cashflow', {
      tipo: 'saida', valor: rec.valor, data: rec.dataProgramada, conta: b.conta || 'principal',
      formaPagamento: normalizaForma(b.formaPagamento) || 'transferencia',
      categoria: rec.categoria, origem: rec.descricao, documento: rec.documento,
      refType: 'payables', refId: rec.id, descricao: 'Pagamento imediato'
    });
  }
  ok(res, rec);
});

/**
 * Corrigir uma conta a pagar já lançada — função da Direção.
 *
 * O cuidado principal é não duplicar dinheiro: se a conta já foi paga, existe
 * uma saída no fluxo de caixa amarrada a ela. Aqui essa saída é ACERTADA no
 * lugar, nunca criada de novo — trocar o valor da conta e deixar o caixa com
 * o valor antigo é o tipo de divergência que só aparece no fechamento do mês.
 *
 * O parcelamento de uma compra vira uma conta por parcela; cada uma é
 * corrigida por aqui, individualmente.
 */
route('PUT', '/api/payables/:id', 'payables_edit', async (req, res, user, params) => {
  const b = await readBody(req);
  const antes = db.get('payables', params.id);
  if (!antes) return notFound(res);
  if (!b.descricao || !b.vencimento) return bad(res, 'Descrição e vencimento são obrigatórios');
  const valor = Math.round((Number(b.valor) || 0) * 100) / 100;
  if (valor <= 0) return bad(res, 'O valor precisa ser maior que zero.');

  const imediato = b.tipoPagamento === 'imediato';
  /* A data programada é derivada do vencimento (sexta anterior) — recalcular
     aqui evita que corrigir o vencimento deixe a agenda apontando para o dia
     antigo. Quem quiser fugir da regra informa dataProgramada explicitamente. */
  const dataProgramada = b.dataProgramada
    || (imediato ? (antes.dataProgramada || domain.today()) : domain.previousFriday(b.vencimento));

  const patch = {
    descricao: b.descricao,
    categoria: b.categoria || antes.categoria,
    fornecedorId: b.fornecedorId ? Number(b.fornecedorId) : null,
    formaPagamento: b.formaPagamento !== undefined
      ? (normalizaForma(b.formaPagamento) || '') : (antes.formaPagamento || ''),
    faturaCartao: b.faturaCartao !== undefined ? !!b.faturaCartao : !!antes.faturaCartao,
    valor, vencimento: b.vencimento,
    tipoPagamento: imediato ? 'imediato' : 'programado',
    dataProgramada,
    forma: b.forma || antes.forma || '',
    documento: b.documento || '',
    observacoes: b.observacoes || '',
    recurringId: b.recurringId ? Number(b.recurringId) : null
  };
  const rotulos = {
    descricao: 'descrição', categoria: 'categoria', fornecedorId: 'fornecedor', valor: 'valor',
    vencimento: 'vencimento', tipoPagamento: 'tipo de pagamento', dataProgramada: 'agendamento',
    forma: 'forma de pagamento', documento: 'documento', observacoes: 'observações',
    recurringId: 'conta recorrente'
  };
  const mudancas = Object.keys(patch)
    .filter(k => JSON.stringify(antes[k] ?? '') !== JSON.stringify(patch[k] ?? ''))
    .map(k => `${rotulos[k] || k}: ${antes[k] ?? '—'} → ${patch[k] ?? '—'}`);

  const rec = db.update('payables', antes.id, patch);

  /* Conta paga: a saída correspondente no caixa acompanha a correção, em vez
     de virar um segundo lançamento. */
  let caixaAjustado = false;
  if (rec.status === 'pago') {
    const saida = db.all('cashflow').find(c =>
      c.refType === 'payables' && c.refId === rec.id && c.tipo === 'saida');
    if (saida) {
      db.update('cashflow', saida.id, {
        valor: rec.valor, categoria: rec.categoria,
        origem: rec.descricao, documento: rec.documento || ''
      });
      caixaAjustado = true;
    }
  }

  audit(user, 'alterou', 'payables', rec.id,
    `Conta a pagar corrigida pela Direção${mudancas.length ? ' — ' + mudancas.join('; ') : ' (sem alteração de campos)'}` +
    (caixaAjustado ? '; saída no caixa acertada junto' : ''));
  ok(res, Object.assign({}, rec, { caixaAjustado, mudancas }));
});

/**
 * Excluir conta a pagar — o caso é a conta lançada errada ou em duplicidade.
 *
 * Antes de apagar, confere o que está pendurado nela e responde 409 pedindo
 * confirmação em vez de agir por conta própria. O que precisa ser desfeito
 * junto é desfeito aqui mesmo: a saída no fluxo de caixa some com a conta,
 * senão o dinheiro continuaria contado. Apagar uma duplicada não encosta na
 * conta correta — cada registro é independente, e é justamente por isso que
 * a exclusão é por id, nunca por descrição ou valor.
 */
route('DELETE', '/api/payables/:id', 'payables_edit', async (req, res, user, params) => {
  const p = db.get('payables', params.id);
  if (!p) return notFound(res);
  const confirmado = String(req.headers['x-confirmar'] || '').toLowerCase() === 'sim';
  const caixa = db.all('cashflow').filter(c => c.refType === 'payables' && c.refId === p.id);
  const paga = p.status === 'pago' || caixa.length > 0;

  /* Parcela de compra: apagar só ela deixa a compra com o parcelamento
     incompleto. É legítimo (foi lançada a mais), mas a pessoa precisa saber. */
  const compra = p.refType === 'purchases' && p.refId ? db.get('purchases', p.refId) : null;

  if ((paga || compra) && !confirmado) {
    const partes = [];
    if (paga) {
      partes.push(`Esta conta consta como paga (${brl(p.valor)}` +
        (p.dataPagamento ? ` em ${dataBR(p.dataPagamento)}` : '') + ')' +
        (caixa.length ? ` e tem ${caixa.length} saída(s) no fluxo de caixa, que serão estornadas` : ''));
    }
    if (compra) {
      const irmas = db.all('payables').filter(x =>
        x.refType === 'purchases' && x.refId === compra.id && x.id !== p.id).length;
      partes.push(`É uma parcela da compra ${compra.documentoNumero || '#' + compra.id}` +
        (irmas ? `, que tem outras ${irmas} parcela(s) — elas continuam como estão` : ''));
    }
    return send(res, 409, {
      error: partes.join('. ') + '. Confirma a exclusão?',
      precisaConfirmar: true, saidasCaixa: caixa.length
    });
  }

  for (const c of caixa) db.remove('cashflow', c.id);
  db.remove('payables', p.id);
  audit(user, 'excluiu', 'payables', Number(params.id),
    `${p.descricao || 'Conta'} — ${brl(p.valor)} (venc. ${dataBR(p.vencimento)}) excluída` +
    (caixa.length ? `; ${caixa.length} saída(s) de caixa estornada(s)` : '') +
    (compra ? `; era parcela da compra ${compra.documentoNumero || '#' + compra.id}` : ''));
  ok(res, { ok: true, estornadas: caixa.length });
});

/**
 * Desfazer o pagamento de uma conta: ela volta para a agenda e a saída sai
 * do caixa. É o caminho para corrigir "paguei e não era essa" sem precisar
 * apagar a conta inteira e recadastrar.
 */
route('POST', '/api/payables/:id/unpay', 'payables', async (req, res, user, params) => {
  const p = db.get('payables', params.id);
  if (!p) return notFound(res);
  if (p.status !== 'pago') return bad(res, 'Esta conta não está paga.');
  const caixa = db.all('cashflow').filter(c => c.refType === 'payables' && c.refId === p.id);
  for (const c of caixa) db.remove('cashflow', c.id);
  db.update('payables', p.id, { status: 'aberto', dataPagamento: null, semCaixa: false, motivoSemCaixa: '' });
  audit(user, 'estornou', 'payables', p.id,
    `Pagamento de ${p.descricao} (${brl(p.valor)}) desfeito; ` +
    `${caixa.length} saída(s) retirada(s) do caixa`);
  ok(res, { ok: true, estornadas: caixa.length });
});

route('POST', '/api/payables/:id/pay', 'payables', async (req, res, user, params) => {
  const b = await readBody(req);
  const p = db.get('payables', params.id);
  if (!p) return notFound(res);
  if (p.status === 'pago') return bad(res, 'Conta já paga');
  const data = b.data || domain.today();
  const forma = normalizaForma(b.forma || b.formaPagamento || p.formaPagamento) || 'transferencia';

  /* FATURA DO CARTÃO: as compras que a compõem já lançaram a despesa no
     caixa, cada uma na sua data. Lançar a fatura de novo contaria o mesmo
     dinheiro duas vezes — então a conta é quitada SEM saída no caixa. */
  if (p.faturaCartao) {
    db.update('payables', p.id, {
      status: 'pago', dataPagamento: data, formaPagamento: forma, semCaixa: true,
      motivoSemCaixa: 'Fatura de cartão — as compras do período já lançaram a despesa na data em que foram feitas'
    });
    audit(user, 'pagou', 'payables', p.id,
      `${p.descricao} — ${brl(p.valor)} em ${dataBR(data)} (fatura de cartão: quitada sem nova saída no caixa, ` +
      'porque as compras do período já estão lançadas)');
    return ok(res, { ok: true, semCaixa: true,
      aviso: 'Fatura quitada sem lançar saída no caixa — as compras do cartão já estão lançadas nas datas em que foram feitas.' });
  }

  db.update('payables', p.id, { status: 'pago', dataPagamento: data, formaPagamento: forma });
  db.insert('cashflow', {
    tipo: 'saida', valor: p.valor, data, conta: b.conta || 'principal',
    formaPagamento: forma,
    categoria: p.categoria, origem: p.descricao, documento: p.documento || '',
    refType: 'payables', refId: p.id, descricao: 'Pagamento de conta'
  });
  audit(user, 'pagou', 'payables', p.id, `${p.descricao} — R$ ${p.valor.toFixed(2)} em ${data} (${forma})`);
  ok(res, { ok: true });
});

/** Agenda de sexta-feira: contas agrupadas por data programada. */
route('GET', '/api/payables/agenda', 'payables', async (req, res) => {
  const abertos = withOverdue(db.all('payables')).filter(p => p.status !== 'pago');
  const grupos = {};
  for (const p of abertos) {
    const d = p.dataProgramada || p.vencimento;
    (grupos[d] = grupos[d] || []).push(p);
  }
  const dias = Object.keys(grupos).sort().map(d => ({
    data: d,
    total: grupos[d].reduce((s, p) => s + p.valor, 0),
    contas: grupos[d]
  }));
  ok(res, dias);
});

/* ---- contas a receber ---- */
route('POST', '/api/receivables/generate', 'receivables', async (req, res, user) => {
  const b = await readBody(req);
  const cliente = db.get('clients', b.clienteId);
  if (!cliente) return bad(res, 'Cliente é obrigatório');
  const parcels = domain.generateInstallments(b.dataVenda || domain.today(), b.valor,
    b.parcelas, b.intervaloDias, b.primeiroVencimento);
  const out = [];
  for (const p of parcels) {
    out.push(db.insert('receivables', {
      clienteId: cliente.id, origem: b.origem || 'venda', refType: b.refType || null, refId: b.refId || null,
      descricao: `${b.descricao || 'Boleto'} — parcela ${p.parcela}/${p.parcelas}`,
      forma: b.forma || 'boleto', valor: p.valor, vencimento: p.vencimento,
      status: 'aberto', parcela: p.parcela, parcelas: p.parcelas
    }));
  }
  audit(user, 'gerou', 'receivables', null, `${parcels.length} parcela(s) de ${cliente.nome} — total R$ ${Number(b.valor).toFixed(2)}`);
  ok(res, out);
});

/* Edita uma parcela. Se ela já foi recebida, o dinheiro já entrou no caixa:
   a alteração exige confirmação explícita (confirmar: true) e o lançamento
   de caixa ligado acompanha o novo valor. Tudo fica no histórico. */
route('PUT', '/api/receivables/:id', 'receivables', async (req, res, user, params) => {
  const antes = db.get('receivables', params.id);
  if (!antes) return notFound(res);
  const b = await readBody(req);

  /* No espelho da venda, valor, recebido e situação vêm do pedido: editar
     aqui seria desfeito na próxima sincronização e, pior, faria a tela
     divergir do dinheiro registrado. Vencimento e observação, sim — é onde
     se anota "o cliente prometeu pagar dia 20". */
  if (ehEspelhoDaVenda(antes)) {
    const pedido = (db.get('sales', antes.refId) || {}).numero || antes.refId;
    if (b.valor !== undefined && Math.round(Number(b.valor) * 100) !== Math.round((Number(antes.valor) || 0) * 100)) {
      return bad(res, `O valor desta linha é o valor do pedido nº ${pedido}. Altere o pedido em Vendas — ` +
        'Contas a receber acompanha sozinho.');
    }
    if (b.status !== undefined && b.status !== antes.status) {
      return bad(res, 'A situação desta linha vem dos recebimentos do pedido. Use ✓ Receber (aqui ou no pedido) ' +
        'para registrar o pagamento — ela passa a Pago sozinha.');
    }
  }

  const patch = {};
  for (const k of ['descricao', 'forma', 'vencimento', 'observacoes']) {
    if (b[k] !== undefined) patch[k] = b[k];
  }
  if (b.valor !== undefined) patch.valor = Number(b.valor) || 0;
  /* Situação editável à mão: só entre "em cobrança" e "cancelada". Marcar
     uma parcela como paga por aqui criaria dinheiro que nunca passou pelo
     caixa — a baixa é sempre pelo recebimento. */
  if (b.status !== undefined && b.status !== antes.status) {
    if (!['aberto', 'cancelada'].includes(b.status)) {
      return bad(res, 'A situação só pode ser alterada entre "em cobrança" e "cancelada". Para dar baixa, use Receber.');
    }
    if (antes.status === 'paga' || antes.status === 'parcial') {
      return bad(res, 'Esta parcela já tem recebimento lançado — estorne o recebimento antes de mudar a situação.');
    }
    if (!(b.status === 'aberto' && antes.status === 'vencida')) patch.status = b.status;
  }
  if (b.clienteId !== undefined) {
    const c = db.get('clients', b.clienteId);
    if (!c) return bad(res, 'Cliente não encontrado.');
    patch.clienteId = c.id;
  }

  const NOMES = { clienteId: 'Cliente', descricao: 'Descrição', forma: 'Forma', valor: 'Valor',
                  vencimento: 'Vencimento', observacoes: 'Observações', status: 'Situação' };
  const mudancas = Object.keys(patch)
    .filter(k => JSON.stringify(antes[k] ?? '') !== JSON.stringify(patch[k] ?? ''))
    .map(k => `${NOMES[k]}: ${antes[k] ?? '—'} → ${patch[k] === '' ? '—' : patch[k]}`);
  if (!mudancas.length) return ok(res, antes);

  const mexeuDinheiro = patch.valor !== undefined && patch.valor !== antes.valor;
  /* No espelho da venda, valor e situação já são barrados acima: o que
     sobra (vencimento, observação) não mexe em dinheiro e não precisa de
     confirmação. */
  const temMovimento = !ehEspelhoDaVenda(antes) &&
    (antes.status === 'paga' || antes.status === 'parcial');
  if (temMovimento) {
    if (!b.confirmar) {
      return send(res, 409, {
        error: antes.status === 'paga'
          ? 'Esta parcela já possui movimentação financeira (recebida). Deseja realmente alterar seus dados?'
          : `Esta parcela já possui movimentação financeira (${brl(recebidoDaParcela(antes))} recebidos em parte). Deseja realmente alterar seus dados?`,
        precisaConfirmar: true
      });
    }
    if (mexeuDinheiro && antes.status === 'paga') {
      // O caixa acompanha, para os relatórios não divergirem do recebível.
      for (const c of db.all('cashflow').filter(c => c.refType === 'receivables' && c.refId === antes.id)) {
        db.update('cashflow', c.id, { valor: patch.valor });
      }
      mudancas.push('(entrada de caixa ligada ajustada junto)');
    }
    /* Recebida em parte: os recebimentos já lançados continuam valendo como
       estão — mudar o valor da parcela só muda o que ainda falta. Se o novo
       valor já estiver coberto pelo que entrou, a parcela fica quitada. */
    if (mexeuDinheiro && antes.status === 'parcial') {
      const recebido = recebidoDaParcela(antes);
      if (recebido >= patch.valor - 0.005) {
        patch.status = 'paga';
        mudancas.push(`(o que já entrou — ${brl(recebido)} — cobre o novo valor: parcela quitada)`);
      } else {
        mudancas.push(`(${brl(recebido)} já recebidos continuam lançados; falta ${brl(Math.round((patch.valor - recebido) * 100) / 100)})`);
      }
    }
  }

  /* Histórico da própria parcela: quem mudou o quê e quando. É aqui que
     ficam registradas as alterações de data de vencimento e de valor. */
  patch.historico = (antes.historico || []).concat([{
    em: new Date().toISOString(), por: user.name, tipo: 'edicao', mudancas: mudancas.slice()
  }]);

  const rec = db.update('receivables', antes.id, patch);
  audit(user, 'alterou', 'receivables', rec.id,
    `${antes.descricao || 'Parcela'} editada — ${mudancas.join('; ')}${antes.status === 'paga' ? ' [parcela já recebida — alteração confirmada]' : ''}`);
  ok(res, rec);
});

/* Exclui uma conta a receber lançada por engano.
   Sem recebimento, sai limpo. Com recebimento, só sai se o usuário
   confirmar — e aí a entrada correspondente sai do caixa junto, para o
   financeiro não ficar com dinheiro que não existe. */
route('DELETE', '/api/receivables/:id', 'receivables', async (req, res, user, params) => {
  const r = db.get('receivables', params.id);
  if (!r) return notFound(res);
  if (ehEspelhoDaVenda(r)) {
    const pedido = (db.get('sales', r.refId) || {}).numero || r.refId;
    return bad(res, `Esta linha é o espelho do pedido nº ${pedido} e voltaria na próxima atualização. ` +
      'Para tirar a cobrança, cancele ou exclua o pedido em Vendas — o recebimento já registrado é preservado.');
  }
  const caixa = db.all('cashflow').filter(c => c.refType === 'receivables' && c.refId === r.id);
  const recebida = r.status === 'paga' || caixa.length > 0;

  if (recebida && String((req.headers['x-confirmar'] || '')).toLowerCase() !== 'sim') {
    return send(res, 409, {
      error: `Esta parcela já tem recebimento registrado (${brl(r.valor)}` +
             (r.dataRecebimento ? ` em ${dataBR(r.dataRecebimento)}` : '') +
             `). Excluir vai retirar também ${caixa.length} entrada(s) do caixa. Confirma?`,
      precisaConfirmar: true, entradasCaixa: caixa.length
    });
  }
  for (const c of caixa) db.remove('cashflow', c.id);
  db.remove('receivables', r.id);
  audit(user, 'excluiu', 'receivables', r.id,
    `${r.descricao || 'Parcela'} — R$ ${Number(r.valor).toFixed(2)} excluída` +
    (caixa.length ? ` (${caixa.length} entrada(s) de caixa estornada(s))` : ''));
  ok(res, { ok: true, estornadas: caixa.length });
});

/* Recalcula as parcelas futuras de um grupo (os boletos de uma venda).
   As já recebidas não são tocadas: o valor recebido é abatido do novo
   total e o restante é redistribuído nas novas parcelas em aberto. */
route('POST', '/api/receivables/replan', 'receivables', async (req, res, user) => {
  const b = await readBody(req);
  const ids = Array.isArray(b.ids) ? b.ids.map(Number) : [];
  const grupo = ids.map(id => db.get('receivables', id)).filter(Boolean);
  if (!grupo.length) return bad(res, 'Nenhuma parcela informada.');

  /* Parcela com dinheiro dentro (paga ou recebida em parte) não é refeita:
     ela fica como está e o valor dela sai do que será redistribuído. */
  const pagas = grupo.filter(r => r.status === 'paga' || r.status === 'parcial');
  const abertas = grupo.filter(r => r.status === 'aberto' || r.status === 'vencida');
  if (!abertas.length) return bad(res, 'Todas as parcelas deste grupo já foram recebidas ou canceladas.');

  const totalNovo = Number(b.valorTotal) || grupo.reduce((s, r) => s + r.valor, 0);
  const jaRecebido = pagas.reduce((s, r) => s + r.valor, 0);
  const restante = Math.round((totalNovo - jaRecebido) * 100) / 100;
  if (restante <= 0) return bad(res, `O novo total (R$ ${totalNovo.toFixed(2)}) é menor ou igual ao já recebido (R$ ${jaRecebido.toFixed(2)}). Nada sobraria para as parcelas futuras.`);

  const totalParcelas = Math.max(pagas.length + 1, Number(b.parcelas) || grupo.length);
  const futuras = totalParcelas - pagas.length;
  const intervalo = Number(b.intervaloDias) || 30;

  const modelo = abertas[0];
  const base = (modelo.descricao || 'Boleto').replace(/ — parcela \d+\/\d+$/, '');

  // Datas: a 1ª parcela cai na data informada; sem ela, conta da data-base.
  const primeiro = b.primeiroVencimento || b.primeiraData || '';
  const parcels = domain.generateInstallments(
    b.dataVenda || domain.today(), restante, futuras, intervalo, primeiro);

  for (const r of abertas) db.remove('receivables', r.id);
  const criadas = [];
  for (const p of parcels) {
    const n = pagas.length + p.parcela;
    criadas.push(db.insert('receivables', {
      clienteId: modelo.clienteId, origem: modelo.origem || 'venda',
      refType: modelo.refType || null, refId: modelo.refId || null,
      descricao: `${base} — parcela ${n}/${totalParcelas}`,
      forma: b.forma || modelo.forma || 'boleto',
      valor: p.valor, vencimento: p.vencimento,
      status: 'aberto', parcela: n, parcelas: totalParcelas
    }));
  }
  // Renumera as pagas para o novo total de parcelas, sem tocar em valor/data.
  for (const r of pagas) {
    db.update('receivables', r.id, {
      parcelas: totalParcelas,
      descricao: `${base} — parcela ${r.parcela}/${totalParcelas}`
    });
  }

  audit(user, 'alterou', 'receivables', null,
    `Parcelas recalculadas: ${grupo.length} → ${totalParcelas} (${pagas.length} já recebida(s) preservada(s)); ` +
    `total R$ ${totalNovo.toFixed(2)}, restante R$ ${restante.toFixed(2)} em ${futuras}x; ` +
    `vencimentos ${criadas.map(c => c.vencimento).join(', ')}`);
  ok(res, { pagas: pagas.length, criadas });
});

/* Baixa de um boleto. Sem `valor` informado, recebe tudo que falta (é o
   caminho de sempre). Com um valor menor, a parcela fica "recebida em parte":
   o que entrou vai para o caixa na hora e o restante continua sendo cobrado
   — sem lançamento duplicado, porque o caixa registra só o que foi recebido. */
route('POST', '/api/receivables/:id/receive', 'receivables', async (req, res, user, params) => {
  const b = await readBody(req);
  const r = db.get('receivables', params.id);
  if (!r) return notFound(res);
  if (r.status === 'paga') {
    return bad(res, ehEspelhoDaVenda(r)
      ? `O pedido nº ${(db.get('sales', r.refId) || {}).numero || r.refId} já está totalmente recebido — não há saldo a receber.`
      : 'Parcela já recebida');
  }
  if (r.status === 'cancelada') {
    return bad(res, ehEspelhoDaVenda(r)
      ? 'O pedido desta cobrança está cancelado — não é possível receber.'
      : 'Parcela cancelada — não é possível receber.');
  }

  /* A linha da venda em Contas a receber é o espelho da venda. Receber por
     aqui é o MESMO evento de "Registrar recebimento" no pedido: o dinheiro
     é gravado na venda, gera uma entrada de caixa só, e o espelho se
     atualiza. As duas telas trabalham sobre o mesmo registro financeiro. */
  if (ehEspelhoDaVenda(r)) {
    const sale = db.get('sales', r.refId);
    if (!sale) return bad(res, 'O pedido desta cobrança não existe mais.');
    const resumo = resumoFinanceiroVenda(sale);
    const informadoEsp = b.valor === undefined || b.valor === null || b.valor === '';
    const valorEsp = informadoEsp ? resumo.saldo : Math.round(Number(b.valor) * 100) / 100;
    if (!(valorEsp > 0)) return bad(res, 'Informe um valor de recebimento maior que zero.');
    if (valorEsp > resumo.saldo + 0.005) {
      return bad(res, `Deste pedido já entraram ${brl(resumo.recebido)} de ${brl(resumo.total)}. ` +
        `Falta receber ${brl(resumo.saldo)} — não dá para lançar ${brl(valorEsp)}.`);
    }
    const dataEsp = b.data || domain.today();
    const igual = (sale.recebimentos || []).find(x =>
      Math.round((Number(x.valor) || 0) * 100) === Math.round(valorEsp * 100) && x.data === dataEsp);
    if (igual && !b.confirmar) {
      return send(res, 409, {
        error: `Já existe um recebimento de ${brl(valorEsp)} em ${dataBR(dataEsp)} neste pedido. ` +
               'Lançar de novo somaria o mesmo dinheiro duas vezes. O cliente pagou duas vezes esse valor?',
        precisaConfirmar: true
      });
    }
    const recId = db.nextNumber('recebimentoVenda', 1);
    const forma = b.forma || r.forma || (sale.pagamento || {}).forma || 'pix';
    db.update('sales', sale.id, {
      recebimentos: (sale.recebimentos || []).concat([{
        recId, valor: valorEsp, data: dataEsp, forma,
        obs: b.obs || 'Recebido pela tela de Contas a receber', por: user.name
      }])
    });
    db.insert('cashflow', {
      tipo: 'entrada', valor: valorEsp, data: dataEsp, conta: b.conta || 'principal',
      formaPagamento: normalizaForma(forma) || 'outro',
      categoria: 'venda_cabecote', origem: `Pedido nº ${sale.numero} — recebimento`,
      documento: '', refType: 'sales', refId: sale.id, recebimentoId: recId,
      descricao: `Recebimento (${forma})`
    });
    const saldoEsp = sincronizarReceberDaVenda(db.get('sales', sale.id), { forma });
    audit(user, 'recebeu', 'sales', sale.id,
      `Pedido nº ${sale.numero} — recebido ${brl(valorEsp)} em ${dataBR(dataEsp)} (${forma}) ` +
      `pela tela de Contas a receber; saldo ${brl(saldoEsp)}`);
    return ok(res, {
      ok: true, valor: valorEsp, recebido: Math.round((resumo.recebido + valorEsp) * 100) / 100,
      saldo: saldoEsp, quitada: saldoEsp <= 0.005, pedido: sale.numero
    });
  }

  const data = b.data || domain.today();
  const total = Math.round((Number(r.valor) || 0) * 100) / 100;
  const antes = Math.round((Number(r.recebido) || 0) * 100) / 100;
  const falta = Math.round((total - antes) * 100) / 100;
  const informado = b.valor === undefined || b.valor === null || b.valor === '';
  const valor = informado ? falta : Math.round(Number(b.valor) * 100) / 100;
  if (!(valor > 0)) return bad(res, 'Informe um valor de recebimento maior que zero.');
  if (valor > falta + 0.005) {
    return bad(res, `Falta receber ${brl(falta)} desta parcela — não dá para lançar ${brl(valor)}.`);
  }

  const recebido = Math.round((antes + valor) * 100) / 100;
  const quitada = recebido >= total - 0.005;
  const forma = b.forma || r.forma || 'boleto';
  const lancamento = { data, valor, forma, conta: b.conta || 'principal', obs: b.obs || '', por: user.name };

  db.update('receivables', r.id, {
    status: quitada ? 'paga' : 'parcial',
    recebido, dataRecebimento: data,
    recebimentos: (r.recebimentos || []).concat([lancamento]),
    historico: (r.historico || []).concat([{
      em: new Date().toISOString(), por: user.name, tipo: 'recebimento',
      mudancas: [`Recebido ${brl(valor)} em ${dataBR(data)} (${forma})` +
        (quitada ? ' — parcela quitada' : ` — falta ${brl(Math.round((total - recebido) * 100) / 100)}`)]
    }])
  });

  const categoria = r.origem === 'servico' ? 'servico' : 'venda_cabecote';
  db.insert('cashflow', {
    tipo: 'entrada', valor, data, conta: b.conta || 'principal',
    formaPagamento: normalizaForma(forma) || 'outro',
    categoria, origem: r.descricao, documento: '',
    refType: 'receivables', refId: r.id,
    descricao: quitada ? 'Recebimento' : 'Recebimento parcial'
  });
  audit(user, 'recebeu', 'receivables', r.id,
    `${r.descricao} — R$ ${valor.toFixed(2)} em ${data}` +
    (quitada ? '' : ` (parcial — falta R$ ${(total - recebido).toFixed(2)})`));
  ok(res, { ok: true, valor, recebido, saldo: Math.round((total - recebido) * 100) / 100, quitada });
});

route('POST', '/api/receivables/:id/cancel', 'receivables', async (req, res, user, params) => {
  const r = db.get('receivables', params.id);
  if (!r) return notFound(res);
  if (ehEspelhoDaVenda(r)) {
    return bad(res, `Esta linha é o espelho do pedido nº ${(db.get('sales', r.refId) || {}).numero || r.refId} — ` +
      'ela acompanha a venda. Para tirá-la da cobrança, cancele o pedido em Vendas: ' +
      'as parcelas, a produção e o estoque são tratados junto.');
  }
  db.update('receivables', r.id, { status: 'cancelada' });
  audit(user, 'cancelou', 'receivables', r.id, r.descricao);
  ok(res, { ok: true });
});

/* ---- agenda financeira (contas a pagar + a receber no calendário) ---- */
/* A agenda não guarda nada de si: lê o que já está em Contas a pagar e em
   Contas a receber e devolve agrupado por dia. É por isso que nenhum
   compromisso precisa ser cadastrado duas vezes — o que entra nos módulos
   financeiros aparece aqui sozinho, e a baixa lá some daqui na hora.

   base=vencimento (padrão): o dia em que o compromisso vence.
   base=caixa: o dia em que o dinheiro se move — nas contas a pagar é a
   sexta-feira programada (ou a data em que foi efetivamente pago), que é
   como a oficina organiza os pagamentos de verdade. */

const AGENDA_BASES = ['vencimento', 'caixa'];

function fimDoMesDe(iso) {
  const d = new Date(iso.slice(0, 8) + '01T12:00:00');
  d.setMonth(d.getMonth() + 1);
  d.setDate(0);
  return d.toISOString().slice(0, 10);
}

function agendaDataDe(item, base) {
  return base === 'caixa'
    ? (item.dataBaixa || item.dataProgramada || item.vencimento)
    : (item.vencimento || item.dataProgramada || item.dataBaixa);
}

function agendaItemPagar(p) {
  const forn = p.fornecedorId ? db.get('suppliers', p.fornecedorId) : null;
  return {
    tipo: 'pagar', id: p.id,
    descricao: p.descricao || '',
    contraparte: forn ? forn.nome : '',
    contraparteId: forn ? forn.id : null,
    valor: Number(p.valor) || 0,
    vencimento: p.vencimento || null,
    dataProgramada: p.dataProgramada || null,
    dataBaixa: p.dataPagamento || null,
    status: p.status,
    liquidado: p.status === 'pago',
    cancelado: false,
    categoria: p.categoria || '',
    documento: p.documento || '',
    observacoes: p.observacoes || ''
  };
}

/* Frete em aberto é dinheiro que a empresa deve — antes ele só aparecia no
   caixa DEPOIS de pago, e a agenda dizia "isto é tudo que vence no período"
   sem contá-lo. O mesmo vale para os pagamentos de RH programados. */
function agendaItemFrete(f) {
  const c = f.clienteId ? db.get('clients', f.clienteId) : null;
  return {
    tipo: 'pagar', id: f.id, modulo: 'freights',
    descricao: `Frete ${f.transportadora || ''}`.trim() + (f.conhecimento ? ` — CT-e ${f.conhecimento}` : ''),
    contraparte: f.transportadora || (c ? c.nome : ''),
    contraparteId: null,
    valor: Number(f.valor) || 0,
    vencimento: f.dataPagamento || f.dataEnvio || null,
    dataProgramada: null,
    dataBaixa: f.status === 'pago' ? (f.dataPagamento || null) : null,
    status: f.status === 'pago' ? 'pago' : 'aberto',
    liquidado: f.status === 'pago',
    cancelado: false,
    categoria: 'frete_venda',
    documento: f.conhecimento || '',
    observacoes: f.observacoes || ''
  };
}

function agendaItemRH(h) {
  const emp = h.employeeId ? db.get('employees', h.employeeId) : null;
  return {
    tipo: 'pagar', id: h.id, modulo: 'hrPayments',
    descricao: `RH — ${h.descricao || h.tipo || 'pagamento'}`,
    contraparte: emp ? emp.nome : '',
    contraparteId: null,
    valor: Number(h.valor) || 0,
    vencimento: h.vencimento || h.data || null,
    dataProgramada: null,
    dataBaixa: h.status === 'pago' ? (h.dataPagamento || null) : null,
    status: h.status === 'pago' ? 'pago' : 'aberto',
    liquidado: h.status === 'pago',
    cancelado: false,
    categoria: h.tipo === 'beneficio' ? 'beneficios' : 'salarios',
    documento: '',
    observacoes: h.observacoes || ''
  };
}

function agendaItemReceber(r) {
  const c = r.clienteId ? db.get('clients', r.clienteId) : null;
  return {
    tipo: 'receber', id: r.id,
    descricao: r.descricao || '',
    contraparte: c ? c.nome : '',
    contraparteId: c ? c.id : null,
    contraparteCodigo: c ? (c.codigo || '') : '',
    /* Recebida em parte entra pelo que ainda falta: o que já caiu no caixa
       não é compromisso futuro. */
    valor: r.status === 'parcial' ? saldoDaParcela(r) : (Number(r.valor) || 0),
    valorTotal: Number(r.valor) || 0,
    recebido: recebidoDaParcela(r),
    vencimento: r.vencimento || null,
    dataProgramada: null,
    dataBaixa: r.dataRecebimento || null,
    status: r.status,
    liquidado: r.status === 'paga',
    cancelado: r.status === 'cancelada',
    forma: r.forma || '',
    origem: r.origem || '',
    refType: r.refType || null, refId: r.refId || null
  };
}

route('GET', '/api/agenda', ['agenda', 'payables', 'receivables'], async (req, res, user, params, query) => {
  const base = AGENDA_BASES.includes(query.base) ? query.base : 'vencimento';
  const hoje = domain.today();
  const dia = v => (/^\d{4}-\d{2}-\d{2}$/.test(v || '') ? v : null);
  const de = dia(query.de) || hoje.slice(0, 8) + '01';
  const ate = dia(query.ate) || fimDoMesDe(de);
  if (ate < de) return bad(res, 'O fim do período não pode ser antes do início');

  /* Cada perfil recebe só o lado que já pode ver: quem não enxerga contas a
     pagar continua sem enxergá-las aqui. */
  const podeVerPagar = can(user, 'payables');
  const podeVerReceber = can(user, 'receivables');
  const itens = []
    .concat(podeVerPagar ? withOverdue(db.all('payables')).map(agendaItemPagar) : [])
    /* Frete e RH não passam por Contas a pagar, mas vencem como qualquer
       compromisso: sem eles a agenda mostrava um mês mais folgado do que é. */
    .concat(podeVerPagar ? withOverdue(db.all('freights').map(agendaItemFrete)) : [])
    .concat(podeVerPagar && can(user, 'hr') ? withOverdue(db.all('hrPayments').map(agendaItemRH)) : [])
    .concat(podeVerReceber ? withOverdue(db.all('receivables')).map(agendaItemReceber) : []);

  const dias = new Map();
  const totais = {
    pagar: 0, receber: 0, saldo: 0,
    pagarAberto: 0, pagarLiquidado: 0, receberAberto: 0, receberLiquidado: 0,
    vencidos: 0, vencidosValor: 0, qtd: 0
  };

  for (const it of itens) {
    const data = agendaDataDe(it, base);
    if (!data || data < de || data > ate) continue;
    it.data = data;
    if (!dias.has(data)) {
      dias.set(data, { data, pagar: 0, receber: 0, pagarAberto: 0, receberAberto: 0,
                       liquidados: 0, vencidos: 0, saldo: 0, itens: [] });
    }
    const d = dias.get(data);
    d.itens.push(it);
    // Cancelado continua visível no detalhe do dia, mas não entra em soma alguma.
    if (it.cancelado) continue;
    totais.qtd++;
    if (it.tipo === 'pagar') {
      d.pagar += it.valor; totais.pagar += it.valor;
      if (it.liquidado) { d.liquidados++; totais.pagarLiquidado += it.valor; }
      else { d.pagarAberto += it.valor; totais.pagarAberto += it.valor; }
    } else {
      d.receber += it.valor; totais.receber += it.valor;
      if (it.liquidado) { d.liquidados++; totais.receberLiquidado += it.valor; }
      else { d.receberAberto += it.valor; totais.receberAberto += it.valor; }
    }
    if (it.status === 'vencida') { d.vencidos++; totais.vencidos++; totais.vencidosValor += it.valor; }
  }

  for (const d of dias.values()) {
    d.saldo = d.receber - d.pagar;
    // A receber primeiro, e dentro de cada lado o maior valor no topo.
    d.itens.sort((a, b) => (a.tipo === b.tipo ? b.valor - a.valor : a.tipo === 'receber' ? -1 : 1));
  }
  totais.saldo = totais.receber - totais.pagar;

  ok(res, {
    de, ate, base, hoje, podeVerPagar, podeVerReceber,
    dias: [...dias.values()].sort((a, b) => (a.data < b.data ? -1 : 1)),
    totais
  });
});

/* ---- financeiro: projeção e DRE ---- */
route('GET', '/api/projection', 'projection', async (req, res) => ok(res, domain.projection()));
route('GET', '/api/dre', 'dre', async (req, res, user, params, query) => {
  ok(res, domain.dre(query.mes || domain.today().slice(0, 7)));
});

/* ---- análises / BI ---- */
/**
 * Agregados para os gráficos. Cada bloco só é incluído se o usuário tiver a
 * permissão correspondente (produção não recebe caixa nem resultado, etc.).
 */
route('GET', '/api/analytics', 'dashboard', async (req, res, user, params, query) => {
  const meses = Math.min(24, Math.max(3, Number(query.meses) || 12));
  const now = new Date();
  const months = [];
  for (let i = meses - 1; i >= 0; i--) {
    months.push(new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - i, 1)).toISOString().slice(0, 7));
  }
  const NOMES = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
  const label = m => NOMES[Number(m.slice(5, 7)) - 1] + '/' + m.slice(2, 4);
  const inWindow = d => d && months.includes(String(d).slice(0, 7));

  const sales = db.all('sales').filter(s => s.status !== 'cancelado');
  const oss = db.all('serviceOrders').filter(o => !osCancelada(o));
  const out = { janelaMeses: meses };

  // Faturamento mensal: só para quem tem acesso ao financeiro (Produção não recebe valores)
  if (canFinanceiro(user)) {
    out.faturamento = months.map(m => ({
      mes: label(m),
      vendas: sales.filter(s => String(s.dataPedido || '').slice(0, 7) === m).reduce((a, s) => a + (s.valorTotal || 0), 0),
      servicos: oss.filter(o => String(o.dataFinalizacao || '').slice(0, 7) === m).reduce((a, o) => a + (o.valorTotal || 0), 0)
    }));
  }

  if (can(user, 'cashflow')) {
    const flows = db.all('cashflow');
    out.caixa = months.map(m => ({
      mes: label(m),
      entradas: flows.filter(f => f.tipo === 'entrada' && String(f.data || '').slice(0, 7) === m).reduce((a, f) => a + f.valor, 0),
      saidas: flows.filter(f => f.tipo === 'saida' && String(f.data || '').slice(0, 7) === m).reduce((a, f) => a + f.valor, 0)
    }));
  }

  if (can(user, 'projection')) {
    const receiv = withOverdue(db.all('receivables')).filter(r => r.status === 'aberto' || r.status === 'vencida');
    const pay = withOverdue(db.all('payables')).filter(p => p.status !== 'pago');
    const t = domain.today();
    out.vencidos = {
      aReceber: receiv.filter(r => r.vencimento < t).reduce((a, r) => a + r.valor, 0),
      aPagar: pay.filter(p => p.vencimento < t).reduce((a, p) => a + p.valor, 0)
    };
    out.projecaoSemanal = [];
    let ini = t;
    for (let w = 0; w < 8; w++) {
      const fim = domain.addDays(ini, 6);
      out.projecaoSemanal.push({
        semana: ini.slice(8, 10) + '/' + ini.slice(5, 7),
        aReceber: receiv.filter(r => r.vencimento >= ini && r.vencimento <= fim).reduce((a, r) => a + r.valor, 0),
        aPagar: pay.filter(p => p.vencimento >= ini && p.vencimento <= fim).reduce((a, p) => a + p.valor, 0)
      });
      ini = domain.addDays(ini, 7);
    }
  }

  if (can(user, 'sales')) {
    const accP = {}, accE = {};
    for (const s of sales.filter(s => inWindow(s.dataPedido))) {
      for (const i of s.itens || []) {
        const k = i.produto;
        accP[k] = accP[k] || { produto: k.replace('Cabeçote ', ''), qtd: 0, valor: 0 };
        accP[k].qtd += i.qtd; accP[k].valor += i.total;
      }
      const uf = s.estado || '—';
      accE[uf] = accE[uf] || { uf, qtd: 0, valor: 0 };
      accE[uf].qtd += (s.itens || []).reduce((a, i) => a + i.qtd, 0);
      accE[uf].valor += s.valorTotal || 0;
    }
    out.produtos = Object.values(accP).sort((a, b) => b.valor - a.valor);
    let estados = Object.values(accE).sort((a, b) => b.valor - a.valor);
    if (estados.length > 8) {
      const resto = estados.slice(7);
      estados = estados.slice(0, 7);
      estados.push({ uf: 'Outros', qtd: resto.reduce((a, e) => a + e.qtd, 0), valor: resto.reduce((a, e) => a + e.valor, 0) });
    }
    out.estados = estados;
    // Sem acesso financeiro: os gráficos ficam por quantidade — valores nem trafegam
    if (!canFinanceiro(user)) {
      out.produtos = out.produtos.map(p => ({ produto: p.produto, qtd: p.qtd }));
      out.estados = out.estados.map(e => ({ uf: e.uf, qtd: e.qtd }));
    }
  }

  // Funil da oficina (etapas ordenadas — contagens atuais)
  const entries = db.all('headEntries');
  out.funil = [
    { etapa: 'Recebido / em análise', qtd: entries.filter(e => ['recebido', 'em_analise', 'aguardando_orcamento'].includes(e.status)).length },
    { etapa: 'Orçado — aguardando aprovação', qtd: db.all('quotes').filter(q => q.status === 'aberto').length },
    { etapa: 'Em serviço', qtd: oss.filter(o => ['em_analise', 'em_andamento', 'aguardando_peca'].includes(o.status)).length },
    { etapa: 'Aguardando pagamento', qtd: oss.filter(o => o.status === 'aguardando_pagamento' || (o.status === 'finalizado' && o.pagamentoStatus === 'pendente')).length },
    { etapa: 'Finalizado no período', qtd: oss.filter(o => inWindow(o.dataFinalizacao)).length }
  ];

  if (can(user, 'finance_sensitive')) {
    out.resultado = months.map(m => ({
      mes: label(m),
      resultado: sales.filter(s => String(s.dataPedido || '').slice(0, 7) === m)
        .reduce((a, s) => a + domain.saleResult(s).resultado, 0)
    }));
  }

  /* ---- Bloco operacional: só contagens, sem nenhum valor ----
     É o que sustenta as Análises do perfil Produção. */
  const op = {};

  // Movimento da oficina: cabeçotes que entraram × OS finalizadas por mês
  op.movimento = months.map(m => ({
    mes: label(m),
    entradas: entries.filter(e => String(e.dataChegada || '').slice(0, 7) === m).length,
    finalizadas: oss.filter(o => String(o.dataFinalizacao || '').slice(0, 7) === m).length
  }));

  // Serviços mais executados (itens das OS do período) — puro volume
  const accS = {};
  for (const o of oss) {
    if (!inWindow(o.dataFinalizacao) && !['em_analise', 'em_andamento', 'aguardando_peca'].includes(o.status)) continue;
    for (const i of o.itens || []) {
      const k = String(i.nome || '').trim() || '—';
      accS[k] = (accS[k] || 0) + (Number(i.qtd) || 1);
    }
  }
  op.servicosTop = Object.entries(accS).map(([nome, qtd]) => ({ nome, qtd }))
    .sort((a, b) => b.qtd - a.qtd).slice(0, 10);

  // Situação atual das ordens de produção
  const pos = db.all('productionOrders');
  const ST_PROD = [['nao_produzido', 'Não produzido'], ['preparacao', 'Preparação'],
    ['usinagem', 'Usinagem'], ['montagem', 'Montagem'], ['pronto', 'Pronto']];
  op.statusProducao = ST_PROD.map(([k, l]) => ({ etapa: l, qtd: pos.filter(p => p.status === k).length }));

  // Cabeçotes produzidos por configuração (quantidade, sem preço)
  const accC = {};
  for (const s of sales.filter(s => inWindow(s.dataPedido))) {
    for (const i of s.itens || []) {
      const k = `${i.tipo === 'crossflow' ? 'Crossflow' : 'Unilateral'} ${i.rotuloStage || domain.rotuloStage(i.stage, i.variante)}`;
      accC[k] = (accC[k] || 0) + (Number(i.qtd) || 1);
    }
  }
  op.configuracoes = Object.entries(accC).map(([config, qtd]) => ({ config, qtd })).sort((a, b) => b.qtd - a.qtd);

  // Assistência de pista por evento: quantas pessoas e dias por etapa (sem R$)
  const accE2 = {};
  for (const p of db.all('hrPayments').filter(p => p.tipo === 'pista')) {
    const ev = p.evento || 'Sem evento';
    accE2[ev] = accE2[ev] || { evento: ev, pessoas: 0, dias: 0, data: p.data || '' };
    accE2[ev].pessoas++;
    accE2[ev].dias += Number(p.dias) || 1;
    if ((p.data || '') > accE2[ev].data) accE2[ev].data = p.data;
  }
  op.pista = Object.values(accE2).sort((a, b) => (a.data < b.data ? 1 : -1)).slice(0, 10);

  out.operacional = op;
  ok(res, out);
});

/* ---- RH ---- */
route('POST', '/api/hrPayments/:id/pay', 'hr', async (req, res, user, params) => {
  const b = await readBody(req);
  const h = db.get('hrPayments', params.id);
  if (!h) return notFound(res);
  if (h.status === 'pago') return bad(res, 'Já pago');
  const data = b.data || domain.today();
  const cat = h.tipo === 'salario' ? 'salarios' : h.tipo === 'beneficio' ? 'beneficios' : 'salarios';
  db.update('hrPayments', h.id, { status: 'pago', dataPagamento: data });
  db.insert('cashflow', {
    tipo: 'saida', valor: h.valor, data, conta: b.conta || 'principal',
    formaPagamento: normalizaForma(b.forma) || 'transferencia',
    categoria: cat, origem: `RH — ${h.descricao || h.tipo}`, documento: '',
    refType: 'hrPayments', refId: h.id, descricao: 'Pagamento de RH'
  });
  audit(user, 'pagou', 'hrPayments', h.id, `${h.tipo} — R$ ${h.valor.toFixed(2)}`);
  ok(res, { ok: true });
});

/* Desfaz o pagamento: estorna a saída de caixa que ele gerou e devolve o
   lançamento para "pendente", liberando edição e exclusão. */
route('POST', '/api/hrPayments/:id/unpay', 'hr', async (req, res, user, params) => {
  const h = db.get('hrPayments', params.id);
  if (!h) return notFound(res);
  if (h.status !== 'pago') return bad(res, 'Este lançamento não está pago.');
  const lancamentos = db.all('cashflow').filter(c => c.refType === 'hrPayments' && c.refId === h.id);
  for (const c of lancamentos) db.remove('cashflow', c.id);
  db.update('hrPayments', h.id, { status: 'pendente', dataPagamento: null });
  audit(user, 'estornou', 'hrPayments', h.id,
    `Pagamento desfeito — R$ ${Number(h.valor || 0).toFixed(2)}; ${lancamentos.length} lançamento(s) de caixa estornado(s)`);
  ok(res, { ok: true, estornados: lancamentos.length });
});

/* ---- rastreabilidade: linha do tempo de um cabeçote/entidade ---- */
route('GET', '/api/trace/:entity/:id', 'dashboard', async (req, res, user, params) => {
  const list = db.all('audit').filter(a =>
    (a.entity === params.entity && String(a.entityId) === String(params.id)) ||
    (a.action === 'timeline' && a.entity === params.entity && String(a.entityId) === String(params.id))
  ).sort((a, b) => a.at < b.at ? -1 : 1);
  ok(res, list);
});

/* ===================================================================== */
/* CRUD genérico                                                          */
/* ===================================================================== */

async function handleRest(req, res, user, collection, id) {
  const cfg = REST[collection];
  if (!cfg) return notFound(res);
  const method = req.method;
  /* Corrigir um registro já lançado pesa mais do que criar um: contas a
     pagar, caixa e histórico de estoque pedem permissão de Direção para
     alterar, mas seguem abertos para lançar no dia a dia. */
  const needed = method === 'GET' ? cfg.perm
    : (method === 'PUT' && cfg.editPerm) ? cfg.editPerm
      : (cfg.writePerm || cfg.perm);
  if (!can(user, needed)) {
    return forbidden(res, method === 'PUT' && cfg.editPerm
      ? `Alterar ${cfg.label.toLowerCase()} é uma função da Direção`
      : `Sem permissão: ${cfg.label}`);
  }

  if (method === 'GET' && !id) {
    let list = db.all(collection);
    if (collection === 'receivables' || collection === 'payables') list = withOverdue(list);
    if (collection === 'cashflow') list = comFormaPagamento(list);
    return ok(res, list.map(r => sanitize(user, collection, r)));
  }
  if (method === 'GET') {
    const rec = db.get(collection, id);
    return rec ? ok(res, sanitize(user, collection, rec)) : notFound(res);
  }
  if (method === 'POST') {
    const body = await readBody(req);
    delete body.id;
    // O código do cliente é gerado pelo sistema — não vem do formulário.
    if (collection === 'clients') body.codigo = proximoCodigoCliente();
    /* A OS nasce numerada mesmo quando não vem da aprovação de um orçamento:
       sem número ela aparece como "OS nº undefined" no caixa e nas telas. */
    if (collection === 'serviceOrders' && !body.numero) body.numero = db.nextNumber('os', 1);
    const rec = db.insert(collection, body);
    audit(user, 'criou', collection, rec.id, cfg.label + (body.nome ? ': ' + body.nome : body.titulo ? ': ' + body.titulo : ' #' + rec.id));
    return ok(res, rec);
  }
  /* Um lançamento de RH já pago gerou uma saída no caixa. Alterar o valor ou
     apagar o lançamento deixaria essa saída órfã ou com valor divergente —
     primeiro se desfaz o pagamento (que estorna o caixa), depois se edita. */
  if ((collection === 'hrPayments' || collection === 'freights') && (method === 'PUT' || method === 'DELETE')) {
    const atual = db.get(collection, id);
    if (atual && atual.status === 'pago') {
      return bad(res, 'Este lançamento já foi pago e gerou uma saída no caixa. Use “Desfazer pagamento” antes de editar ou excluir.');
    }
  }

  /* Alterar a linha da movimentação por aqui deixaria o saldo do item como
     estava — a correção precisa recalcular o estoque, e quem faz isso é
     PUT /api/stock/history/:id. */
  if (collection === 'stockMoves' && (method === 'PUT' || method === 'DELETE')) {
    return bad(res, 'Movimentação de estoque se corrige em Estoque → Histórico, para o saldo do item ser recalculado junto.');
  }

  if (method === 'PUT') {
    const body = await readBody(req);
    delete body.id; delete body.createdAt;
    // O código acompanha o cliente para sempre: corrigir o nome não o altera.
    if (collection === 'clients') delete body.codigo;
    const before = db.get(collection, id);
    if (!before) return notFound(res);
    const changed = Object.keys(body).filter(k => JSON.stringify(before[k]) !== JSON.stringify(body[k]));
    const rec = db.update(collection, id, body);
    audit(user, 'alterou', collection, rec.id, `${cfg.label} #${rec.id}` + (changed.length ? ` — campos: ${changed.join(', ')}` : ''));
    return ok(res, rec);
  }
  if (method === 'DELETE') {
    const rec = db.get(collection, id);
    if (!rec) return notFound(res);
    // Entidades com efeitos financeiros/históricos não são apagadas, apenas canceladas.
    // (sales, serviceOrders e receivables têm rota própria de exclusão, com estorno.)
    /* payables, cashflow e purchases têm rota própria de exclusão, que
       desfaz junto o que o lançamento gerou (caixa, parcelas, estoque).
       Chegar aqui significaria apagar sem esse acerto. */
    if (['quotes', 'supplierInvoices'].includes(collection)) {
      return bad(res, 'Este registro não pode ser excluído — use cancelamento/estorno para manter a rastreabilidade');
    }
    /* Cadastro em uso não some: apagá-lo deixaria vendas, compras e
       lançamentos apontando para o vazio. O caminho é inativar. */
    const vinc = vinculosDe(collection, id);
    if (vinc.length) {
      const lista = vinc.map(v => `${v.qtd} ${v.rotulo}`).join(', ');
      return send(res, 409, {
        error: `Este cadastro está em uso: ${lista}. Excluir deixaria esses registros sem referência — ` +
               (INATIVAVEIS[collection]
                 ? 'use "Inativar" para tirá-lo das listas sem perder o histórico.'
                 : 'não é possível excluí-lo enquanto houver vínculos.'),
        vinculos: vinc, podeInativar: !!INATIVAVEIS[collection]
      });
    }
    db.remove(collection, id);
    audit(user, 'excluiu', collection, Number(id),
      cfg.label + ' #' + id + (rec.nome ? ': ' + rec.nome : ''));
    return ok(res, { ok: true });
  }
  notFound(res);
}

/* ===================================================================== */
/* Servidor                                                              */
/* ===================================================================== */

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.json': 'application/json'
};

function serveStatic(req, res, urlPath) {
  let p = urlPath === '/' ? '/index.html' : urlPath;
  p = path.normalize(p).replace(/^(\.\.[/\\])+/, '');
  const file = path.join(PUBLIC_DIR, p);
  if (!file.startsWith(PUBLIC_DIR)) return notFound(res);
  fs.readFile(file, (err, data) => {
    if (err) {
      // SPA: qualquer rota desconhecida devolve o index.
      if (!path.extname(p)) {
        return fs.readFile(path.join(PUBLIC_DIR, 'index.html'), (e2, d2) => {
          if (e2) return notFound(res);
          res.writeHead(200, { 'Content-Type': MIME['.html'], 'Cache-Control': 'no-cache' });
          res.end(d2);
        });
      }
      return notFound(res);
    }
    // no-cache: após uma atualização do sistema, o navegador sempre busca a
    // versão nova dos arquivos (evita tela antiga presa no cache).
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, 'http://x');
  const urlPath = decodeURIComponent(u.pathname);
  const query = Object.fromEntries(u.searchParams.entries());

  // Proteções básicas de navegador, que passam a valer quando o sistema fica
  // acessível pela internet: nada de adivinhar tipo de arquivo, nada de abrir
  // o sistema dentro de um site de terceiros, e o endereço interno não vaza
  // no cabeçalho de origem ao clicar num link para fora.
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'same-origin');

  try {
    /* A Conta Azul devolve o usuário no endereço cadastrado no portal dela,
       que nem sempre é o caminho padrão daqui. Atendemos no caminho que
       estiver configurado, seja ele qual for. */
    if (req.method === 'GET' && !urlPath.startsWith('/api/')) {
      const retorno = contaazul.caminhoRetorno();
      if (retorno && retorno !== '/' && urlPath === retorno) {
        return await contaazulRetorno(req, res, query);
      }
    }
    if (!urlPath.startsWith('/api/')) return serveStatic(req, res, urlPath);

    // Rotas especiais primeiro.
    for (const r of routes) {
      if (r.method !== req.method) continue;
      const m = urlPath.match(r.regex);
      if (!m) continue;
      let user = null;
      if (r.perm !== null) {
        user = authUser(req);
        if (!user) return send(res, 401, { error: 'Sessão expirada — faça login novamente' });
        // Uma lista de permissões vale como "qualquer uma serve": a agenda
        // financeira abre para quem enxerga contas a pagar OU a receber.
        const liberado = Array.isArray(r.perm) ? r.perm.some(x => can(user, x)) : can(user, r.perm);
        if (!liberado) return forbidden(res);
      }
      return await r.handler(req, res, user, m.groups || {}, query);
    }

    // CRUD genérico: /api/<collection>[/<id>]
    const parts = urlPath.split('/').filter(Boolean); // ['api', collection, id?]
    if (parts.length >= 2 && REST[parts[1]]) {
      const user = authUser(req);
      if (!user) return send(res, 401, { error: 'Sessão expirada — faça login novamente' });
      return await handleRest(req, res, user, parts[1], parts[2]);
    }

    notFound(res);
  } catch (e) {
    console.error(req.method, urlPath, e);
    send(res, 500, { error: 'Erro interno: ' + e.message });
  }
});

/* ===================================================================== */
/* Backup automático (local + pasta de nuvem sincronizada)               */
/* ===================================================================== */
/* Uma cópia de data/db.json por dia em data/backups/, mantendo as 30    */
/* últimas. Se uma pasta de nuvem estiver configurada (Google Drive para */
/* Computador, OneDrive, Dropbox…), a cópia diária também vai para lá —  */
/* o aplicativo de sincronização sobe o arquivo para a nuvem sozinho.    */
/* Roda no start e é reavaliado a cada 6 horas.                          */

/* ===================================================================== */
/* Reconciliação: produção e financeiro do que já estava no sistema      */
/* ===================================================================== */
/**
 * Vendas e OS cadastradas antes desta versão não tinham ordem de produção
 * nem conta a receber automática. Esta rotina identifica o que ficou para
 * trás e completa — sempre conferindo antes, para nunca duplicar.
 */
function reconciliarProducaoEFinanceiro(user) {
  const quem = user || { id: 0, name: 'Sistema' };
  const out = { checklistsAtualizados: 0, producaoVendas: 0, producaoServicos: 0, receberServicos: 0 };

  // 1. Checklists antigos (lista simples) ganham as etapas.
  for (const p of db.all('productionOrders')) {
    if ((p.checklist || []).some(c => !c.etapa)) {
      db.update('productionOrders', p.id, { checklist: domain.migrarChecklist(p.checklist) });
      out.checklistsAtualizados++;
    }
    if (!p.origem) db.update('productionOrders', p.id, { origem: p.osId ? 'servico' : 'venda' });
  }

  // 2. Vendas de cabeçote sem ordem de produção.
  for (const sale of db.all('sales')) {
    if (sale.status === 'cancelado' || sale.status === 'cancelada') continue;
    const cabecotes = (sale.itens || []).filter(i => i.kind !== 'peca');
    if (!cabecotes.length) continue;
    if (db.all('productionOrders').some(p => p.saleId === sale.id)) continue;
    const cliente = db.get('clients', sale.clienteId);
    if (!cliente) continue;
    gerarProducaoDaVenda(sale, cliente, quem);
    out.producaoVendas += cabecotes.reduce((s, i) => s + (Number(i.qtd) || 1), 0);
  }

  // 3. Ordens de serviço em andamento sem ordem de produção.
  for (const os of db.all('serviceOrders')) {
    if (osCancelada(os)) continue;
    if (db.all('productionOrders').some(p => p.osId === os.id)) continue;
    if (gerarProducaoDaOS(os, quem)) out.producaoServicos++;
  }

  // 4. Serviços com valor a receber que nunca chegaram ao financeiro.
  for (const os of db.all('serviceOrders')) {
    if (osCancelada(os)) continue;
    if (!(Number(os.valorTotal) > 0)) continue;
    if (os.pagamentoStatus === 'pago') continue;
    // Já tem cobrança ou dinheiro registrado? Então não se mexe.
    const temReceber = db.all('receivables').some(r => r.refType === 'serviceOrders' && r.refId === os.id);
    const temCaixa = db.all('cashflow').some(c => c.refType === 'serviceOrders' && c.refId === os.id);
    if (temReceber || temCaixa) continue;
    const r = gerarFinanceiroDaOS(os, quem, {
      forma: (os.pagamento || {}).forma,
      condicao: (os.pagamento || {}).condicao,
      parcelas: (os.pagamento || {}).parcelas,
      intervaloDias: (os.pagamento || {}).intervaloDias,
      primeiroVencimento: primeiroVencimentoVigente(os)
    });
    if (r.criadas) out.receberServicos += r.criadas;
  }

  db.save();
  return out;
}

/* Roda uma vez sozinha ao subir a versão nova; depois é só pelo botão. */
function reconciliacaoInicial() {
  // Códigos de cliente: conferido em toda subida, porque um backup restaurado
  // pode trazer cadastros de uma versão que ainda não os tinha.
  try {
    const n = garantirCodigosDeCliente();
    if (n) console.log(`Código interno atribuído a ${n} cliente(s).`);
  } catch (e) {
    console.error('Falha ao gerar códigos de cliente:', e.message);
  }
  if (db.settings.reconciliacaoProducaoV1) return;
  try {
    const r = reconciliarProducaoEFinanceiro();
    db.settings.reconciliacaoProducaoV1 = { at: new Date().toISOString(), resultado: r };
    db.save();
    const total = r.producaoVendas + r.producaoServicos + r.receberServicos;
    if (total || r.checklistsAtualizados) {
      console.log('Reconciliação inicial:', JSON.stringify(r));
    }
  } catch (e) {
    console.error('Falha na reconciliação inicial:', e.message);
  }
}

/* =====================================================================
   AUDITORIA: entradas de venda lançadas em dobro no Fluxo de caixa
   ---------------------------------------------------------------------
   Houve um período em que cadastrar uma venda em Pix ou dinheiro "à vista"
   lançava sozinha o valor cheio no Fluxo de caixa (descrição "Venda à
   vista") e criava um recebível já quitado. Quem depois fazia o caminho
   certo — Registrar recebimento → entrada de saldo — via o MESMO dinheiro
   entrar uma segunda vez. O caixa ficava inflado.

   A regra já foi corrigida: venda nenhuma lança dinheiro no caixa. Esta
   auditoria existe para acertar o que ficou gravado antes disso.

   Ela NÃO altera nada. Identifica as entradas automáticas pela assinatura
   exata que o código antigo gravava — entrada + refType 'sales' +
   descrição "Venda à vista", que nenhuma outra rotina escreve — e separa:

     duplicada    a venda TAMBÉM tem recebimento registrado à mão. O
                  dinheiro entrou uma vez e está no caixa duas vezes: a
                  entrada automática é indevida e deve sair.

     semRegistro  a venda não tem recebimento registrado. O dinheiro
                  provavelmente entrou de verdade (venda em dinheiro ou
                  Pix), só nunca passou pelo caminho certo. Aqui não se
                  apaga nada: a entrada é CONVERTIDA em recebimento
                  registrado, passando a contar uma vez só.

   Nada é classificado por "dois valores iguais": a separação vem da
   origem de cada lançamento e do vínculo com o mesmo pedido.              */

const MARCA_VENDA_AUTOMATICA = 'Venda à vista';
const c2 = v => Math.round((Number(v) || 0) * 100) / 100;

/** Recebíveis "espelho": registros que repetem dinheiro contado em outro
    lugar e por isso inflam o "já recebido" nas telas. */
function espelhosDeRecebivel() {
  return db.all('receivables').filter(r =>
    (r.refType === 'sales' || r.refType === 'serviceOrders') && r.status === 'paga' &&
    (r.auto === true || r.origem === 'saldo'));
}

function auditarDuplicidadeVendas() {
  const automaticas = db.all('cashflow').filter(c =>
    c.tipo === 'entrada' && c.refType === 'sales' && c.descricao === MARCA_VENDA_AUTOMATICA);

  const casos = automaticas.map(c => {
    const sale = c.refId ? db.get('sales', c.refId) : null;
    const cliente = sale && sale.clienteId ? db.get('clients', sale.clienteId) : null;
    const pg = (sale && sale.pagamento) || {};
    const recebimentos = (sale && sale.recebimentos) || [];
    const outrasEntradas = db.all('cashflow').filter(x =>
      x.tipo === 'entrada' && x.refType === 'sales' && x.refId === c.refId && x.id !== c.id);
    return {
      cashflowId: c.id,
      tipo: recebimentos.length ? 'duplicada' : 'semRegistro',
      data: c.data, mes: String(c.data || '').slice(0, 7), valor: c2(c.valor),
      conta: c.conta || '', categoria: c.categoria || '', origemTexto: c.origem || '',
      vendaId: c.refId, vendaExiste: !!sale,
      pedido: sale ? sale.numero : null,
      clienteId: cliente ? cliente.id : null,
      cliente: cliente ? cliente.nome : (sale ? '(cliente removido)' : '(venda removida)'),
      valorVenda: sale ? c2(sale.valorTotal) : null,
      dataVenda: sale ? sale.dataPedido : null,
      formaPagamento: pg.forma || '', condicao: pg.condicao || '',
      recebimentosManuais: recebimentos.map(r => ({ data: r.data, valor: c2(r.valor), forma: r.forma || '' })),
      recebidoManual: c2(recebimentos.reduce((s, r) => s + (Number(r.valor) || 0), 0)),
      outrasEntradasCaixa: outrasEntradas.map(x => ({
        id: x.id, data: x.data, valor: c2(x.valor), descricao: x.descricao || ''
      })),
      totalNoCaixa: c2(c2(c.valor) + outrasEntradas.reduce((s, x) => s + (Number(x.valor) || 0), 0))
    };
  }).sort((a, b) => String(a.data || '').localeCompare(String(b.data || '')) || a.cashflowId - b.cashflowId);

  const duplicadas = casos.filter(x => x.tipo === 'duplicada');
  const semRegistro = casos.filter(x => x.tipo === 'semRegistro');

  /* Quanto o caixa foi inflado em cada mês — só o que está comprovadamente
     em dobro entra nesta conta. */
  const porMes = {};
  for (const x of duplicadas) {
    const m = porMes[x.mes] = porMes[x.mes] || { mes: x.mes, quantidade: 0, valorInflado: 0, pedidos: [] };
    m.quantidade++;
    m.valorInflado = c2(m.valorInflado + x.valor);
    if (x.pedido && !m.pedidos.includes(x.pedido)) m.pedidos.push(x.pedido);
  }
  const meses = Object.values(porMes).sort((a, b) => a.mes.localeCompare(b.mes));

  /* Recebíveis espelho: não são dinheiro, mas fazem a tela do título somar
     o mesmo valor outra vez e mostrar "saldo a devolver ao cliente". */
  const espelhos = espelhosDeRecebivel().map(r => {
    const fonte = r.refType === 'sales' ? db.get('sales', r.refId) : db.get('serviceOrders', r.refId);
    const cliente = r.clienteId ? db.get('clients', r.clienteId) : null;
    return {
      recebivelId: r.id, refType: r.refType, refId: r.refId,
      rotulo: r.refType === 'sales' ? `Pedido nº ${fonte ? fonte.numero : '?'}` : `OS nº ${fonte ? fonte.numero : '?'}`,
      cliente: cliente ? cliente.nome : '', descricao: r.descricao || '',
      valor: c2(r.valor), motivo: r.auto ? 'baixa automática da venda/OS' : 'linha de saldo marcada como paga',
      recebimentosNaOrigem: ((fonte && fonte.recebimentos) || []).length
    };
  });

  /* Serviços com entrada "à vista" E recebimentos registrados: aqui a
     entrada no caixa foi pedida por quem marcou a caixinha, então o sistema
     não decide nada — só mostra para conferência. */
  const osConferir = [];
  for (const os of db.all('serviceOrders')) {
    const aVista = db.all('cashflow').filter(c =>
      c.tipo === 'entrada' && c.refType === 'serviceOrders' && c.refId === os.id &&
      c.descricao === 'Pagamento de serviço');
    if (!aVista.length) continue;
    const recebimentos = (os.recebimentos || []);
    const todas = db.all('cashflow').filter(c =>
      c.tipo === 'entrada' && c.refType === 'serviceOrders' && c.refId === os.id);
    const somaCaixa = c2(todas.reduce((s, c) => s + (Number(c.valor) || 0), 0));
    if (somaCaixa <= c2(os.valorTotal) + 0.005) continue; // não há excesso
    const cliente = os.clienteId ? db.get('clients', os.clienteId) : null;
    osConferir.push({
      osId: os.id, numero: os.numero, cliente: cliente ? cliente.nome : '',
      valorOS: c2(os.valorTotal), somaNoCaixa: somaCaixa,
      excedente: c2(somaCaixa - c2(os.valorTotal)),
      entradas: todas.map(c => ({ id: c.id, data: c.data, valor: c2(c.valor), descricao: c.descricao || '' })),
      recebimentosRegistrados: recebimentos.length
    });
  }

  const entradasTotais = db.all('cashflow').filter(c => c.tipo === 'entrada');
  return {
    geradoEm: new Date().toISOString(),
    vendasAnalisadas: db.all('sales').length,
    entradasDeCaixaAnalisadas: entradasTotais.length,
    lancamentosAutomaticosEncontrados: casos.length,
    duplicadas, semRegistro, meses, espelhos, osConferir,
    totais: {
      duplicadas: duplicadas.length,
      valorDuplicado: c2(duplicadas.reduce((s, x) => s + x.valor, 0)),
      semRegistro: semRegistro.length,
      valorSemRegistro: c2(semRegistro.reduce((s, x) => s + x.valor, 0)),
      espelhos: espelhos.length,
      osConferir: osConferir.length
    }
  };
}

/* =====================================================================
   AUDITORIA: vínculo entre Vendas, Recebimentos e Contas a receber
   ---------------------------------------------------------------------
   Contas a receber mostra UMA linha por venda sem plano de parcelas, com o
   valor do pedido, quanto já entrou e a situação. Numa versão anterior essa
   linha era um "saldo em aberto" que encolhia a cada recebimento e era
   APAGADA quando a venda ficava quitada — então venda recebida em Vendas
   parecia não existir em Contas a receber, e venda recebida em parte
   mostrava só o resto, sem o total nem o recebido.

   Esta auditoria confere cada venda contra o que Contas a receber mostra e
   NÃO altera nada. A correção reconstrói a linha a partir do que já está
   registrado na venda: não cria recebimento, não lança caixa, não encosta
   em parcela com dinheiro dentro.                                         */

function auditarVinculoVendas() {
  const vendas = db.all('sales');
  const corrigir = [], conferir = [], certas = [];
  let recebimentosExistentes = 0;

  for (const sale of vendas) {
    const recebimentos = sale.recebimentos || [];
    recebimentosExistentes += recebimentos.length;
    const cliente = sale.clienteId ? db.get('clients', sale.clienteId) : null;
    const { total, recebido, saldo } = resumoFinanceiroVenda(sale);
    const parcelas = parcelasDaVenda(sale.id);
    const comPlano = vendaComPlano(sale.id);
    const espelho = db.all('receivables').find(r =>
      r.refType === 'sales' && r.refId === sale.id && ehEspelhoDaVenda(r));
    const espelhos = db.all('receivables').filter(r =>
      r.refType === 'sales' && r.refId === sale.id && ehEspelhoDaVenda(r));
    const cancelada = sale.status === 'cancelado' || sale.status === 'cancelada';

    const base = {
      vendaId: sale.id, pedido: sale.numero, dataVenda: sale.dataPedido,
      cliente: cliente ? cliente.nome : '(cliente removido)',
      clienteCodigo: cliente ? (cliente.codigo || '') : '',
      formaPagamento: (sale.pagamento || {}).forma || '',
      condicao: (sale.pagamento || {}).condicao || '',
      valorVenda: total, recebido, saldo,
      recebimentos: recebimentos.map(r => ({
        recId: r.recId || null, data: r.data, valor: c2(r.valor), forma: r.forma || ''
      })),
      comPlano, parcelas: parcelas.length,
      situacaoEsperada: cancelada ? 'cancelada'
        : saldo <= 0.005 && total > 0 ? 'paga' : recebido > 0.005 ? 'parcial' : 'aberto',
      emContasAReceber: espelho ? {
        recebivelId: espelho.id, valor: c2(espelho.valor), recebido: c2(espelho.recebido),
        status: espelho.status, descricao: espelho.descricao || ''
      } : null
    };

    /* Caso que pede olho humano: a venda tem plano de parcelas E recebimento
       lançado direto no pedido. São dois controles do mesmo dinheiro e o
       sistema não tem como saber qual parcela aquele dinheiro quitou. */
    if (comPlano && recebimentos.length) {
      conferir.push(Object.assign({}, base, {
        motivo: 'A venda tem plano de parcelas E recebimento lançado direto no pedido. ' +
          'Dá para somar o total, mas não dá para saber qual parcela cada recebimento quitou — ' +
          'confira e, se for o caso, estorne o recebimento do pedido e dê a baixa na parcela.'
      }));
      continue;
    }
    if (comPlano) { certas.push(base); continue; }

    const problemas = [];
    if (espelhos.length > 1) problemas.push(`${espelhos.length} linhas para o mesmo pedido em Contas a receber`);
    if (!espelho) {
      problemas.push(recebimentos.length
        ? 'a venda tem recebimento registrado mas não aparece em Contas a receber'
        : 'a venda não tem linha em Contas a receber');
    } else {
      if (Math.abs(c2(espelho.valor) - total) > 0.005) {
        problemas.push(`valor mostrado ${brl(espelho.valor)} ≠ valor do pedido ${brl(total)}`);
      }
      if (Math.abs(c2(espelho.recebido) - recebido) > 0.005) {
        problemas.push(`recebido mostrado ${brl(espelho.recebido || 0)} ≠ recebido real ${brl(recebido)}`);
      }
      const st = espelho.status === 'vencida' ? 'aberto' : espelho.status;
      if (st !== base.situacaoEsperada) {
        problemas.push(`situação "${st}" deveria ser "${base.situacaoEsperada}"`);
      }
    }
    if (problemas.length) corrigir.push(Object.assign({}, base, { problemas }));
    else certas.push(base);
  }

  /* Linhas de Contas a receber apontando para venda que não existe mais. */
  const orfas = db.all('receivables')
    .filter(r => r.refType === 'sales' && r.refId && !db.get('sales', r.refId))
    .map(r => ({
      recebivelId: r.id, descricao: r.descricao || '', valor: c2(r.valor),
      recebido: recebidoDaParcela(r), status: r.status,
      temCaixa: db.all('cashflow').some(c => c.refType === 'receivables' && c.refId === r.id)
    }));

  /* Entradas de caixa de recebimento de venda sem o pedido correspondente. */
  const caixaOrfa = db.all('cashflow')
    .filter(c => c.tipo === 'entrada' && c.refType === 'sales' && c.refId && !db.get('sales', c.refId))
    .map(c => ({ cashflowId: c.id, data: c.data, valor: c2(c.valor), descricao: c.descricao || '' }));

  /* Recebimento de venda com mais de uma entrada de caixa ligada ao mesmo
     identificador — duplicidade financeira de verdade, tratada à parte. */
  const duplicadas = [];
  for (const sale of vendas) {
    const porRec = {};
    for (const c of db.all('cashflow').filter(c =>
      c.tipo === 'entrada' && c.refType === 'sales' && c.refId === sale.id && c.recebimentoId)) {
      (porRec[c.recebimentoId] = porRec[c.recebimentoId] || []).push(c);
    }
    for (const [rid, lista] of Object.entries(porRec)) {
      if (lista.length > 1) {
        duplicadas.push({
          vendaId: sale.id, pedido: sale.numero, recebimentoId: Number(rid),
          entradas: lista.map(c => ({ id: c.id, data: c.data, valor: c2(c.valor) }))
        });
      }
    }
    // O caixa da venda não pode passar do que está registrado como recebido.
    const somaCaixa = c2(db.all('cashflow').filter(c =>
      c.tipo === 'entrada' && c.refType === 'sales' && c.refId === sale.id)
      .reduce((s, c) => s + (Number(c.valor) || 0), 0));
    const somaRecebida = c2((sale.recebimentos || []).reduce((s, r) => s + (Number(r.valor) || 0), 0));
    if (somaCaixa - somaRecebida > 0.005) {
      duplicadas.push({
        vendaId: sale.id, pedido: sale.numero, recebimentoId: null,
        excedente: c2(somaCaixa - somaRecebida), somaCaixa, somaRecebida,
        entradas: db.all('cashflow').filter(c =>
          c.tipo === 'entrada' && c.refType === 'sales' && c.refId === sale.id)
          .map(c => ({ id: c.id, data: c.data, valor: c2(c.valor), descricao: c.descricao || '' }))
      });
    }
  }

  const soma = (lista, campo) => c2(lista.reduce((s, x) => s + (Number(x[campo]) || 0), 0));
  return {
    geradoEm: new Date().toISOString(),
    vendasAnalisadas: vendas.length,
    recebimentosExistentes,
    totais: {
      corrigir: corrigir.length,
      comRecebimentoForaDeContasAReceber: corrigir.filter(x => x.recebido > 0.005).length,
      valorRecebidoAConciliar: soma(corrigir.filter(x => x.recebido > 0.005), 'recebido'),
      valorAConciliar: soma(corrigir, 'valorVenda'),
      conferirManual: conferir.length,
      certas: certas.length,
      orfas: orfas.length,
      caixaOrfa: caixaOrfa.length,
      duplicidadesFinanceiras: duplicadas.length
    },
    corrigir, conferir, orfas, caixaOrfa, duplicadas
  };
}

route('GET', '/api/auditoria/vinculo-vendas', ['cashflow_edit', 'admin'], async (req, res) => {
  ok(res, auditarVinculoVendas());
});

/**
 * Religa o histórico: reconstrói a linha de Contas a receber de cada venda
 * escolhida a partir do que já está registrado nela.
 *
 * Não cria recebimento. Não lança nada no Fluxo de caixa. Não encosta em
 * parcela com dinheiro dentro. Só põe a linha da venda em dia com os
 * recebimentos que já existem — que é o que estava faltando.
 */
route('POST', '/api/auditoria/vinculo-vendas/corrigir', ['cashflow_edit', 'admin'], async (req, res, user) => {
  const b = await readBody(req);
  const vendas = (Array.isArray(b.vendas) ? b.vendas : []).map(Number).filter(Boolean);
  const orfas = (Array.isArray(b.orfas) ? b.orfas : []).map(Number).filter(Boolean);
  if (!vendas.length && !orfas.length) return bad(res, 'Nenhuma venda selecionada para religar.');
  if (String(req.headers['x-confirmar'] || '').toLowerCase() !== 'sim') {
    return send(res, 409, {
      error: `Confirma religar ${vendas.length} venda(s)` +
             (orfas.length ? ` e remover ${orfas.length} linha(s) órfã(s)` : '') +
             '? Contas a receber passa a mostrar o valor do pedido, ' +
             'o que já foi recebido e a situação. Nenhum recebimento é criado e o Fluxo de caixa não é tocado.',
      precisaConfirmar: true
    });
  }

  let copia = '';
  try {
    db.persistNow();
    const dir = path.join(db.DATA_DIR, 'backups');
    fs.mkdirSync(dir, { recursive: true });
    copia = path.join(dir, `antes-religar-vendas-${new Date().toISOString().replace(/[:.]/g, '-')}.json`);
    fs.copyFileSync(db.DB_FILE, copia);
  } catch (e) { return bad(res, 'Não foi possível gravar a cópia de segurança: ' + e.message); }

  const caixaAntes = c2(db.all('cashflow').reduce((s, c) =>
    s + (c.tipo === 'entrada' ? (Number(c.valor) || 0) : -(Number(c.valor) || 0)), 0));
  const feito = { religadas: [], ignoradas: [] };

  for (const id of vendas) {
    const sale = db.get('sales', id);
    if (!sale) { feito.ignoradas.push({ vendaId: id, motivo: 'a venda não existe mais' }); continue; }
    if (vendaComPlano(sale.id) && (sale.recebimentos || []).length) {
      feito.ignoradas.push({ vendaId: id, pedido: sale.numero,
        motivo: 'tem plano de parcelas e recebimento no pedido — precisa de revisão manual' });
      continue;
    }
    /* Tira a cobrança antiga em aberto que sobrou de versões anteriores e
       põe a linha da venda em dia. Parcela com recebimento não é tocada. */
    const saldo = reequilibrarReceberDaVenda(sale, {});
    const resumo = resumoFinanceiroVenda(sale);
    const linha = db.all('receivables').find(r =>
      r.refType === 'sales' && r.refId === sale.id && ehEspelhoDaVenda(r));
    feito.religadas.push({
      vendaId: sale.id, pedido: sale.numero,
      valorVenda: resumo.total, recebido: resumo.recebido, saldo,
      situacao: linha ? linha.status : (vendaComPlano(sale.id) ? 'parcelas' : '—'),
      recebivelId: linha ? linha.id : null
    });
    audit(user, 'religou', 'receivables', linha ? linha.id : 0,
      `Pedido nº ${sale.numero} religado em Contas a receber — valor ${brl(resumo.total)}, ` +
      `recebido ${brl(resumo.recebido)}, saldo ${brl(saldo)}` +
      `${linha ? ` (situação: ${linha.status})` : ''}; nenhum recebimento criado, caixa intacto`);
  }

  /* Linhas apontando para venda que não existe mais. Só sai a que não tem
     entrada de caixa ligada — com dinheiro dentro, fica para revisão. */
  feito.orfasRemovidas = []; feito.orfasMantidas = [];
  for (const id of orfas) {
    const r = db.get('receivables', id);
    if (!r || r.refType !== 'sales' || db.get('sales', r.refId)) {
      feito.ignoradas.push({ recebivelId: id, motivo: 'não é uma linha órfã' });
      continue;
    }
    const caixa = db.all('cashflow').filter(c => c.refType === 'receivables' && c.refId === r.id);
    if (caixa.length) {
      feito.orfasMantidas.push({ recebivelId: id, descricao: r.descricao || '', entradas: caixa.length });
      continue;
    }
    db.remove('receivables', r.id);
    feito.orfasRemovidas.push({ recebivelId: id, descricao: r.descricao || '', valor: c2(r.valor) });
    audit(user, 'corrigiu', 'receivables', id,
      `Linha órfã removida de Contas a receber: "${r.descricao || ''}" (${brl(r.valor)}) — ` +
      'a venda não existe mais e não havia entrada de caixa ligada');
  }

  const caixaDepois = c2(db.all('cashflow').reduce((s, c) =>
    s + (c.tipo === 'entrada' ? (Number(c.valor) || 0) : -(Number(c.valor) || 0)), 0));
  db.persistNow();
  audit(user, 'auditoria', 'receivables', 0,
    `Religação de Contas a receber: ${feito.religadas.length} venda(s) religada(s), ` +
    `${feito.orfasRemovidas.length} órfã(s) removida(s), ${feito.ignoradas.length} ignorada(s). ` +
    `Saldo do caixa antes ${brl(caixaAntes)} / depois ${brl(caixaDepois)}. ` +
    `Cópia: ${copia}`);

  ok(res, Object.assign(feito, {
    copiaDeSeguranca: copia,
    caixaAntes, caixaDepois, caixaIntacto: Math.abs(caixaAntes - caixaDepois) < 0.005,
    auditoria: auditarVinculoVendas()
  }));
});

/* Só leitura: é o relatório para conferir ANTES de corrigir nada. */
route('GET', '/api/auditoria/vendas-duplicadas', ['cashflow_edit', 'admin'], async (req, res) => {
  ok(res, auditarDuplicidadeVendas());
});

/**
 * Aplica a correção — e só no que vier listado no pedido, nunca "tudo".
 *
 *   remover:   ids de lançamento de caixa (entrada automática comprovadamente
 *              em dobro) que saem do Fluxo de caixa.
 *   converter: ids de lançamento de caixa que FICAM no caixa, mas passam a
 *              ser um recebimento registrado na venda — o dinheiro entrou,
 *              só não estava no lugar certo.
 *   espelhos:  ids de recebível espelho a retirar de Contas a receber.
 *
 * Antes de mexer em qualquer coisa, grava uma cópia do banco. Nenhuma venda,
 * cliente ou recebimento real é apagado em momento nenhum.
 */
route('POST', '/api/auditoria/vendas-duplicadas/corrigir', ['cashflow_edit', 'admin'], async (req, res, user) => {
  const b = await readBody(req);
  const remover = (Array.isArray(b.remover) ? b.remover : []).map(Number).filter(Boolean);
  const converter = (Array.isArray(b.converter) ? b.converter : []).map(Number).filter(Boolean);
  const espelhos = (Array.isArray(b.espelhos) ? b.espelhos : []).map(Number).filter(Boolean);
  if (!remover.length && !converter.length && !espelhos.length) {
    return bad(res, 'Nada selecionado para corrigir.');
  }
  if (String(req.headers['x-confirmar'] || '').toLowerCase() !== 'sim') {
    return send(res, 409, {
      error: `Confirma a correção? ${remover.length} entrada(s) sairão do Fluxo de caixa, ` +
             `${converter.length} serão convertidas em recebimento registrado e ` +
             `${espelhos.length} recebível(is) espelho sairão de Contas a receber. ` +
             'Uma cópia do banco é gravada antes.',
      precisaConfirmar: true
    });
  }

  // Cópia de segurança antes de tocar em dinheiro.
  let copia = '';
  try {
    db.persistNow();
    const dir = path.join(db.DATA_DIR, 'backups');
    fs.mkdirSync(dir, { recursive: true });
    copia = path.join(dir, `antes-correcao-duplicidade-${new Date().toISOString().replace(/[:.]/g, '-')}.json`);
    fs.copyFileSync(db.DB_FILE, copia);
  } catch (e) { return bad(res, 'Não foi possível gravar a cópia de segurança: ' + e.message); }

  const feito = { removidas: [], convertidas: [], espelhosRemovidos: [], ignorados: [] };
  const vendasTocadas = new Set();

  /* 1. Entradas automáticas em dobro: saem do caixa. */
  for (const id of remover) {
    const c = db.get('cashflow', id);
    if (!c || c.descricao !== MARCA_VENDA_AUTOMATICA || c.refType !== 'sales') {
      feito.ignorados.push({ cashflowId: id, motivo: 'não é um lançamento automático de venda' });
      continue;
    }
    const sale = c.refId ? db.get('sales', c.refId) : null;
    db.remove('cashflow', c.id);
    if (sale) vendasTocadas.add(sale.id);
    feito.removidas.push({ cashflowId: id, data: c.data, valor: c2(c.valor), pedido: sale ? sale.numero : null });
    audit(user, 'corrigiu', 'cashflow', id,
      `Auditoria de duplicidade: entrada automática de ${brl(c.valor)} em ${dataBR(c.data)} ` +
      `${sale ? `do pedido nº ${sale.numero} ` : ''}retirada do Fluxo de caixa — o recebimento real registrado foi mantido`);
  }

  /* 2. Entradas automáticas sem recebimento registrado: viram recebimento. */
  for (const id of converter) {
    const c = db.get('cashflow', id);
    if (!c || c.descricao !== MARCA_VENDA_AUTOMATICA || c.refType !== 'sales') {
      feito.ignorados.push({ cashflowId: id, motivo: 'não é um lançamento automático de venda' });
      continue;
    }
    const sale = c.refId ? db.get('sales', c.refId) : null;
    if (!sale) {
      feito.ignorados.push({ cashflowId: id, motivo: 'a venda não existe mais' });
      continue;
    }
    const valor = c2(c.valor);
    db.update('sales', sale.id, {
      recebimentos: (sale.recebimentos || []).concat([{
        valor, data: c.data, forma: (sale.pagamento || {}).forma || 'pix',
        obs: 'Regularizado pela auditoria de duplicidade (entrada que a venda já havia lançado)',
        por: user.name
      }])
    });
    db.update('cashflow', c.id, { descricao: `Recebimento (${(sale.pagamento || {}).forma || 'à vista'})` });
    vendasTocadas.add(sale.id);
    feito.convertidas.push({ cashflowId: id, data: c.data, valor, pedido: sale.numero });
    audit(user, 'corrigiu', 'cashflow', id,
      `Auditoria de duplicidade: entrada de ${brl(valor)} em ${dataBR(c.data)} do pedido nº ${sale.numero} ` +
      'passou a ser um recebimento registrado na venda — valor mantido no Fluxo de caixa, agora contado uma vez só');
  }

  /* 3. Recebíveis espelho: saem de Contas a receber. */
  for (const id of espelhos) {
    const r = db.get('receivables', id);
    if (!r || r.status !== 'paga' || !(r.auto === true || r.origem === 'saldo')) {
      feito.ignorados.push({ recebivelId: id, motivo: 'não é um recebível espelho' });
      continue;
    }
    db.remove('receivables', r.id);
    if (r.refType === 'sales') vendasTocadas.add(r.refId);
    feito.espelhosRemovidos.push({ recebivelId: id, descricao: r.descricao || '', valor: c2(r.valor) });
    audit(user, 'corrigiu', 'receivables', id,
      `Auditoria de duplicidade: "${r.descricao || 'recebível'}" (${brl(r.valor)}) retirado de Contas a receber — ` +
      'repetia dinheiro já registrado no recebimento da origem');
  }

  /* 4. Contas a receber de cada venda tocada volta a mostrar o que falta. */
  for (const vendaId of vendasTocadas) {
    const sale = db.get('sales', vendaId);
    if (sale) ajustarSaldoDaVenda(sale, {});
  }

  db.persistNow();
  audit(user, 'auditoria', 'cashflow', 0,
    `Correção de duplicidade aplicada: ${feito.removidas.length} entrada(s) retirada(s) ` +
    `(${brl(feito.removidas.reduce((s, x) => s + x.valor, 0))}), ${feito.convertidas.length} convertida(s), ` +
    `${feito.espelhosRemovidos.length} recebível(is) espelho removido(s). Cópia: ${copia}`);
  ok(res, Object.assign(feito, { copiaDeSeguranca: copia, auditoria: auditarDuplicidadeVendas() }));
});

route('POST', '/api/producao/reconciliar', 'admin', async (req, res, user) => {
  const r = reconciliarProducaoEFinanceiro(user);
  audit(user, 'reconciliou', 'productionOrders', 0,
    `Produção/financeiro reconciliados — ${r.producaoVendas} OP de venda, ${r.producaoServicos} OP de serviço, ${r.receberServicos} conta(s) a receber`);
  ok(res, r);
});

/** Pastas de nuvem que costumam existir no computador (só as que existem). */
function cloudCandidates() {
  const home = process.env.USERPROFILE || process.env.HOME || '';
  const list = [];
  if (process.env.OneDrive) list.push(process.env.OneDrive);
  for (const n of ['OneDrive', 'Google Drive', 'Meu Drive', 'My Drive', 'Dropbox']) {
    if (home) list.push(path.join(home, n));
  }
  for (const letra of ['G:', 'H:', 'I:']) {
    for (const n of ['Meu Drive', 'My Drive']) list.push(letra + path.sep + n);
  }
  return [...new Set(list)].filter(p => {
    try { return fs.statSync(p).isDirectory(); } catch (e) { return false; }
  });
}

/** Copia o banco para a pasta de nuvem configurada (1 arquivo por dia, 60 mantidos). */
function cloudBackup(force) {
  const dir = db.settings.backupDir;
  if (!dir) return { ok: false, naoConfigurado: true };
  const dataFile = db.DB_FILE;
  try {
    if (!fs.existsSync(dataFile)) return { ok: false, error: 'ainda não há dados para copiar' };
    fs.mkdirSync(dir, { recursive: true });
    const today = new Date().toISOString().slice(0, 10);
    const target = path.join(dir, `jaques-backup-${today}.json`);
    if (!force && fs.existsSync(target)) return { ok: true, file: target, jaExistia: true };
    db.persistNow();
    fs.copyFileSync(dataFile, target);
    const old = fs.readdirSync(dir).filter(f => /^jaques-backup-\d{4}-\d{2}-\d{2}\.json$/.test(f)).sort();
    while (old.length > 60) fs.unlinkSync(path.join(dir, old.shift()));
    db.settings.lastCloudBackup = { at: new Date().toISOString(), ok: true, file: target };
    db.save();
    console.log('Backup na nuvem:', target);
    return { ok: true, file: target };
  } catch (e) {
    db.settings.lastCloudBackup = { at: new Date().toISOString(), ok: false, error: e.message };
    db.save();
    console.error('Falha no backup na nuvem:', e.message);
    return { ok: false, error: e.message };
  }
}

function ensureDailyBackup() {
  try {
    const dataFile = db.DB_FILE;
    if (!fs.existsSync(dataFile)) return;
    const backupDir = path.join(db.DATA_DIR, 'backups');
    if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
    const today = new Date().toISOString().slice(0, 10);
    const target = path.join(backupDir, `db-${today}.json`);
    if (!fs.existsSync(target)) {
      db.persistNow();
      fs.copyFileSync(dataFile, target);
      console.log('Backup diário criado:', target);
    }
    const old = fs.readdirSync(backupDir).filter(f => /^db-\d{4}-\d{2}-\d{2}\.json$/.test(f)).sort();
    while (old.length > 30) fs.unlinkSync(path.join(backupDir, old.shift()));
  } catch (e) { console.error('Falha no backup diário:', e.message); }
  cloudBackup(false);
}
ensureDailyBackup();
setInterval(ensureDailyBackup, 6 * 3600 * 1000);
reconciliacaoInicial();

process.on('SIGINT', () => { db.persistNow(); process.exit(0); });
process.on('SIGTERM', () => { db.persistNow(); process.exit(0); });

/* Configurações dos cabeçotes e composição saem do código e vão para o
   cadastro — uma vez, na primeira subida desta versão. Roda aqui, depois de
   todas as tabelas de apoio existirem. */
const MIGRACAO_PRODUTOS = migrarProdutos();

server.listen(PORT, () => {
  console.log(`Jaques Motorsport — Sistema de Gestão rodando em http://localhost:${PORT}`);
  console.log('Login inicial: admin / admin123 (troque a senha no primeiro acesso)');
});
