# Jaques Motorsport — Sistema de Gestão Interno

Sistema de gestão personalizado para a operação de **cabeçotes de alta performance**:
venda de componentes, produção de cabeçotes sob encomenda e serviços de
preparação/retrabalho de cabeçotes de clientes.

Não é um ERP genérico — os fluxos, regras e telas foram desenhados para a
realidade da empresa, com o objetivo de eliminar planilhas paralelas.

## Como rodar

Requisitos: **Node.js 18+** (sem nenhuma dependência externa).

**Windows — fácil como abrir um HTML:** o pacote distribuído (ZIP) já traz o
Node.js embutido (`node.exe`) — nada precisa ser instalado. Extraia e dê dois
cliques em **`ABRIR O SISTEMA.bat`**: o sistema sobe invisível e o navegador
abre sozinho. Opcional: rodar **`INSTALAR.bat`** uma vez configura o início
automático com o Windows e cria o atalho “Sistema Jaques Motorsport” na Área
de Trabalho.

**Para atualizar (sem perder nenhum dado):**
1. dois cliques em **`PARAR O SISTEMA.bat`** (fecha o sistema que está rodando);
2. extraia o ZIP novo **por cima** da pasta atual, substituindo os arquivos —
   a pasta `data` (os dados da empresa) não vem no ZIP e fica intacta;
3. dois cliques em **`ABRIR O SISTEMA.bat`**. O navegador já busca sozinho a
   versão nova das telas.

Manualmente (qualquer sistema):

```bash
npm start          # ou: node server.js
```

Acesse **http://localhost:3000**.

> Login inicial: `admin` / `admin123` — troque a senha no primeiro acesso
> (menu lateral → 🔑 Alterar senha).

Os dados ficam em `data/db.json` (criado automaticamente, fora do controle de
versão), com backup diário automático em `data/backups/`. Para recomeçar do
zero: `npm run seed`.

**Backup na nuvem (Google Drive/OneDrive):** em *Administração → Configurações →
Backup na nuvem*, aponte uma pasta sincronizada (o sistema detecta as pastas do
Google Drive para Computador, OneDrive e Dropbox sozinho) — a cópia diária dos
dados também vai para lá e o aplicativo de sincronização sobe para a nuvem.
Para restaurar: copie o `jaques-backup-….json` mais recente para `data/db.json`
com o sistema parado.

> **Integrações:** a preparação para uma futura sincronização com a Conta Azul
> (sem duplicar registros) está descrita em **[INTEGRACOES.md](INTEGRACOES.md)**.

> **Para usar na empresa:** veja o guia completo de implantação em
> **[DEPLOY.md](DEPLOY.md)** — computador da oficina (rede local) ou servidor
> na nuvem com HTTPS, backup e checklist do primeiro dia.

## Módulos

| Área | O que faz |
|---|---|
| **Dashboard** | Faturamento, vendas e serviços do mês, lucro estimado e margem (restrito), contas a receber/pagar, saldo, vencidos, orçamentos aguardando, serviços em andamento, pedidos não entregues e **Minhas Pendências** |
| **Minhas pendências** | Central de tarefas por prioridade (Urgente / Esta semana / Aguardando) com **dono sugerido automaticamente** (tarefas sem dono ficam sinalizadas); modelos de título em um clique; contas recorrentes (COPEL, Sanepar, consórcio) geram aviso **alguns dias antes do vencimento** (configurável), com **link do site** para pagar e botão “Cadastrar boleto” que pré-preenche Contas a pagar — e a pendência **dá baixa sozinha** quando o boleto do mês é cadastrado |
| **Clientes** | Cadastro completo (cidade e estado separados para relatórios por região) + perfil consolidado: compras, serviços, orçamentos, financeiro e linha do tempo; **código interno automático** (`CLI-000001`) gerado no cadastro, único e imutável — acompanha o cliente mesmo se o nome mudar e aparece nas listas, nos seletores de cliente de vendas/serviços/orçamentos/financeiro e na busca, para que dois cadastros de nome parecido nunca se confundam (o CPF/CNPJ continua sendo do cliente, não da numeração da empresa) |
| **Entrada de cabeçotes** | Fluxo padrão *Entrada → Orçamento → Aprovação → OS → Produção → Finalização → Pagamento → NF de retorno → Envio*; entrada direta só como exceção marcada |
| **Bens de clientes** | Estoque de terceiros **totalmente separado** do estoque próprio; aceita entrada sem NF de remessa (marcada como “sem documento fiscal”); devolução dá saída do estoque de terceiros, nunca do estoque próprio |
| **Orçamentos** | Catálogo de serviços com preços-base do modelo atual (editáveis), valor personalizado por orçamento sem alterar o catálogo, cálculo automático de totais, validade padrão de 30 dias (configurável) |
| **Aprovação → OS** | Um clique converte o orçamento em OS aproveitando todos os dados, sem recadastro |
| **Ordens de serviço** | Status (Em análise, Em andamento, Aguardando peça, Finalizado, Aguardando pagamento, Cancelado) + envio/entrega, responsável, pagamento (à vista ou parcelado com boletos automáticos), NF de retorno, histórico |
| **Vendas** | 8 configurações (Unilateral/Fluxo Cruzado × Stage 1, 2, 3 e **3 Plus**); comandos e tuchos **saem do cadastro** em *Produtos e custos* e são validados na venda (S1: 288 e **280x280** · S2: 290x300, 290x290 · S3 e S3 Plus: 300x308, 300x318, 316x320, 316x316, 308x320 — **Stage 3 = tucho 35 mm, Stage 3 Plus = 37 mm**); cartão/link com taxa da operadora, valor líquido e data prevista de recebimento; custos adicionais por venda; resultado e margem. O detalhe do pedido mostra a **composição e as baixas de estoque** de cada cabeçote, com a situação de cada peça e o histórico da movimentação |
| **Produção** | Ordem de produção por cabeçote vendido com checklist automático (separações, montagem, controle, embalagem, expedição) incluindo operações extras: retrabalho dos dutos de escape (Stage 3) e abertura do alojamento para tucho 37 mm; baixa automática de componentes ao concluir. Filtro **“Todos em aberto”** com tudo que ainda pede trabalho — derivado do checklist, não de uma lista fixa de status: item sem marcar significa ordem aberta, e um status novo que represente trabalho pendente entra sozinho. Imprime a lista de trabalho da equipe (cliente, cabeçote/peça, o que fazer, qtd, previsão, etapa/status), **sem nenhum valor** |
| **Estoque próprio** | Cascos usinados (unilateral/crossflow), válvulas, molas, pratos, travas, tuchos 35/37, comandos; mínimos com alerta de compra; movimentações rastreadas. Lista única em **ordem alfabética**, com **busca** por nome, código ou categoria, filtros de categoria e de situação (ativos / abaixo do mínimo / inativos) e colunas ordenáveis (nome, quantidade, custo, valor em estoque) |
| **Compras** | Com ou sem NF (NF, recibo, comprovante, sem documento); **leitura automática de NF-e (XML)** com conferência antes de confirmar; vínculo a cliente/OS/pedido/produção/uso interno; gera contas a pagar (parceladas) automaticamente. Cada item pode ser **vinculado a um produto do Estoque próprio** (com sugestão pelo nome) e aí a quantidade **entra sozinha no estoque**, com fornecedor, NF, data e custo no histórico; item sem vínculo (serviço, manutenção, material consumido) não mexe no estoque. Editar ajusta pela **diferença** e salvar de novo não duplica. **Busca** por fornecedor, item, categoria, data, valor, forma de pagamento ou nº da nota, filtro por período e colunas ordenáveis (data, fornecedor, itens, valor, categoria, documento, pagamento) |
| **Fornecedores** | Fechamento mensal (Jaú Auto Peças, Retifos, Ferragens Brasil, Mangopar…): gastos registrados no dia, acumulado em aberto e **conferência da fatura com alerta de divergência** antes do pagamento |
| **Contas a pagar** | Categorias completas; **agenda de sextas-feiras** — a data de pagamento é calculada automaticamente como a sexta anterior ao vencimento (ex.: venc. qui 20/08 → pgto sex 14/08); pagamentos imediatos entram na data em que ocorrem; contas recorrentes com lembrete mensal. **Busca** por fornecedor, descrição, NF, nº da compra, categoria, valor, forma de pagamento, datas e situação, com filtros de forma e situação — filtrando, a agenda de sexta-feira dá lugar à lista do resultado, e o papel sai igual à tela. Uma conta marcada como **“Fatura de cartão”** é quitada **sem lançar saída de novo**, porque as compras no cartão já lançaram a despesa na data em que foram feitas |
| **Contas a receber** | Duas visões: a geral, com tudo que a empresa tem a receber, e a aba **Boletos a receber**, uma linha por parcela (cliente, nº da venda/OS, referência, parcela 2/4, valor, vencimento, situação e data do pagamento), com **filtros** por situação, cliente, venda/OS, período de vencimento e busca, **navegação mês a mês** e o **total de boletos a receber no mês**. Parcelas com **geração automática** a partir da **data do 1º vencimento** (ex.: R$ 12.000, 3× a cada 30 dias com 1º em 10/10/2026 → 10/10, 09/11, 09/12 de R$ 4.000; sem data informada, conta da venda: 27/07, 3× a cada 20 dias → 16/08, 05/09, 25/09). O **vencimento de cada parcela se edita sozinho**, sem mexer nas irmãs, e data/valor alterados ficam no **histórico da parcela**. Recebimento **total ou parcial**: o que entra vai para o Fluxo de caixa na hora, sem lançamento duplicado, e a parcela fica *Parcialmente paga* pelo saldo. Situações: a vencer / vencido / parcialmente pago / pago / cancelado. A venda entra aqui como **reflexo do pedido** — valor do pedido, total recebido e situação, sem sumir quando quita — e receber por aqui é **o mesmo recebimento** de Vendas, com uma entrada só no caixa |
| **Agenda financeira** | Calendário mensal com **contas a pagar e a receber lado a lado**, lido direto dos dois módulos — nenhum compromisso é cadastrado de novo. Cada dia mostra o total a receber (verde) e a pagar (vermelho), marca o que já foi baixado (✓) e o que está vencido (!); clicar no dia abre o detalhe com cliente/fornecedor, descrição, valor, vencimento e status. Navega por mês anterior / mês atual / próximo, aceita **período personalizado** (inclusive atravessando meses) e alterna entre **por vencimento** e **por data de pagamento** — nesta última a conta aparece na sexta-feira em que será paga, seguindo a agenda de sextas. Cada perfil enxerga só o lado que já podia ver |
| **Fluxo de caixa (forma de pagamento)** | Cada lançamento registra **como** o dinheiro se moveu — Pix, dinheiro, cartão de crédito, cartão de débito, boleto, transferência, cheque — preenchido automaticamente pela origem (recebimento, pagamento de conta, compra no cartão, frete, RH) e editável nos manuais. **Não é conta bancária**: tudo continua na mesma conta da empresa. Coluna ordenável, filtro próprio e busca por forma. Escolhendo **Cartão de crédito** + um mês, a tela mostra o **total gasto no cartão no período**, a quantidade de lançamentos e um campo para digitar o valor da fatura que chegou, apontando a diferença — é a conferência da fatura |
| **Fluxo de caixa** | Regime de caixa (quando o dinheiro entrou/saiu), separado da DRE; alimentado automaticamente por vendas, OS, contas e RH; exportação CSV |
| **Projeção** | A receber × a pagar × saldo projetado em 7/30/60/90 dias, 6 meses e 1 ano |
| **DRE** | Receita (cabeçotes, peças, serviços), custos, lucro bruto, despesas operacionais e financeiras, lucro líquido e margem, por mês |
| **RH** | Mini-painel (ativos, custo fixo mensal, extras do mês, próximos pagamentos), busca + filtros por vínculo (Fixo/Oficina · Administrativo · Freelancer/Pista), salários/benefícios (acesso restrito), bônus de produção e **assistência de pista agrupada por etapa/evento** (várias pessoas de uma vez, total por corrida); telas vazias guiam o primeiro passo; pagamentos alimentam o financeiro |
| **Relatórios** | Central com filtros (data, status, responsável, cliente) e **🖨️ Imprimir** / exportar; inclui **IMPRIMIR PENDÊNCIAS** (tudo que precisa ser feito) para entregar aos colaboradores |
| **Administração** | Usuários, perfis de permissão configuráveis (Administrador, Financeiro/Administrativo, Produção + novos), catálogo de serviços, configurações e **histórico de alterações** (quem alterou o quê e quando) |
| **Assistente de IA** | Botão ✦ em todas as telas: responde perguntas sobre os dados (contas, clientes, produção, estoque…) usando Gemini ou Claude; a chave da API fica só no servidor e **cada perfil só recebe respostas com o que já pode ver** (Produção não recebe custos/margens/salários) |
| **Envio por WhatsApp** | Botão ✆ nos orçamentos (proposta completa com itens, total e validade), nas OS e vendas (avisos de “pronto”/“enviado”/andamento) e nas contas a receber (lembrete de cobrança); abre uma janela de revisão com a mensagem editável e vai direto para a conversa do cliente no WhatsApp |
| **Backup na nuvem** | Além do backup diário local, copia os dados para uma pasta sincronizada (Google Drive para Computador, OneDrive, Dropbox) com detecção automática das pastas, teste de escrita, “fazer backup agora” e status do último envio — se o computador quebrar, os dados estão na nuvem |
| **Etiqueta de envio** | Botão 📦 no pedido e na OS: gera a etiqueta com **remetente da empresa** (cadastrado uma vez) e **destinatário do cadastro do cliente**, sem redigitar nada; ocupa ~1/3 de uma folha A4 vertical para recortar e colar na caixa, com destaque para nome, endereço, cidade/UF e CEP; imprime ou salva em PDF pela janela de impressão, e a emissão fica registrada no pedido/OS |
| **Documentos e endereço** | Máscara automática de **CPF/CNPJ e CEP** com validação real (dígitos verificadores) — guardados só com números, então a busca funciona com ou sem pontuação; digitar o **CEP preenche endereço, bairro, cidade e UF** (nunca sobrescreve o que já está preenchido sem confirmar, e o cadastro continua funcionando sem internet) |
| **Trabalho simultâneo** | Com um servidor único (rede local ou Tailscale), o servidor avisa as telas abertas e elas se **atualizam sozinhas em menos de 1 segundo** — sem recarregar e sem interromper quem está digitando (a atualização espera o formulário fechar) |
| **Atualização em um clique** | **`ATUALIZAR.bat`** baixa a versão nova, troca só os arquivos do programa e reabre o sistema — a pasta `data` (dados da empresa) nunca é tocada |
| **Acesso pelo celular** | Em *Administração → Configurações*, um **QR code** abre o sistema no celular (mesmo Wi-Fi) com os mesmos dados em tempo real — QR gerado localmente, sem internet; **LIBERAR NO CELULAR.bat** destrava o firewall do Windows com um clique |
| **Produtos e custos** | Administração completa das configurações, **sem mexer no código**: criar e editar configurações, mudar nomenclatura, **acrescentar comandos** (nunca substituindo os existentes), definir os tuchos aceitos, ativar/desativar o que saiu de linha, e a **composição técnica** de cada montagem — peça por peça, com quantidade por cabeçote (casco, comando, tuchos, válvulas de admissão e de escape, molas, pratos, travas e o que mais a oficina usar). O comando e o tucho entram como “o escolhido na venda”, então a mesma composição serve a todos os comandos da configuração. Abas de **Comandos** (onde cada um vale), **Custos** (custo de cada peça e custo total estimado, com opção de usar a composição como custo-base) e **🔎 Conferência das baixas** |
| **Modelos 3D** | Em *Produtos e custos*: upload do escaneamento/CAD exportado como **STL/OBJ/PLY** (até 200 MB), vínculo por produto e **visualizador 3D em tela cheia** (three.js embutido, offline) — peça em alumínio sobre fundo escuro, gira com o mouse ou com o dedo no celular; ideal para mostrar ao cliente |
| **Importar planilha de gastos** | No *Fluxo de caixa*: lê o Excel semanal da oficina (uma aba por semana, gastos à esquerda e entradas à direita), com conferência antes de gravar, **categorias sugeridas automaticamente** (componentes, salários, impostos… → alimentam a DRE) e **trava anti-duplicação** — pode reimportar o mesmo arquivo todo mês que só entra o que é novo |

## Princípios implementados

- **Não duplicar informação**: venda alimenta produção, estoque, contas a receber,
  caixa, custo, resultado, DRE e histórico do cliente; serviço alimenta bem de
  terceiro, orçamento, OS, pagamento e devolução; compra alimenta estoque,
  fornecedor, contas a pagar, agenda e caixa.
- **Um fato, um lançamento**: o mesmo trabalho aparece em abas diferentes, mas só
  é informado uma vez. Cada informação tem uma fonte principal, e as outras a
  recebem sozinhas:

  | Informação | Fonte principal | Quem acompanha sozinho |
  |---|---|---|
  | Andamento físico do trabalho | **Produção** (checklist) | status da OS, status do pedido de venda |
  | Conclusão do serviço | **OS** (status/envio) | checklist da produção, bem do cliente, entrada do cabeçote |
  | Expedição | **Venda / OS** (enviado, entregue) | produção concluída, bem devolvido |
  | Escopo e preço do serviço | **Orçamento** até aprovar; depois a **OS** | produção, contas a receber |
  | O que a empresa tem a receber | **Contas a receber** | fluxo de caixa, agenda, painel, ficha do cliente |
  | O que a empresa deve | **Contas a pagar / Compras / Fretes / RH** | fluxo de caixa, agenda |
  | Estoque próprio | **Estoque** e suas movimentações | produção, venda, compra |
  | Que peças entram em cada cabeçote | **Produtos e custos** (composição) | separação da produção, baixa de estoque, custo do produto |

  Toda alteração automática fica registrada no histórico e na auditoria, dizendo
  o que mudou e por quê (“ordem de produção concluída automaticamente porque a
  OS nº 12 ficou pronta para envio”).
- **Cancelar uma vez**: cancelar um pedido cancela as parcelas em aberto, tira a
  produção da fila e devolve as peças ao estoque; cancelar uma OS cancela as
  parcelas e a produção e libera o cabeçote do cliente; recusar um orçamento
  devolve a entrada para “aguardando orçamento”. O que já virou dinheiro no
  caixa nunca é apagado por trás — fica registrado.
- **Estoque ≠ bens de clientes** · **Receita ≠ recebimento** · **Despesa ≠ pagamento** —
  o caixa registra o dinheiro efetivo; contas a pagar/receber registram compromissos.
- **Compra no cartão ≠ pagamento da fatura**: a compra no cartão de crédito
  lança a despesa no Fluxo de caixa **na data da compra** (forma “cartão de
  crédito”) e não gera conta a pagar — quem se paga depois é a fatura. A conta
  da fatura, marcada como tal, é quitada **sem lançar saída outra vez**. Assim o
  mesmo gasto nunca entra duas vezes, e a tela do cartão serve para conferir a
  fatura contra o que está lançado.
- **Venda não é recebimento**: cadastrar uma venda registra só o que o cliente
  **deve** pagar, em Contas a receber — nenhuma forma de pagamento, nem “à vista”,
  lança dinheiro no Fluxo de caixa. O caixa recebe o valor quando alguém usa
  **Registrar recebimento** no pedido (total ou parcial), e o saldo da venda
  considera tudo que já entrou — recebimentos lançados no pedido e parcelas
  baixadas em Contas a receber — para o mesmo dinheiro nunca contar duas vezes.
  Repetir o mesmo valor na mesma data pede confirmação.
  *Administração → 🔎 Conferência do caixa* audita as entradas automáticas que a
  versão antiga gravava e corrige só o que for confirmado, com cópia do banco antes.
- **Vendas e Contas a receber são a mesma conta**: a linha da venda em Contas a
  receber é o **reflexo do pedido** — mostra sempre o valor do pedido, o total já
  recebido e a situação (*Em aberto / Recebido em parte / Paga*), e **não desaparece
  quando a venda quita**. O dinheiro fica gravado em **um lugar só**: receber por
  **Vendas → 💵 Registrar recebimento** ou por **Contas a receber → ✓ Receber** grava
  o mesmo recebimento, com **identificador próprio**, e lança **uma** entrada no Fluxo
  de caixa. Cobrança própria — plano de boletos, cartão ou link — tem baixa na
  **parcela**, e o pedido aponta para lá em vez de aceitar um segundo lançamento.
  Para o histórico gravado antes dessa regra, *Administração → 🔎 Conferência do caixa*
  traz a seção **B. Vendas que não aparecem certas em Contas a receber**: ela lista
  venda por venda o que está errado hoje, separa o que religa com segurança do que
  precisa de revisão manual e **religa sem criar recebimento e sem tocar no Fluxo de
  caixa** (vencimento e observações digitados são preservados; cópia do banco antes).
- **Uma composição só, para tudo**: as peças de cada configuração são cadastradas
  uma vez em *Produtos e custos* e dali saem a **separação do checklist** da
  produção, a **baixa do estoque** quando a ordem fica pronta e o **custo** do
  produto. Mudar a composição vale para as próximas vendas; a ordem que já
  consumiu guarda o que consumiu, com quantidade e custo, e não é reescrita.
  Comando e tucho entram como “o escolhido na venda”, então a baixa é sempre do
  comando que o cliente comprou.
- **A baixa acontece na produção, não na venda**: cadastrar o pedido não tira
  peça do estoque — quem tira é a ordem de produção ao ficar **pronta**, uma vez
  só (reabrir e fechar de novo não baixa em dobro). Peça de revenda é diferente:
  sai no ato da venda. O detalhe do pedido mostra, peça por peça, o que deveria
  sair, o que saiu e a situação (*baixa realizada / pendente / aguardando a
  produção / item não vinculado / necessita revisão*), com data, quantidade e o
  pedido que originou cada movimentação.
  *Produtos e custos → 🔎 Conferência das baixas* confere todos os pedidos de
  uma vez e separa o que pode ser corrigido do que foi baixado pela regra
  anterior (1 unidade de cada peça) — este último nada vem marcado, porque pode
  já ter sido movimentado à mão. A correção é por pedido e por peça, movimenta
  **só a diferença**, grava cópia do banco antes e deixa cada ajuste registrado.
- **Rastreabilidade**: cada cabeçote tem linha do tempo completa
  (entrada → orçamento → aprovação → OS → produção → pagamento → NF → envio) e
  auditoria de alterações por usuário.
- **Permissões**: perfil Produção não vê salários, custos, margens nem financeiro
  sensível — controlado pela permissão “Dados financeiros sensíveis”.
- **O filtro escolhido não se perde**: a tela se atualiza sozinha a cada
  gravação (inclusive de outra pessoa). O filtro, o tipo e as etapas abertas
  ficam guardados por tela, então concluir uma etapa não joga ninguém de
  volta para o filtro padrão.
- **Busca e ordenação iguais em todas as abas**: a mesma barra de pesquisa
  (sem acento, palavras em qualquer ordem), os mesmos cabeçalhos clicáveis
  com seta (⇅ ▲ ▼) e o mesmo botão de limpar filtros. Filtrar e ordenar é
  sempre só visualização: nunca altera o registro nem a ordem guardada no
  banco. A impressão sai com o mesmo recorte e a mesma ordem da tela.

## Arquitetura

- `server.js` — servidor HTTP + API REST (Node puro, sem dependências)
- `lib/db.js` — persistência JSON com gravação atômica
- `lib/domain.js` — regras de negócio (sexta-feira de pagamento, parcelas,
  Stage × comando × tucho, checklist de produção, resultado de venda, projeção, DRE)
- `lib/seed.js` — dados iniciais (perfis, catálogo com preços do modelo atual,
  produtos, componentes, fornecedores, recorrentes)
- `public/` — SPA responsiva com impressão dedicada. Identidade visual Jaques
  Motorsport: preto/grafite com acentos vermelhos, selo JM como ícone e
  wordmark serifada nos documentos (arquivos-fonte da marca em `branding/`)
